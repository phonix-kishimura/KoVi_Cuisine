using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Quản lý cấu trúc lưới bàn cờ, các ô nền (BackgroundTiile) và vật cản (ObstacleTile).
/// - Mọi ô Obstacle đều có sẵn BackgroundTiile nằm bên dưới ngay từ đầu.
/// - Mỗi Obstacle chỉ cần 1 lần va chạm là vỡ. Khi vỡ sẽ kiểm tra ObstacleData (ScriptableObject)
///   để đẻ ra Obstacle mới có Sprite bị nứt/vỡ cho đến khi hết số lần sinh (RemainingSpawns == 0).
/// </summary>
public class Board : MonoBehaviour
{
    public const int EMPTY_CELL_TYPE = -2;

    [Header("Level Data")]
    [SerializeField] private LevelData levelData;

    [Header("Fallback Board Size")]
    [SerializeField, Min(3)] private int width = 8;
    [SerializeField, Min(3)] private int height = 8;

    [Header("Prefabs & Obstacle ScriptableObject")]
    [Tooltip("Prefab ô nền có gắn BackgroundTiile.cs (Luôn được tạo dưới cả Kẹo lẫn Obstacle).")]
    [SerializeField] private GameObject tilePrefab;

    [Tooltip("Prefab hiển thị cho Obstacle.")]
    [SerializeField] private GameObject obstaclePrefab;

    [Tooltip("File ScriptableObject ObstacleData mặc định (nếu trong LevelData chưa gán).")]
    [SerializeField] private ObstacleData defaultObstacleData;

    [Header("Gameplay Reference")]
    [SerializeField] private GameManager gameManager;

    private BoardLayoutData activeLayout;
    private Vector2 boardCenterPosition;

    public float CellSize { get; private set; } = 1f;
    public Vector2 BoardWorldCenter => boardCenterPosition;

    public int Width => activeLayout != null ? activeLayout.Width : width;
    public int Height => activeLayout != null ? activeLayout.Height : height;
    public GameObject TilePrefab => tilePrefab;
    public GameObject ObstaclePrefab => obstaclePrefab;
    public LevelData CurrentLevelData => levelData;
    public BoardLayoutData CurrentLayout => activeLayout;
    public bool UsesCustomLayout => activeLayout != null;

    public BackgroundTiile[,] Tiles { get; private set; }
    public ObstacleTile[,] Obstacles { get; private set; }
    public List<BackgroundTiile> PlayableTiles { get; } = new List<BackgroundTiile>();

    public Transform TilesContainer { get; private set; }
    public Transform ObstaclesContainer { get; private set; }
    public Transform CandiesContainer { get; private set; }
    public CandyPool Pool { get; private set; }
    public bool IsBuilt { get; private set; }
    public int ActiveObstacleCount { get; private set; }

    private void Start()
    {
        if (LevelSession.SelectedLevelData != null)
        {
            levelData = LevelSession.SelectedLevelData;
        }

        if (!ValidateBoardSetup())
        {
            return;
        }

        Match3VFXManager.EnsureInstance();
        Match3UIManager uiManager = Match3UIManager.EnsureInstance();

        CalculateSafeBoardTransform();
        SetupContainersAndPool();
        BuildBoard();

        if (gameManager == null)
        {
            gameManager = FindFirstObjectByType<GameManager>();
        }

        if (gameManager == null)
        {
            Debug.LogError("Không tìm thấy GameManager trong scene. Hãy thêm GameManager vào scene.", this);
            return;
        }

        Match3VFXManager.Instance.SuppressVFX = true;
        gameManager.Initialize(this);
        Match3VFXManager.Instance.SuppressVFX = false;

        uiManager.InitializeWithBoard(this, gameManager);
    }

    public void SetBoardVisible(bool visible)
    {
        if (TilesContainer != null) TilesContainer.gameObject.SetActive(visible);
        if (ObstaclesContainer != null) ObstaclesContainer.gameObject.SetActive(visible);
        if (CandiesContainer != null) CandiesContainer.gameObject.SetActive(visible);
    }

    private void CalculateSafeBoardTransform()
    {
        Camera cam = Camera.main;
        if (cam != null && cam.orthographic)
        {
            float totalWorldHeight = cam.orthographicSize * 2f;
            float totalWorldWidth = totalWorldHeight * cam.aspect;

            float topReserved = totalWorldHeight * Match3UIManager.TOP_HUD_SCREEN_RATIO;
            float bottomReserved = totalWorldHeight * Match3UIManager.BOTTOM_HUD_SCREEN_RATIO;

            float safeCenterY = cam.transform.position.y + (bottomReserved - topReserved) * 0.5f;
            float safeCenterX = cam.transform.position.x;
            boardCenterPosition = new Vector2(safeCenterX, safeCenterY);

            float availableHeight = (totalWorldHeight - topReserved - bottomReserved) * 0.88f;
            float availableWidth = totalWorldWidth * 0.90f;

            float maxCellW = availableWidth / Mathf.Max(1, Width);
            float maxCellH = availableHeight / Mathf.Max(1, Height);
            CellSize = Mathf.Min(1.0f, Mathf.Min(maxCellW, maxCellH));
        }
        else
        {
            boardCenterPosition = GetParentCanvasCenter();
            CellSize = 0.85f;
        }

        transform.position = boardCenterPosition;
    }

    public Vector2 GetParentCanvasCenter()
    {
        Canvas parentCanvas = GetComponentInParent<Canvas>();
        if (parentCanvas != null)
        {
            RectTransform canvasRect = parentCanvas.GetComponent<RectTransform>();
            if (canvasRect != null)
            {
                Vector3 worldCenter = canvasRect.TransformPoint(canvasRect.rect.center);
                if (parentCanvas.renderMode == RenderMode.ScreenSpaceOverlay && Camera.main != null)
                {
                    worldCenter = Camera.main.ScreenToWorldPoint(worldCenter);
                }
                return new Vector2(worldCenter.x, worldCenter.y);
            }
        }

        if (transform.parent != null)
        {
            return new Vector2(transform.parent.position.x, transform.parent.position.y);
        }

        return new Vector2(transform.position.x, transform.position.y);
    }

    public Vector2 GetCellPosition(int x, int y)
    {
        Vector2 gridCenterOffset = new Vector2((Width - 1) * 0.5f, (Height - 1) * 0.5f);

        return new Vector2(
            boardCenterPosition.x + (x - gridCenterOffset.x) * CellSize,
            boardCenterPosition.y + (y - gridCenterOffset.y) * CellSize);
    }

    public bool TryGetGridCoordFromWorld(Vector3 worldPos, out int x, out int y)
    {
        x = -1;
        y = -1;

        Vector2 point2D = new Vector2(worldPos.x, worldPos.y);

        Collider2D[] hits = Physics2D.OverlapPointAll(point2D);
        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i] == null) continue;

            ObstacleTile hitObs = hits[i].GetComponent<ObstacleTile>() ?? hits[i].GetComponentInParent<ObstacleTile>();
            if (hitObs != null)
            {
                x = hitObs.X;
                y = hitObs.Y;
                return true;
            }

            Candy hitCandy = hits[i].GetComponent<Candy>() ?? hits[i].GetComponentInParent<Candy>();
            if (hitCandy != null && hitCandy.Cell != null)
            {
                x = hitCandy.Cell.X;
                y = hitCandy.Cell.Y;
                return true;
            }

            BackgroundTiile hitTile = hits[i].GetComponent<BackgroundTiile>() ?? hits[i].GetComponentInParent<BackgroundTiile>();
            if (hitTile != null)
            {
                x = hitTile.X;
                y = hitTile.Y;
                return true;
            }
        }

        float maxRadius = Mathf.Max(0.45f, CellSize * 0.72f);
        float bestDistSq = maxRadius * maxRadius;
        bool foundClosest = false;

        for (int ix = 0; ix < Width; ix++)
        {
            for (int iy = 0; iy < Height; iy++)
            {
                Vector3 cellWorldPos;
                if (Tiles != null && Tiles[ix, iy] != null)
                {
                    cellWorldPos = Tiles[ix, iy].transform.position;
                }
                else if (Obstacles != null && Obstacles[ix, iy] != null)
                {
                    cellWorldPos = Obstacles[ix, iy].transform.position;
                }
                else
                {
                    continue;
                }

                float dx = point2D.x - cellWorldPos.x;
                float dy = point2D.y - cellWorldPos.y;
                float distSq = dx * dx + dy * dy;
                if (distSq <= bestDistSq)
                {
                    bestDistSq = distSq;
                    x = ix;
                    y = iy;
                    foundClosest = true;
                }
            }
        }

        if (foundClosest)
        {
            return true;
        }

        Vector2 gridCenterOffset = new Vector2((Width - 1) * 0.5f, (Height - 1) * 0.5f);
        float fx = ((worldPos.x - boardCenterPosition.x) / CellSize) + gridCenterOffset.x;
        float fy = ((worldPos.y - boardCenterPosition.y) / CellSize) + gridCenterOffset.y;

        x = Mathf.RoundToInt(fx);
        y = Mathf.RoundToInt(fy);

        return x >= 0 && x < Width && y >= 0 && y < Height;
    }

    public GameObject[] GetActiveCandyPrefabs()
    {
        if (levelData != null && levelData.CustomCandyPrefabs != null && levelData.CustomCandyPrefabs.Length >= 3)
        {
            return levelData.CustomCandyPrefabs;
        }

        if (tilePrefab != null)
        {
            BackgroundTiile tileTemplate = tilePrefab.GetComponent<BackgroundTiile>();
            if (tileTemplate != null)
            {
                return tileTemplate.dots;
            }
        }

        return null;
    }

    private void SetupContainersAndPool()
    {
        GameObject tilesObj = new GameObject("Tiles_Container");
        tilesObj.transform.SetParent(transform, false);
        tilesObj.transform.localPosition = Vector2.zero;
        TilesContainer = tilesObj.transform;

        GameObject obstaclesObj = new GameObject("Obstacles_Container");
        obstaclesObj.transform.SetParent(transform, false);
        obstaclesObj.transform.localPosition = Vector2.zero;
        ObstaclesContainer = obstaclesObj.transform;

        GameObject candiesObj = new GameObject("Candies_Container");
        candiesObj.transform.SetParent(transform, false);
        candiesObj.transform.localPosition = Vector2.zero;
        CandiesContainer = candiesObj.transform;

        Pool = GetComponent<CandyPool>();
        if (Pool == null)
        {
            Pool = gameObject.AddComponent<CandyPool>();
        }

        Pool.Initialize(GetActiveCandyPrefabs(), CandiesContainer);
    }

    private bool ValidateBoardSetup()
    {
        activeLayout = levelData != null ? levelData.BoardLayout : null;

        if (Width < 3 || Height < 3)
        {
            Debug.LogError("Bảng Match 3 cần Width và Height tối thiểu bằng 3.", this);
            return false;
        }

        if (tilePrefab == null || tilePrefab.GetComponent<BackgroundTiile>() == null)
        {
            Debug.LogError("Tile Prefab chưa gán hoặc thiếu component BackgroundTiile.", this);
            return false;
        }

        GameObject[] candyPrefabs = GetActiveCandyPrefabs();
        if (candyPrefabs == null || candyPrefabs.Length < 3)
        {
            Debug.LogError("Cần gán ít nhất 3 Candy Prefab trong LevelData hoặc mảng dots của Tile Prefab.", this);
            return false;
        }

        if (activeLayout != null)
        {
            if (!activeLayout.Validate(out string layoutError, out int playableCount, out bool hasObstacle))
            {
                Debug.LogError($"BoardLayoutData '{activeLayout.name}' không hợp lệ: {layoutError}", activeLayout);
                return false;
            }

            if (hasObstacle && obstaclePrefab == null && (defaultObstacleData == null || defaultObstacleData.CustomObstaclePrefab == null))
            {
                Debug.LogError("Layout có ký hiệu Obstacle nhưng Board chưa được gán Obstacle Prefab.", this);
                return false;
            }

            if (playableCount < 3)
            {
                Debug.LogError("Layout cần có ít nhất 3 ô chơi được (#).", activeLayout);
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Dựng lưới bàn cờ:
    /// - Mọi ô Obstacle đều được tạo một BackgroundTiile nằm ở dưới trước,
    ///   sau đó mới sinh ObstacleTile ban đầu (CrackStep = 0) đặt đè lên trên.
    /// </summary>
    private void BuildBoard()
    {
        Tiles = new BackgroundTiile[Width, Height];
        Obstacles = new ObstacleTile[Width, Height];
        PlayableTiles.Clear();
        ActiveObstacleCount = 0;

        for (int x = 0; x < Width; x++)
        {
            for (int y = 0; y < Height; y++)
            {
                BoardCellType cellType = activeLayout == null
                    ? BoardCellType.Playable
                    : activeLayout.GetCellType(x, y);

                if (cellType == BoardCellType.Empty)
                {
                    continue;
                }

                if (cellType == BoardCellType.Obstacle)
                {
                    // 1. Tạo sẵn BackgroundTiile nằm bên dưới Obstacle (chưa mở khóa vào PlayableTiles)
                    CreateBackgroundTileAt(x, y, addToPlayableList: false);

                    // 2. Lấy cấu hình ObstacleData và số lần đẻ ra Obstacle mới
                    char symbol = GetLayoutSymbol(x, y);
                    ResolveInitialObstacleSetup(symbol, out ObstacleData obsData, out int initialSpawnCount);

                    // 3. Sinh Obstacle ban đầu (nguyên vẹn: crackStep = 0) nằm đè lên trên BackgroundTiile
                    SpawnObstacleInstanceAt(x, y, obsData, initialSpawnCount, crackStep: 0, isNewlySpawnedCrack: false);
                    ActiveObstacleCount++;
                    continue;
                }

                if (cellType == BoardCellType.Playable)
                {
                    CreateBackgroundTileAt(x, y, addToPlayableList: true);
                }
            }
        }

        IsBuilt = true;
    }

    /// <summary>
    /// Xác định file ObstacleData và số lần đẻ ra Obstacle mới (spawnCount) khi khởi tạo ô Obstacle.
    /// </summary>
    private void ResolveInitialObstacleSetup(char symbol, out ObstacleData resolvedData, out int initialSpawnCount)
    {
        resolvedData = levelData != null
            ? levelData.GetObstacleDataForSymbol(symbol, defaultObstacleData)
            : defaultObstacleData;

        // Nếu ký hiệu trên BoardLayoutData là chữ số '1'..'9' và chưa dùng bảng màu riêng -> Số lần đẻ = (chữ số - 1)
        if (symbol >= '1' && symbol <= '9' && (levelData == null || levelData.CustomObstaclePalette == null || levelData.CustomObstaclePalette.Length == 0))
        {
            initialSpawnCount = (symbol - '0') - 1;
            return;
        }

        if (resolvedData != null)
        {
            initialSpawnCount = resolvedData.SpawnCount;
            return;
        }

        // Dự phòng nếu chưa gán file ObstacleData nào
        int fallbackHits = levelData != null ? Mathf.Max(1, levelData.ObstacleHitPoints) : 1;
        initialSpawnCount = fallbackHits - 1;
    }

    private BackgroundTiile CreateBackgroundTileAt(int x, int y, bool addToPlayableList)
    {
        if (Tiles[x, y] == null)
        {
            Vector2 position = GetCellPosition(x, y);
            GameObject tileObject = Instantiate(tilePrefab, position, Quaternion.identity, TilesContainer);
            tileObject.name = $"Tile ({x}, {y})";
            tileObject.transform.localScale *= CellSize;

            BackgroundTiile tile = tileObject.GetComponent<BackgroundTiile>();
            tile.Initialize(this, x, y);
            Tiles[x, y] = tile;
        }

        if (addToPlayableList && !PlayableTiles.Contains(Tiles[x, y]))
        {
            PlayableTiles.Add(Tiles[x, y]);
        }

        return Tiles[x, y];
    }

    public BackgroundTiile CreatePlayableTileAt(int x, int y)
    {
        return CreateBackgroundTileAt(x, y, addToPlayableList: true);
    }

    /// <summary>
    /// Sinh ra một GameObject ObstacleTile mới tại ô (x, y).
    /// Dùng cả lúc khởi tạo bàn cờ lẫn mỗi khi một Obstacle cũ vỡ và đẻ ra Obstacle mới có Sprite bị vỡ.
    /// </summary>
    private ObstacleTile SpawnObstacleInstanceAt(
        int x,
        int y,
        ObstacleData data,
        int remainingSpawns,
        int crackStep,
        bool isNewlySpawnedCrack)
    {
        GameObject prefabToUse = (data != null && data.CustomObstaclePrefab != null)
            ? data.CustomObstaclePrefab
            : obstaclePrefab;

        if (prefabToUse == null)
        {
            Debug.LogError($"Board: Chưa gán Obstacle Prefab để sinh Obstacle tại ({x}, {y})!", this);
            return null;
        }

        Vector2 position = GetCellPosition(x, y);
        Transform parent = ObstaclesContainer != null ? ObstaclesContainer : TilesContainer;

        GameObject obsObj = Instantiate(prefabToUse, position, Quaternion.identity, parent);
        obsObj.name = $"Obstacle_Step{crackStep}_Rem{remainingSpawns} ({x}, {y})";
        obsObj.transform.localScale *= CellSize;

        ObstacleTile obstacle = obsObj.GetComponent<ObstacleTile>();
        if (obstacle == null)
        {
            obstacle = obsObj.AddComponent<ObstacleTile>();
        }

        // Lấy sortingOrder của BackgroundTiile bên dưới để đảm bảo Obstacle luôn hiển thị nổi lên trên
        int baseSortingOrder = 0;
        if (Tiles[x, y] != null)
        {
            SpriteRenderer tileSr = Tiles[x, y].GetComponentInChildren<SpriteRenderer>();
            if (tileSr != null)
            {
                baseSortingOrder = tileSr.sortingOrder;
            }
        }

        obstacle.InitializeWithData(this, x, y, data, remainingSpawns, crackStep, baseSortingOrder + 2);
        Obstacles[x, y] = obstacle;

        if (isNewlySpawnedCrack && gameObject.activeInHierarchy)
        {
            StartCoroutine(AnimateCrackedObstacleSpawnRoutine(obstacle.transform));
        }

        return obstacle;
    }

    /// <summary>
    /// Xử lý va chạm vào Obstacle tại tọa độ (x, y):
    /// - Mỗi Obstacle chỉ cần 1 lần va chạm là vỡ ngay (Destroy).
    /// - Khi vỡ: Nếu còn lượt đẻ (TryGetNextSpawnInfo == true), nó sẽ lập tức ĐẺ RA 1 OBSTACLE MỚI
    ///   ngay tại ô (x, y) có Sprite là hình ảnh bị vỡ của bước tiếp theo!
    /// - Nếu không còn lượt đẻ nào (RemainingSpawns == 0), ô BackgroundTiile bên dưới sẽ được mở khóa!
    /// </summary>
    public bool DamageObstacleAt(int x, int y, int damage = 1)
    {
        if (Obstacles == null || x < 0 || x >= Width || y < 0 || y >= Height)
        {
            return false;
        }

        ObstacleTile currentObs = Obstacles[x, y];
        if (currentObs == null || currentObs.IsDestroyed)
        {
            return false;
        }

        Vector3 obsWorldPos = currentObs.transform.position;

        // Kiểm tra trước thông tin Obstacle bị vỡ sẽ đẻ ra tiếp theo (nếu có)
        bool shouldSpawnCrackedObstacle = currentObs.TryGetNextSpawnInfo(
            out ObstacleData nextData,
            out int nextRemainingSpawns,
            out int nextCrackStep);

        // 1. Phá vỡ Obstacle hiện tại ngay lập tức (1 chạm là vỡ)
        currentObs.MarkDestroyed();
        if (Match3VFXManager.Instance != null)
        {
            Match3VFXManager.Instance.PlayBubblePop(obsWorldPos, nextCrackStep + 2, CellSize * 1.15f);
        }
        Destroy(currentObs.gameObject);

        // 2. Nếu còn số lần sinh Obstacle mới -> Đẻ ra một Obstacle mới mang Sprite bị vỡ tại đúng ô (x, y)!
        if (shouldSpawnCrackedObstacle)
        {
            SpawnObstacleInstanceAt(
                x,
                y,
                nextData,
                nextRemainingSpawns,
                nextCrackStep,
                isNewlySpawnedCrack: true);

            return false; // Chưa mở khóa ô kẹo vì vừa đẻ ra Obstacle bị vỡ mới
        }

        // 3. Nếu Obstacle vừa vỡ là bản thể cuối cùng (RemainingSpawns == 0) -> Mở khóa BackgroundTiile bên dưới!
        Obstacles[x, y] = null;
        ActiveObstacleCount = Mathf.Max(0, ActiveObstacleCount - 1);

        CreatePlayableTileAt(x, y);
        return true;
    }

    /// <summary>
    /// Hiệu ứng nảy & rung nhẹ khi một Obstacle mới có Sprite bị vỡ vừa được đẻ ra.
    /// </summary>
    private IEnumerator AnimateCrackedObstacleSpawnRoutine(Transform target)
    {
        if (target == null) yield break;
        Vector3 baseScale = target.localScale;
        float duration = 0.18f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            if (target == null) yield break;
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float scaleBounce = 1f + Mathf.Sin(t * Mathf.PI) * 0.20f;
            float tiltAngle = Mathf.Sin(t * Mathf.PI * 2f) * 7f * (1f - t);

            target.localScale = baseScale * scaleBounce;
            target.localRotation = Quaternion.Euler(0f, 0f, tiltAngle);
            yield return null;
        }

        if (target != null)
        {
            target.localScale = baseScale;
            target.localRotation = Quaternion.identity;
        }
    }

    public bool ExecuteHammerBoosterAt(int x, int y)
    {
        return gameManager != null && gameManager.TryExecuteHammerBooster(x, y);
    }

    public bool ExecuteFreeSwapBooster(BackgroundTiile tileA, BackgroundTiile tileB)
    {
        return gameManager != null && gameManager.TryExecuteFreeSwapBooster(tileA, tileB);
    }

    public bool ExecuteColorBombBoosterAt(int x, int y)
    {
        return gameManager != null && gameManager.TryExecuteColorBombBooster(x, y);
    }

    public bool ExecuteShuffleBooster()
    {
        return gameManager != null && gameManager.TryExecuteShuffleBooster();
    }

    public char GetLayoutSymbol(int x, int y)
    {
        if (x < 0 || x >= Width || y < 0 || y >= Height) return '.';
        return activeLayout == null ? '#' : activeLayout.GetSymbol(x, y);
    }

    public bool IsCellInLayout(int x, int y) => GetBackgroundTile(x, y) != null;

    public BackgroundTiile GetBackgroundTile(int x, int y)
    {
        if (Tiles == null || x < 0 || x >= Width || y < 0 || y >= Height) return null;
        return Tiles[x, y];
    }

    /// <summary>
    /// Trả về BackgroundTiile tại (x, y) chỉ khi ô đó KHÔNG còn bị Obstacle đè lên.
    /// Giúp GameManager không sinh kẹo đè lên Obstacle và tự động kích hoạt trượt chéo (Diagonal Slide).
    /// </summary>
    public BackgroundTiile GetTile(int x, int y)
    {
        if (Tiles == null || x < 0 || x >= Width || y < 0 || y >= Height) return null;

        if (Obstacles != null && Obstacles[x, y] != null && !Obstacles[x, y].IsDestroyed)
        {
            return null;
        }

        return Tiles[x, y];
    }

    public ObstacleTile GetObstacle(int x, int y)
    {
        if (Obstacles == null || x < 0 || x >= Width || y < 0 || y >= Height) return null;
        return Obstacles[x, y];
    }

    public Candy GetCandyAt(int x, int y)
    {
        BackgroundTiile tile = GetTile(x, y);
        return tile != null ? tile.CurrentCandy : null;
    }

    public int GetCandyTypeAt(int x, int y)
    {
        Candy candy = GetCandyAt(x, y);
        return candy == null ? EMPTY_CELL_TYPE : candy.TypeIndex;
    }

    public bool IsNeutralSpecialAt(int x, int y)
    {
        Candy candy = GetCandyAt(x, y);
        return candy != null && candy.IsNeutralSpecial;
    }

    public bool DoesCellMatchColor(int x, int y, int targetColor)
    {
        Candy candy = GetCandyAt(x, y);
        return candy != null && candy.MatchesColor(targetColor);
    }
}