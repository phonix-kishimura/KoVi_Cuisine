using UnityEngine;

/// <summary>
/// Các loại kẹo đặc biệt trong game (tương tự Candy Crush).
/// Toàn bộ kẹo đặc biệt đều mang tính TRUNG TÍNH (không phân màu, ghép được với mọi màu kẹo).
/// </summary>
public enum SpecialCandyType
{
    None = 0,               // Kẹo thường (có màu cụ thể)
    StripedHorizontal = 1,  // Kẹo Sọc Ngang (Match 4 dọc) -> Nổ toàn bộ hàng ngang
    StripedVertical = 2,    // Kẹo Sọc Dọc (Match 4 ngang) -> Nổ toàn bộ cột dọc
    Wrapped = 3,            // Kẹo Gói (Match L hoặc T) -> Nổ vùng 3x3 xung quanh
    ColorBomb = 4,          // Bom Màu (Match 5 thẳng hàng) -> Nổ toàn bộ kẹo của 1 màu
    SugarFish = 5           // Kẹo Cá / Vuông (Match Square 2x2) -> Phá vật cản + ô ngẫu nhiên
}

/// <summary>
/// Quản lý dữ liệu và hiển thị của một viên kẹo trên bàn cờ.
/// </summary>
public class Candy : MonoBehaviour
{
    /// <summary>
    /// Hằng số đại diện cho kẹo trung tính (không thuộc màu nào).
    /// </summary>
    public const int NEUTRAL_COLOR_ID = -1;

    [Header("Runtime State")]
    [Tooltip("ID màu hiện tại của kẹo. Nếu là Kẹo Đặc Biệt trung tính, giá trị này sẽ là -1 (NEUTRAL_COLOR_ID).")]
    public int TypeIndex { get; private set; }

    [Tooltip("ID gốc của Prefab trong CandyPool (giúp trả kẹo về đúng hàng đợi khi thu hồi).")]
    public int PoolIndex { get; private set; }

    [Tooltip("Loại kẹo đặc biệt hiện tại.")]
    public SpecialCandyType SpecialType { get; private set; } = SpecialCandyType.None;

    [Tooltip("Ô nền hiện tại đang chứa viên kẹo này.")]
    public BackgroundTiile Cell { get; private set; }

    /// <summary>
    /// Kiểm tra nhanh viên kẹo này có phải là Kẹo Đặc Biệt trung tính (ghép được với mọi màu) hay không.
    /// </summary>
    public bool IsNeutralSpecial => SpecialType != SpecialCandyType.None;

    [Header("Optional Custom Visuals (Gán Sprite/Badge riêng nếu có)")]
    [SerializeField] private SpriteRenderer mainRenderer;
    [SerializeField] private Sprite customNeutralBaseSprite;
    [SerializeField] private GameObject stripedHorizontalBadge;
    [SerializeField] private GameObject stripedVerticalBadge;
    [SerializeField] private GameObject wrappedBadge;
    [SerializeField] private GameObject colorBombBadge;
    [SerializeField] private GameObject sugarFishBadge;

    // Lưu trữ hình ảnh và màu gốc của Prefab kẹo thường để khôi phục khi tái sử dụng từ Pool
    private Sprite originalSprite;
    private Color baseColor = Color.white;
    private Vector3 baseLocalScale = Vector3.one;

    // Đối tượng chứa ký hiệu kẹo đặc biệt tự vẽ bằng code (nếu chưa gán Badge riêng)
    private GameObject proceduralBadgeRoot;
    private bool isSelected;

    // Sprite hình tròn trung tính dùng chung cho mọi Kẹo Đặc Biệt nếu chưa gán Sprite riêng trong Inspector
    private static Sprite sharedNeutralSprite;

    private void Awake()
    {
        if (mainRenderer == null)
        {
            mainRenderer = GetComponent<SpriteRenderer>();
            if (mainRenderer == null)
            {
                mainRenderer = GetComponentInChildren<SpriteRenderer>();
            }
        }

        baseLocalScale = transform.localScale;
        if (mainRenderer != null)
        {
            originalSprite = mainRenderer.sprite;
            baseColor = mainRenderer.color;
        }
    }

    /// <summary>
    /// Khởi tạo hoặc làm mới viên kẹo khi lấy ra từ Object Pool.
    /// </summary>
    public void Initialize(int poolTypeIndex, SpecialCandyType specialType = SpecialCandyType.None)
    {
        PoolIndex = poolTypeIndex;
        TypeIndex = poolTypeIndex;
        SpecialType = SpecialCandyType.None;
        isSelected = false;
        transform.localScale = baseLocalScale;

        if (mainRenderer != null)
        {
            mainRenderer.sprite = originalSprite;
            mainRenderer.color = baseColor;
        }

        SetSpecialType(specialType);
    }

    /// <summary>
    /// Gán ô đứng hiện tại trên bàn cờ cho viên kẹo.
    /// </summary>
    public void SetCell(BackgroundTiile cell)
    {
        Cell = cell;
    }

    /// <summary>
    /// Chuyển đổi viên kẹo thành Kẹo Đặc Biệt trung tính (hoặc trả về kẹo thường nếu truyền vào None).
    /// </summary>
    public void SetSpecialType(SpecialCandyType newSpecialType)
    {
        SpecialType = newSpecialType;

        // Nếu là Kẹo Đặc Biệt -> Đặt TypeIndex về trung tính (-1) để không còn phân biệt màu.
        // Nếu trở lại Kẹo Thường -> Khôi phục lại màu gốc từ PoolIndex.
        TypeIndex = (SpecialType != SpecialCandyType.None) ? NEUTRAL_COLOR_ID : PoolIndex;

        UpdateSpecialVisuals();
    }

    /// <summary>
    /// Kiểm tra viên kẹo này có thể ghép (Match) với một màu mục tiêu hay không.
    /// - Kẹo Đặc Biệt trung tính: Luôn trả về true với mọi màu.
    /// - Kẹo thường: Chỉ trả về true nếu trùng mã màu.
    /// </summary>
    public bool MatchesColor(int targetColorIndex)
    {
        if (IsNeutralSpecial)
        {
            return true;
        }
        return TypeIndex == targetColorIndex;
    }

    /// <summary>
    /// Hiệu ứng phóng to nhẹ khi người chơi chạm chọn viên kẹo trên màn hình.
    /// </summary>
    public void SetSelectedVisual(bool selected)
    {
        isSelected = selected;
        transform.localScale = selected ? baseLocalScale * 1.18f : baseLocalScale;
    }

    public Vector3 GetBaseScale()
    {
        return baseLocalScale;
    }

    private void Update()
    {
        // Hiệu ứng đổi màu cầu vồng liên tục cho Bom Màu
        if (SpecialType == SpecialCandyType.ColorBomb && mainRenderer != null)
        {
            float hue = Mathf.Repeat(Time.time * 0.6f, 1f);
            mainRenderer.color = Color.HSVToRGB(hue, 0.75f, 1f);
        }

        // Hiệu ứng nhịp thở khi viên kẹo đang được người chơi chọn
        if (isSelected)
        {
            float pulse = 1.12f + Mathf.Sin(Time.time * 10f) * 0.06f;
            transform.localScale = baseLocalScale * pulse;
        }
    }

    /// <summary>
    /// Cập nhật ngoại hình cho Kẹo Đặc Biệt.
    /// Đảm bảo mọi Kẹo Đặc Biệt cùng loại đều có hình dáng và màu sắc TRUNG TÍNH giống hệt nhau,
    /// không bị phụ thuộc vào hình ảnh hay màu sắc của viên kẹo thường ban đầu.
    /// </summary>
    private void UpdateSpecialVisuals()
    {
        // 1. Bật/tắt các Badge thủ công (nếu bạn có gán sẵn trong Inspector)
        bool hasCustomBadges = stripedHorizontalBadge != null || stripedVerticalBadge != null
            || wrappedBadge != null || colorBombBadge != null || sugarFishBadge != null;

        if (stripedHorizontalBadge != null) stripedHorizontalBadge.SetActive(SpecialType == SpecialCandyType.StripedHorizontal);
        if (stripedVerticalBadge != null) stripedVerticalBadge.SetActive(SpecialType == SpecialCandyType.StripedVertical);
        if (wrappedBadge != null) wrappedBadge.SetActive(SpecialType == SpecialCandyType.Wrapped);
        if (colorBombBadge != null) colorBombBadge.SetActive(SpecialType == SpecialCandyType.ColorBomb);
        if (sugarFishBadge != null) sugarFishBadge.SetActive(SpecialType == SpecialCandyType.SugarFish);

        // 2. Xóa Badge tự động cũ trước khi vẽ lại
        if (proceduralBadgeRoot != null)
        {
            Destroy(proceduralBadgeRoot);
            proceduralBadgeRoot = null;
        }

        if (mainRenderer == null)
        {
            return;
        }

        // 3. Nếu là Kẹo Thường -> Khôi phục đúng Sprite và màu của kẹo thường rồi thoát
        if (SpecialType == SpecialCandyType.None)
        {
            mainRenderer.sprite = originalSprite;
            mainRenderer.color = baseColor;
            return;
        }

        // 4. Nếu là Kẹo Đặc Biệt -> Đổi sang Sprite nền trung tính đồng nhất để xóa bỏ hình dáng kẹo màu cũ
        Sprite neutralSprite = customNeutralBaseSprite != null ? customNeutralBaseSprite : GetOrCreateSharedNeutralSprite();
        mainRenderer.sprite = neutralSprite;
        mainRenderer.color = GetNeutralBaseColor(SpecialType);

        if (hasCustomBadges)
        {
            return;
        }

        // 5. Tự động vẽ ký hiệu trực quan cho từng loại Kẹo Đặc Biệt trung tính
        proceduralBadgeRoot = new GameObject("SpecialBadge_Auto");
        proceduralBadgeRoot.transform.SetParent(transform, false);
        proceduralBadgeRoot.transform.localPosition = Vector3.zero;

        switch (SpecialType)
        {
            case SpecialCandyType.StripedHorizontal:
                // Kẹo Sọc Ngang: 2 vạch ngang trắng sáng
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.85f, 0.16f, 1f), new Vector3(0f, 0.16f, 0f), Color.white, 2);
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.85f, 0.16f, 1f), new Vector3(0f, -0.16f, 0f), Color.white, 2);
                break;

            case SpecialCandyType.StripedVertical:
                // Kẹo Sọc Dọc: 2 vạch dọc trắng sáng
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.16f, 0.85f, 1f), new Vector3(-0.16f, 0f, 0f), Color.white, 2);
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.16f, 0.85f, 1f), new Vector3(0.16f, 0f, 0f), Color.white, 2);
                break;

            case SpecialCandyType.Wrapped:
                // Kẹo Gói: Lớp vỏ bọc phát sáng phía sau + tâm vuông ở giữa
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(1.22f, 1.22f, 1f), Vector3.zero, new Color(1f, 0.85f, 0.3f, 0.55f), -1);
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.45f, 0.45f, 1f), Vector3.zero, new Color(1f, 1f, 1f, 0.9f), 2);
                break;

            case SpecialCandyType.ColorBomb:
                // Bom Màu: Lõi ngôi sao chữ thập trắng ở tâm
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.85f, 0.22f, 1f), Vector3.zero, Color.white, 2);
                CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.22f, 0.85f, 1f), Vector3.zero, Color.white, 2);
                break;

            case SpecialCandyType.SugarFish:
                // Kẹo Cá 2x2: Biểu tượng hình thoi xoay 45 độ ở giữa
                GameObject fishIcon = CreateOverlayBar(proceduralBadgeRoot.transform, new Vector3(0.55f, 0.55f, 1f), Vector3.zero, Color.white, 2);
                fishIcon.transform.localRotation = Quaternion.Euler(0f, 0f, 45f);
                break;
        }
    }

    /// <summary>
    /// Bảng màu nền trung tính cố định cho từng loại Kẹo Đặc Biệt (không trùng với màu kẹo thường).
    /// </summary>
    private Color GetNeutralBaseColor(SpecialCandyType type)
    {
        switch (type)
        {
            case SpecialCandyType.StripedHorizontal:
            case SpecialCandyType.StripedVertical:
                return new Color(0.75f, 0.85f, 0.95f, 1f); // Bạc ánh kim
            case SpecialCandyType.Wrapped:
                return new Color(0.95f, 0.78f, 0.45f, 1f); // Vàng đồng trung tính
            case SpecialCandyType.SugarFish:
                return new Color(0.45f, 0.90f, 0.85f, 1f); // Ngọc lam trung tính
            case SpecialCandyType.ColorBomb:
            default:
                return Color.white;
        }
    }

    private GameObject CreateOverlayBar(Transform parent, Vector3 localScale, Vector3 localPos, Color color, int sortingOffset)
    {
        GameObject bar = new GameObject("Indicator");
        bar.transform.SetParent(parent, false);
        bar.transform.localPosition = localPos;
        bar.transform.localScale = localScale;

        SpriteRenderer sr = bar.AddComponent<SpriteRenderer>();
        sr.sprite = mainRenderer.sprite;
        sr.color = color;
        sr.sortingLayerID = mainRenderer.sortingLayerID;
        sr.sortingOrder = mainRenderer.sortingOrder + sortingOffset;
        return bar;
    }

    /// <summary>
    /// Tạo một Sprite hình tròn bo mượt dùng chung trong bộ nhớ cho mọi Kẹo Đặc Biệt,
    /// giúp các Kẹo Đặc Biệt có cùng kích thước và hình dáng bất kể Prefab gốc là hình gì.
    /// </summary>
    private static Sprite GetOrCreateSharedNeutralSprite()
    {
        if (sharedNeutralSprite != null)
        {
            return sharedNeutralSprite;
        }

        const int size = 64;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;

        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float maxRadius = size * 0.45f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dist = Vector2.Distance(new Vector2(x, y), center);
                if (dist <= maxRadius)
                {
                    // Làm mềm viền ngoài (Anti-aliasing) và tạo độ bóng nhẹ ở tâm
                    float edgeAlpha = Mathf.Clamp01((maxRadius - dist) * 0.5f);
                    float highlight = Mathf.Lerp(1f, 0.82f, dist / maxRadius);
                    tex.SetPixel(x, y, new Color(highlight, highlight, highlight, edgeAlpha));
                }
                else
                {
                    tex.SetPixel(x, y, Color.clear);
                }
            }
        }

        tex.Apply();
        sharedNeutralSprite = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 64f);
        return sharedNeutralSprite;
    }
}