using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Bộ điều phối trung tâm của Gameplay Match-3:
/// - Quản lý duy nhất luồng dữ liệu qua LevelGoalTracker (Điểm, Lượt đi, Mục tiêu LevelData).
/// - Đồng bộ trực tiếp với Match3UIManager và xử lý cả 4 kỹ năng Booster.
/// </summary>
public class GameManager : MonoBehaviour
{
    [Header("Board Reference")]
    [Tooltip("Có thể để trống để GameManager tự nhận Board đã dựng xong.")]
    [SerializeField] private Board board;

    [Header("Animation & Physics Speed")]
    [Min(0.05f)] public float swapDuration = 0.15f;
    [Min(0.05f)] public float fallDuration = 0.12f;
    [Min(2f)] public float fallSpeedUnitsPerSecond = 13f;
    [Min(0f)] public float matchPause = 0.08f;

    [Header("Touch / Swipe")]
    [Min(5f)] public float swipeThresholdPixels = 35f;

    [Header("Move Hint")]
    [Min(1f)] public float hintAfterSeconds = 5f;
    [Min(1f)] public float hintScaleMultiplier = 1.15f;
    [Min(0.1f)] public float hintPulseDuration = 0.7f;
    [Min(0f)] public float hintPauseDuration = 0.25f;

    [Header("Debug UI")]
    [Tooltip("Bật nếu muốn xem thêm hộp thông tin IMGUI phụ ở góc màn hình.")]
    [SerializeField] private bool showDebugHUD = false;

    private GameObject[] candyPrefabs;
    private MatchFinder matchFinder;
    private SpecialCandyProcessor specialProcessor;
    private InputController inputController;
    public LevelGoalTracker GoalTracker { get; private set; }

    private bool isReady;
    private bool isProcessing;
    private bool isInitialized;

    public bool IsBusy => !isReady || isProcessing || (GoalTracker != null && GoalTracker.IsGameOver);

    private float idleTime;
    private Coroutine hintCoroutine;
    private Transform hintedTransformA;
    private Transform hintedTransformB;
    private Vector3 hintedScaleA;
    private Vector3 hintedScaleB;

    private struct HintMove
    {
        public BackgroundTiile first;
        public BackgroundTiile second;

        public HintMove(BackgroundTiile first, BackgroundTiile second)
        {
            this.first = first;
            this.second = second;
        }
    }

    private struct MovingCandy
    {
        public Candy candy;
        public Vector3 from;
        public Vector3 to;
        public float duration;

        public MovingCandy(Candy candy, Vector3 from, Vector3 to, float speedUnitsPerSec, float minDuration)
        {
            this.candy = candy;
            this.from = from;
            this.to = to;
            float distance = Vector3.Distance(from, to);
            this.duration = Mathf.Max(minDuration, distance / Mathf.Max(1f, speedUnitsPerSec));
        }
    }

    public void Initialize(Board boardToManage)
    {
        if (isInitialized)
        {
            return;
        }

        if (boardToManage == null)
        {
            Debug.LogError("GameManager cần một Board hợp lệ.", this);
            return;
        }

        board = boardToManage;
        if (!ValidateSetup())
        {
            return;
        }

        matchFinder = new MatchFinder(board);
        specialProcessor = new SpecialCandyProcessor(board);
        GoalTracker = new LevelGoalTracker();
        GoalTracker.Initialize(board.CurrentLevelData, board.ActiveObstacleCount);

        inputController = new InputController(
            board,
            swipeThresholdPixels,
            OnSwapRequestedByInput,
            ResetIdleTimerAndHint);

        SpawnStartingCandies();

        if (!HasPossibleMove())
        {
            InstantEnsurePlayableBoard();
        }

        isReady = true;
        isInitialized = true;
    }

    private bool ValidateSetup()
    {
        if (board.Tiles == null)
        {
            Debug.LogError("Board chưa tạo lưới.", this);
            return false;
        }

        candyPrefabs = board.GetActiveCandyPrefabs();
        if (candyPrefabs == null || candyPrefabs.Length < 3)
        {
            Debug.LogError("Cần ít nhất 3 Candy Prefab để khởi chạy GameManager.", this);
            return false;
        }

        if (Camera.main == null)
        {
            Debug.LogError("Không tìm thấy Main Camera. Hãy gắn tag MainCamera cho Camera.", this);
            return false;
        }

        return true;
    }

    private void SpawnStartingCandies()
    {
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile cell = board.PlayableTiles[i];
            int typeIndex = GetStartingCandyType(cell.X, cell.Y);
            cell.CreateCandy(typeIndex, cell.transform.position, true, SpecialCandyType.None);
        }
    }

    private int GetStartingCandyType(int x, int y)
    {
        List<int> availableTypes = new List<int>();

        for (int type = 0; type < candyPrefabs.Length; type++)
        {
            bool horizontalMatch = board.GetCandyTypeAt(x - 1, y) == type
                && board.GetCandyTypeAt(x - 2, y) == type;

            bool verticalMatch = board.GetCandyTypeAt(x, y - 1) == type
                && board.GetCandyTypeAt(x, y - 2) == type;

            bool squareMatch = board.GetCandyTypeAt(x - 1, y) == type
                && board.GetCandyTypeAt(x, y - 1) == type
                && board.GetCandyTypeAt(x - 1, y - 1) == type;

            if (!horizontalMatch && !verticalMatch && !squareMatch)
            {
                availableTypes.Add(type);
            }
        }

        if (availableTypes.Count == 0)
        {
            return Random.Range(0, candyPrefabs.Length);
        }

        return availableTypes[Random.Range(0, availableTypes.Count)];
    }

    private void Update()
    {
        if (!isReady || GoalTracker == null || GoalTracker.IsGameOver)
        {
            StopMoveHint();
            return;
        }

        if (isProcessing)
        {
            idleTime = 0f;
            return;
        }

        // Nếu người chơi đang bật chế độ chọn ô của Booster (Búa / Đổi chỗ / Bom màu), tạm ngắt vuốt thường
        if (Match3UIManager.Instance != null && Match3UIManager.Instance.ActiveBooster != BoosterType.None)
        {
            idleTime = 0f;
            return;
        }

        inputController.ProcessInput();

        idleTime += Time.deltaTime;
        if (idleTime >= hintAfterSeconds && hintCoroutine == null)
        {
            ShowMoveHint();
        }
    }

    private void OnSwapRequestedByInput(BackgroundTiile first, BackgroundTiile second)
    {
        if (IsBusy)
        {
            return;
        }

        StartCoroutine(SwapAndResolve(first, second));
    }

    // =========================================================================================
    // PHẦN 1: XỬ LÝ VUỐT ĐỔI CHỖ & CHUỖI NỔ DÂY CHUYỀN (CASCADE)
    // =========================================================================================

    private IEnumerator SwapAndResolve(BackgroundTiile first, BackgroundTiile second)
    {
        if (first == null || second == null || first.CurrentCandy == null || second.CurrentCandy == null)
        {
            yield break;
        }

        if (Mathf.Abs(first.X - second.X) + Mathf.Abs(first.Y - second.Y) != 1)
        {
            yield break;
        }

        isProcessing = true;
        ResetIdleTimerAndHint();

        yield return StartCoroutine(SwapCellsAnimation(first, second));

        bool isDirectSpecialCombo = specialProcessor.CanTriggerDirectSpecialSwap(first, second);
        List<MatchGroup> matchGroups = matchFinder.FindAllMatchGroups(first, second);

        if (!isDirectSpecialCombo && matchGroups.Count == 0)
        {
            yield return StartCoroutine(SwapCellsAnimation(first, second));
            isProcessing = false;
            yield break;
        }

        // Nước đi hợp lệ -> Trừ 1 lượt trong GoalTracker và làm mới bộ đếm khen ngợi Combo
        Match3UIManager.Instance?.ResetCascadePraiseCounter();
        GoalTracker.ConsumeMove();

        int cascadeMultiplier = 1;

        if (isDirectSpecialCombo)
        {
            HashSet<BackgroundTiile> comboCells = new HashSet<BackgroundTiile>();
            HashSet<Vector2Int> blastedCoords = new HashSet<Vector2Int>();

            specialProcessor.CollectDirectSpecialCombo(first, second, comboCells, blastedCoords);
            ExecuteClearAndDamageObstacles(comboCells, blastedCoords, null, cascadeMultiplier);

            if (matchPause > 0f)
            {
                yield return new WaitForSeconds(matchPause);
            }

            yield return StartCoroutine(CollapseAndRefillBoard());
            matchGroups = matchFinder.FindAllMatchGroups();
            cascadeMultiplier++;
        }

        yield return StartCoroutine(ResolveCascadeLoop(matchGroups, cascadeMultiplier));
        isProcessing = false;
    }

    /// <summary>
    /// Vòng lặp xử lý nổ dây chuyền, rơi kẹo, đánh giá Thắng/Thua và tự động xáo trộn nếu hết nước đi.
    /// Dùng chung cho cả thao tác vuốt thường lẫn sau khi dùng Booster.
    /// </summary>
    private IEnumerator ResolveCascadeLoop(List<MatchGroup> initialGroups, int startMultiplier)
    {
        List<MatchGroup> matchGroups = initialGroups;
        int cascadeMultiplier = startMultiplier;

        while (matchGroups != null && matchGroups.Count > 0)
        {
            ResolveMatchGroupsStep(matchGroups, cascadeMultiplier);

            if (matchPause > 0f)
            {
                yield return new WaitForSeconds(matchPause);
            }

            yield return StartCoroutine(CollapseAndRefillBoard());

            matchGroups = matchFinder.FindAllMatchGroups();
            cascadeMultiplier++;
        }

        GoalTracker.EvaluateEndOfTurnState();

        if (!GoalTracker.IsGameOver && !HasPossibleMove())
        {
            yield return StartCoroutine(ReshuffleBoardSmooth());
        }
    }

    // =========================================================================================
    // PHẦN 2: THỰC THI 4 KỸ NĂNG BOOSTER ĐỒNG BỘ 100% VỚI GOALTRACKER
    // =========================================================================================

    public bool TryExecuteHammerBooster(int x, int y)
    {
        if (IsBusy) return false;

        ObstacleTile obs = board.GetObstacle(x, y);
        BackgroundTiile tile = board.GetTile(x, y);

        if (obs == null && (tile == null || tile.CurrentCandy == null))
        {
            return false;
        }

        StartCoroutine(HammerBoosterRoutine(x, y, obs, tile));
        return true;
    }

    private IEnumerator HammerBoosterRoutine(int x, int y, ObstacleTile obs, BackgroundTiile tile)
    {
        isProcessing = true;
        ResetIdleTimerAndHint();
        Match3UIManager.Instance?.ResetCascadePraiseCounter();

        Vector2 targetWorldPos = board.GetCellPosition(x, y);
        Match3VFXManager.Instance?.PlayHammerSmash(targetWorldPos, board);
        yield return new WaitForSeconds(0.14f);

        if (obs != null)
        {
            if (board.DamageObstacleAt(x, y, 99))
            {
                GoalTracker.RecordObstacleCleared(1);
                GoalTracker.AddScore(100);
                Match3UIManager.Instance?.OnBoardObstacleCleared(targetWorldPos, 100);
            }
        }
        else if (tile != null && tile.CurrentCandy != null)
        {
            HashSet<BackgroundTiile> cellsToClear = new HashSet<BackgroundTiile> { tile };
            HashSet<Vector2Int> blastedCoords = new HashSet<Vector2Int> { new Vector2Int(x, y) };

            specialProcessor.ExpandSpecialChainReactions(cellsToClear, blastedCoords);
            ExecuteClearAndDamageObstacles(cellsToClear, blastedCoords, null, 1);
        }

        if (matchPause > 0f) yield return new WaitForSeconds(matchPause);
        yield return StartCoroutine(CollapseAndRefillBoard());

        List<MatchGroup> groups = matchFinder.FindAllMatchGroups();
        yield return StartCoroutine(ResolveCascadeLoop(groups, 1));
        isProcessing = false;
    }

    public bool TryExecuteFreeSwapBooster(BackgroundTiile tileA, BackgroundTiile tileB)
    {
        if (IsBusy || tileA?.CurrentCandy == null || tileB?.CurrentCandy == null) return false;
        if (Mathf.Abs(tileA.X - tileB.X) + Mathf.Abs(tileA.Y - tileB.Y) != 1) return false;

        StartCoroutine(FreeSwapBoosterRoutine(tileA, tileB));
        return true;
    }

    private IEnumerator FreeSwapBoosterRoutine(BackgroundTiile first, BackgroundTiile second)
    {
        isProcessing = true;
        ResetIdleTimerAndHint();
        Match3UIManager.Instance?.ResetCascadePraiseCounter();

        // Đổi chỗ cưỡng chế (không hoàn tác ngay cả khi không tạo thành Match)
        yield return StartCoroutine(SwapCellsAnimation(first, second));

        int cascadeMultiplier = 1;
        if (specialProcessor.CanTriggerDirectSpecialSwap(first, second))
        {
            HashSet<BackgroundTiile> comboCells = new HashSet<BackgroundTiile>();
            HashSet<Vector2Int> blastedCoords = new HashSet<Vector2Int>();

            specialProcessor.CollectDirectSpecialCombo(first, second, comboCells, blastedCoords);
            ExecuteClearAndDamageObstacles(comboCells, blastedCoords, null, cascadeMultiplier);

            if (matchPause > 0f) yield return new WaitForSeconds(matchPause);
            yield return StartCoroutine(CollapseAndRefillBoard());
            cascadeMultiplier++;
        }

        List<MatchGroup> groups = matchFinder.FindAllMatchGroups(first, second);
        yield return StartCoroutine(ResolveCascadeLoop(groups, cascadeMultiplier));
        isProcessing = false;
    }

    public bool TryExecuteColorBombBooster(int x, int y)
    {
        if (IsBusy) return false;
        BackgroundTiile tile = board.GetTile(x, y);
        if (tile == null || tile.CurrentCandy == null || tile.CurrentCandy.SpecialType == SpecialCandyType.ColorBomb)
        {
            return false;
        }

        ResetIdleTimerAndHint();
        tile.CurrentCandy.SetSpecialType(SpecialCandyType.ColorBomb);
        Match3VFXManager.Instance?.PlayBubblePop(tile.transform.position, -1, board.CellSize * 1.3f);
        return true;
    }

    public bool TryExecuteShuffleBooster()
    {
        if (IsBusy) return false;
        StartCoroutine(ReshuffleBoardSmooth());
        return true;
    }

    // =========================================================================================
    // PHẦN 3: XÓA KẸO, SÁT THƯƠNG VẬT CẢN, RƠI & TRƯỢT CHÉO
    // =========================================================================================

    private void ResolveMatchGroupsStep(List<MatchGroup> matchGroups, int cascadeMultiplier)
    {
        HashSet<BackgroundTiile> allCellsToClear = new HashSet<BackgroundTiile>();
        HashSet<Vector2Int> blastedCoords = new HashSet<Vector2Int>();
        Dictionary<BackgroundTiile, (int typeIndex, SpecialCandyType specialType)> specialsToSpawn
            = new Dictionary<BackgroundTiile, (int, SpecialCandyType)>();

        for (int i = 0; i < matchGroups.Count; i++)
        {
            MatchGroup group = matchGroups[i];
            for (int c = 0; c < group.Cells.Count; c++)
            {
                allCellsToClear.Add(group.Cells[c]);
            }

            if (group.SpawnedSpecialType != SpecialCandyType.None && group.SpawnCell != null)
            {
                specialsToSpawn[group.SpawnCell] = (group.CandyType, group.SpawnedSpecialType);
            }
        }

        specialProcessor.ExpandSpecialChainReactions(allCellsToClear, blastedCoords);
        ExecuteClearAndDamageObstacles(allCellsToClear, blastedCoords, specialsToSpawn, cascadeMultiplier);
    }

    private void ExecuteClearAndDamageObstacles(
        HashSet<BackgroundTiile> cellsToClear,
        HashSet<Vector2Int> blastedCoords,
        Dictionary<BackgroundTiile, (int typeIndex, SpecialCandyType specialType)> specialsToSpawn,
        int cascadeMultiplier)
    {
        HashSet<Vector2Int> obstacleDamageCoords = new HashSet<Vector2Int>(blastedCoords);

        foreach (BackgroundTiile cell in cellsToClear)
        {
            if (cell == null) continue;

            obstacleDamageCoords.Add(new Vector2Int(cell.X + 1, cell.Y));
            obstacleDamageCoords.Add(new Vector2Int(cell.X - 1, cell.Y));
            obstacleDamageCoords.Add(new Vector2Int(cell.X, cell.Y + 1));
            obstacleDamageCoords.Add(new Vector2Int(cell.X, cell.Y - 1));

            if (cell.CurrentCandy != null)
            {
                Candy candy = cell.CurrentCandy;
                Vector3 candyWorldPos = candy.transform.position;
                int collectedColorIndex = candy.TypeIndex;
                SpecialCandyType spType = candy.SpecialType;
                int pts = 20 * cascadeMultiplier;

                GoalTracker.RecordCandyCollected(collectedColorIndex, 1);
                GoalTracker.AddScore(pts);

                Match3UIManager.Instance?.OnBoardCandyCleared(candyWorldPos, collectedColorIndex, spType, pts);

                cell.SetCandy(null, false);
                board.Pool.ReleaseCandy(candy);
            }
        }

        if (specialsToSpawn != null)
        {
            foreach (var kvp in specialsToSpawn)
            {
                BackgroundTiile spawnCell = kvp.Key;
                int candyType = kvp.Value.typeIndex;
                SpecialCandyType specialType = kvp.Value.specialType;

                if (spawnCell != null && spawnCell.CurrentCandy == null)
                {
                    spawnCell.CreateCandy(candyType, spawnCell.transform.position, true, specialType);
                    GoalTracker.AddScore(50 * cascadeMultiplier);
                }
            }
        }

        foreach (Vector2Int pos in obstacleDamageCoords)
        {
            Vector2 obsWorldPos = board.GetCellPosition(pos.x, pos.y);
            if (board.DamageObstacleAt(pos.x, pos.y, 1))
            {
                int obsPts = 100 * cascadeMultiplier;
                GoalTracker.RecordObstacleCleared(1);
                GoalTracker.AddScore(obsPts);
                Match3UIManager.Instance?.OnBoardObstacleCleared(obsWorldPos, obsPts);
            }
        }
    }

    private IEnumerator CollapseAndRefillBoard()
    {
        List<MovingCandy> collapseMovements = CalculateGravityAndDiagonalSlide();
        if (collapseMovements.Count > 0)
        {
            yield return StartCoroutine(AnimateMovements(collapseMovements));
        }

        List<MovingCandy> refillMovements = SpawnCandiesForEmptyCells();
        if (refillMovements.Count > 0)
        {
            yield return StartCoroutine(AnimateMovements(refillMovements));
        }
    }

    private List<MovingCandy> CalculateGravityAndDiagonalSlide()
    {
        Dictionary<Candy, Vector3> startPositions = new Dictionary<Candy, Vector3>();
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            Candy c = board.PlayableTiles[i].CurrentCandy;
            if (c != null)
            {
                startPositions[c] = c.transform.position;
            }
        }

        bool movedAny;
        do
        {
            movedAny = false;

            for (int x = 0; x < board.Width; x++)
            {
                for (int y = 0; y < board.Height; y++)
                {
                    BackgroundTiile targetCell = board.GetTile(x, y);
                    if (targetCell == null || targetCell.CurrentCandy != null) continue;

                    for (int sourceY = y + 1; sourceY < board.Height; sourceY++)
                    {
                        BackgroundTiile checkCell = board.GetTile(x, sourceY);
                        if (checkCell == null) break;

                        if (checkCell.CurrentCandy != null)
                        {
                            Candy fallingCandy = checkCell.CurrentCandy;
                            checkCell.SetCandy(null, false);
                            targetCell.SetCandy(fallingCandy, false);
                            movedAny = true;
                            break;
                        }
                    }
                }
            }

            for (int y = 0; y < board.Height - 1; y++)
            {
                for (int x = 0; x < board.Width; x++)
                {
                    BackgroundTiile emptyCell = board.GetTile(x, y);
                    if (emptyCell == null || emptyCell.CurrentCandy != null) continue;

                    if (board.GetTile(x, y + 1) == null)
                    {
                        BackgroundTiile diagLeft = board.GetTile(x - 1, y + 1);
                        BackgroundTiile diagRight = board.GetTile(x + 1, y + 1);

                        BackgroundTiile chosenDiag = null;
                        if (diagLeft != null && diagLeft.CurrentCandy != null) chosenDiag = diagLeft;
                        else if (diagRight != null && diagRight.CurrentCandy != null) chosenDiag = diagRight;

                        if (chosenDiag != null)
                        {
                            Candy slidingCandy = chosenDiag.CurrentCandy;
                            chosenDiag.SetCandy(null, false);
                            emptyCell.SetCandy(slidingCandy, false);
                            movedAny = true;
                        }
                    }
                }
            }
        } while (movedAny);

        List<MovingCandy> movements = new List<MovingCandy>();
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile cell = board.PlayableTiles[i];
            Candy candy = cell.CurrentCandy;
            if (candy != null && startPositions.TryGetValue(candy, out Vector3 startPos))
            {
                if ((startPos - cell.transform.position).sqrMagnitude > 0.0001f)
                {
                    movements.Add(new MovingCandy(
                        candy,
                        startPos,
                        cell.transform.position,
                        fallSpeedUnitsPerSecond * board.CellSize,
                        fallDuration));
                }
            }
        }

        return movements;
    }

    private List<MovingCandy> SpawnCandiesForEmptyCells()
    {
        List<MovingCandy> movements = new List<MovingCandy>();

        for (int x = 0; x < board.Width; x++)
        {
            int spawnOffset = 0;
            for (int y = 0; y < board.Height; y++)
            {
                BackgroundTiile cell = board.GetTile(x, y);
                if (cell == null || cell.CurrentCandy != null)
                {
                    continue;
                }

                int typeIndex = Random.Range(0, candyPrefabs.Length);
                Vector2 targetPos = cell.transform.position;
                Vector2 topOfColumn = board.GetCellPosition(x, board.Height);
                Vector2 spawnPos = new Vector2(targetPos.x, topOfColumn.y + (0.5f + spawnOffset) * board.CellSize);
                spawnOffset++;

                Candy newCandy = cell.CreateCandy(typeIndex, spawnPos, false, SpecialCandyType.None);
                if (newCandy != null)
                {
                    movements.Add(new MovingCandy(
                        newCandy,
                        spawnPos,
                        targetPos,
                        fallSpeedUnitsPerSecond * board.CellSize,
                        fallDuration));
                }
            }
        }

        return movements;
    }

    private IEnumerator SwapCellsAnimation(BackgroundTiile cellA, BackgroundTiile cellB)
    {
        Candy candyA = cellA.CurrentCandy;
        Candy candyB = cellB.CurrentCandy;
        if (candyA == null || candyB == null)
        {
            yield break;
        }

        Vector3 startA = candyA.transform.position;
        Vector3 startB = candyB.transform.position;

        cellA.SetCandy(candyB, false);
        cellB.SetCandy(candyA, false);

        List<MovingCandy> movements = new List<MovingCandy>
        {
            new MovingCandy(candyA, startA, cellB.transform.position, 100f, swapDuration),
            new MovingCandy(candyB, startB, cellA.transform.position, 100f, swapDuration)
        };

        yield return StartCoroutine(AnimateMovements(movements));
    }

    // =========================================================================================
    // PHẦN 4: TÌM NƯỚC ĐI HỢP LỆ, GỢI Ý & XÁO TRỘN CHỐNG KẸT
    // =========================================================================================

    private List<HintMove> FindPossibleMoves()
    {
        List<HintMove> possibleMoves = new List<HintMove>();

        for (int x = 0; x < board.Width; x++)
        {
            for (int y = 0; y < board.Height; y++)
            {
                BackgroundTiile cell = board.GetTile(x, y);
                if (cell == null || cell.CurrentCandy == null) continue;

                if (x + 1 < board.Width)
                {
                    BackgroundTiile rightCell = board.GetTile(x + 1, y);
                    if (SwapWouldCreateMatchFast(cell, rightCell))
                    {
                        possibleMoves.Add(new HintMove(cell, rightCell));
                    }
                }

                if (y + 1 < board.Height)
                {
                    BackgroundTiile upperCell = board.GetTile(x, y + 1);
                    if (SwapWouldCreateMatchFast(cell, upperCell))
                    {
                        possibleMoves.Add(new HintMove(cell, upperCell));
                    }
                }
            }
        }

        return possibleMoves;
    }

    private bool HasPossibleMove()
    {
        for (int x = 0; x < board.Width; x++)
        {
            for (int y = 0; y < board.Height; y++)
            {
                BackgroundTiile cell = board.GetTile(x, y);
                if (cell == null || cell.CurrentCandy == null) continue;

                if (x + 1 < board.Width && SwapWouldCreateMatchFast(cell, board.GetTile(x + 1, y)))
                {
                    return true;
                }

                if (y + 1 < board.Height && SwapWouldCreateMatchFast(cell, board.GetTile(x, y + 1)))
                {
                    return true;
                }
            }
        }

        return false;
    }

    private bool SwapWouldCreateMatchFast(BackgroundTiile cellA, BackgroundTiile cellB)
    {
        if (cellA == null || cellB == null || cellA.CurrentCandy == null || cellB.CurrentCandy == null)
        {
            return false;
        }

        if (specialProcessor.CanTriggerDirectSpecialSwap(cellA, cellB))
        {
            return true;
        }

        Candy candyA = cellA.CurrentCandy;
        Candy candyB = cellB.CurrentCandy;

        if (!candyA.IsNeutralSpecial && !candyB.IsNeutralSpecial && candyA.TypeIndex == candyB.TypeIndex)
        {
            return false;
        }

        cellA.AssignCandyLogical(candyB);
        cellB.AssignCandyLogical(candyA);

        bool createsMatch = matchFinder.HasMatchAt(cellA.X, cellA.Y)
                         || matchFinder.HasMatchAt(cellB.X, cellB.Y);

        cellA.AssignCandyLogical(candyA);
        cellB.AssignCandyLogical(candyB);

        return createsMatch;
    }

    public IEnumerator ReshuffleBoardSmooth()
    {
        isProcessing = true;
        ResetIdleTimerAndHint();
        if (Match3VFXManager.Instance != null) Match3VFXManager.Instance.SuppressVFX = true;

        Dictionary<Candy, Vector3> originalPositions = new Dictionary<Candy, Vector3>();
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            Candy c = board.PlayableTiles[i].CurrentCandy;
            if (c != null)
            {
                originalPositions[c] = c.transform.position;
            }
        }

        InstantEnsurePlayableBoard();

        List<MovingCandy> movements = new List<MovingCandy>();
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile targetCell = board.PlayableTiles[i];
            Candy candy = targetCell.CurrentCandy;
            if (candy != null)
            {
                Vector3 fromPos = originalPositions.TryGetValue(candy, out Vector3 savedPos)
                    ? savedPos
                    : targetCell.transform.position;
                movements.Add(new MovingCandy(candy, fromPos, targetCell.transform.position, fallSpeedUnitsPerSecond * board.CellSize, swapDuration * 1.5f));
            }
        }

        yield return StartCoroutine(AnimateMovements(movements));
        if (Match3VFXManager.Instance != null) Match3VFXManager.Instance.SuppressVFX = false;
        isProcessing = false;
    }

    private void InstantEnsurePlayableBoard()
    {
        List<Candy> candies = new List<Candy>(board.PlayableTiles.Count);
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            if (board.PlayableTiles[i].CurrentCandy != null)
            {
                candies.Add(board.PlayableTiles[i].CurrentCandy);
            }
        }

        if (candies.Count != board.PlayableTiles.Count)
        {
            return;
        }

        const int maxFastAttempts = 200;
        for (int attempt = 0; attempt < maxFastAttempts; attempt++)
        {
            for (int i = candies.Count - 1; i > 0; i--)
            {
                int rnd = Random.Range(0, i + 1);
                Candy temp = candies[i];
                candies[i] = candies[rnd];
                candies[rnd] = temp;
            }

            for (int i = 0; i < board.PlayableTiles.Count; i++)
            {
                board.PlayableTiles[i].AssignCandyLogical(candies[i]);
            }

            if (!matchFinder.HasAnyMatchOnBoard() && HasPossibleMove())
            {
                return;
            }
        }

        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile cell = board.PlayableTiles[i];
            Candy oldCandy = cell.CurrentCandy;
            if (oldCandy != null)
            {
                board.Pool.ReleaseCandy(oldCandy);
                cell.AssignCandyLogical(null);
            }
        }

        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile cell = board.PlayableTiles[i];
            int safeType = GetStartingCandyType(cell.X, cell.Y);
            SpecialCandyType sp = (i == 0) ? SpecialCandyType.ColorBomb : SpecialCandyType.None;
            cell.CreateCandy(safeType, cell.transform.position, false, sp);
        }
    }

    private void ResetIdleTimerAndHint()
    {
        idleTime = 0f;
        StopMoveHint();
    }

    private void ShowMoveHint()
    {
        List<HintMove> possibleMoves = FindPossibleMoves();
        if (possibleMoves.Count == 0)
        {
            StartCoroutine(ReshuffleBoardSmooth());
            return;
        }

        HintMove selectedMove = possibleMoves[Random.Range(0, possibleMoves.Count)];
        Candy candyA = selectedMove.first != null ? selectedMove.first.CurrentCandy : null;
        Candy candyB = selectedMove.second != null ? selectedMove.second.CurrentCandy : null;
        if (candyA == null || candyB == null)
        {
            return;
        }

        hintedTransformA = candyA.transform;
        hintedTransformB = candyB.transform;
        hintedScaleA = candyA.GetBaseScale();
        hintedScaleB = candyB.GetBaseScale();
        hintCoroutine = StartCoroutine(AnimateMoveHint());
    }

    private IEnumerator AnimateMoveHint()
    {
        while (hintedTransformA != null && hintedTransformB != null)
        {
            float elapsed = 0f;
            while (elapsed < hintPulseDuration)
            {
                if (hintedTransformA == null || hintedTransformB == null) yield break;

                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / hintPulseDuration);
                float pulse = Mathf.Sin(t * Mathf.PI);
                float scale = Mathf.Lerp(1f, hintScaleMultiplier, pulse);

                hintedTransformA.localScale = hintedScaleA * scale;
                hintedTransformB.localScale = hintedScaleB * scale;
                yield return null;
            }

            if (hintedTransformA != null) hintedTransformA.localScale = hintedScaleA;
            if (hintedTransformB != null) hintedTransformB.localScale = hintedScaleB;

            if (hintPauseDuration > 0f)
            {
                yield return new WaitForSeconds(hintPauseDuration);
            }
        }
    }

    private void StopMoveHint()
    {
        if (hintCoroutine != null)
        {
            StopCoroutine(hintCoroutine);
            hintCoroutine = null;
        }

        if (hintedTransformA != null) hintedTransformA.localScale = hintedScaleA;
        if (hintedTransformB != null) hintedTransformB.localScale = hintedScaleB;
        hintedTransformA = null;
        hintedTransformB = null;
    }

    private void OnApplicationPause(bool isPaused)
    {
        if (isPaused)
        {
            ResetIdleTimerAndHint();
            inputController?.ResetState();
        }
    }

    private void OnApplicationFocus(bool hasFocus)
    {
        if (!hasFocus)
        {
            ResetIdleTimerAndHint();
            inputController?.ResetState();
        }
    }

    private IEnumerator AnimateMovements(List<MovingCandy> movements)
    {
        if (movements == null || movements.Count == 0)
        {
            yield break;
        }

        float maxDuration = 0f;
        for (int i = 0; i < movements.Count; i++)
        {
            if (movements[i].duration > maxDuration)
            {
                maxDuration = movements[i].duration;
            }
        }

        float elapsed = 0f;
        while (elapsed < maxDuration)
        {
            elapsed += Time.deltaTime;

            for (int i = 0; i < movements.Count; i++)
            {
                MovingCandy mv = movements[i];
                if (mv.candy == null) continue;

                float t = mv.duration > 0f ? Mathf.Clamp01(elapsed / mv.duration) : 1f;
                float easedT = t * t * (3f - 2f * t);
                mv.candy.transform.position = Vector3.Lerp(mv.from, mv.to, easedT);
            }

            yield return null;
        }

        for (int i = 0; i < movements.Count; i++)
        {
            if (movements[i].candy != null)
            {
                movements[i].candy.transform.position = movements[i].to;
            }
        }
    }

    private void OnGUI()
    {
        if (!showDebugHUD || !isReady || GoalTracker == null)
        {
            return;
        }

        GUIStyle boxStyle = new GUIStyle(GUI.skin.box) { fontSize = 14, alignment = TextAnchor.UpperLeft };
        string levelName = board.CurrentLevelData != null ? board.CurrentLevelData.DisplayName : "Custom Board";
        string status = GoalTracker.IsGameOver
            ? (GoalTracker.IsLevelWon ? " [THẮNG MÀN!]" : " [HẾT LƯỢT!]")
            : "";

        string info = $"{levelName}{status}\n" +
                      $"Điểm: {GoalTracker.CurrentScore} | Lượt còn: {GoalTracker.MovesRemaining}\n";

        for (int i = 0; i < GoalTracker.Goals.Count; i++)
        {
            var g = GoalTracker.Goals[i];
            string check = g.IsCompleted ? "[X]" : "[ ]";
            info += $"{check} {g.GoalType}: {g.CurrentAmount}/{g.TargetAmount}\n";
        }

        GUI.Box(new Rect(12, 12, 290, 95 + GoalTracker.Goals.Count * 20), info, boxStyle);
    }
}