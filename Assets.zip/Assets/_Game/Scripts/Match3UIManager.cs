﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

/// <summary>
/// Các loại kỹ năng trợ giúp (Booster) ở thanh dưới màn hình.
/// </summary>
public enum BoosterType
{
    None = 0,
    Hammer = 1,     // Búa Phá: Chạm vào 1 ô bất kỳ để đập vỡ kẹo hoặc vật cản ngay lập tức
    FreeSwap = 2,   // Đổi Chỗ: Chạm 2 viên kẹo kề nhau (hoặc kéo viên 1 sang viên 2) để đổi chỗ tự do
    ColorBomb = 3,  // Bom Màu: Chạm vào 1 viên kẹo bất kỳ để nâng cấp nó thành Bom Màu
    Shuffle = 4     // Xáo Trộn: Xáo trộn ngay toàn bộ kẹo trên bàn cờ
}

/// <summary>
/// Quản lý giao diện chính thức của màn chơi Match-3 (Gắn trực tiếp vào Canvas cha):
/// - Top HUD chỉ hiển thị Thanh Tiến Trình 3 Sao (không hiển thị con số điểm).
/// - Nếu Goal chỉ là ReachScore: Chỉ hiện Thanh Tiến Trình Sao (mở rộng) và Lượt Đi.
/// - Nếu Goal có CollectCandy / ClearObstacles: Hiện cả Thanh Tiến Trình Sao và Ô Kẹo/Vật cản cần thu thập.
/// - Sửa triệt để lỗi chặn Raycast khiến người chơi không chọn được kẹo khi dùng Búa Phá / Đổi Chỗ / Bom Màu.
/// </summary>
[DisallowMultipleComponent]
public class Match3UIManager : MonoBehaviour
{
    public static Match3UIManager Instance { get; private set; }

    public const float TOP_HUD_SCREEN_RATIO = 0.145f;
    public const float BOTTOM_HUD_SCREEN_RATIO = 0.125f;

    [Header("Khung Canvas / Panel Thanh Trên & Dưới (Trong Canvas Cha)")]
    [Tooltip("Kéo Canvas con (hoặc Panel) của Thanh Trên vào đây. Nếu để trống, script sẽ tự tìm trong Canvas cha.")]
    [SerializeField] private RectTransform topBarContainer;

    [Tooltip("Kéo Canvas con (hoặc Panel) của Thanh Dưới vào đây. Nếu để trống, script sẽ tự tìm trong Canvas cha.")]
    [SerializeField] private RectTransform bottomBarContainer;

    [Tooltip("Bật nếu muốn vẽ thêm khung nền bo góc cho Thanh Trên/Dưới. Tắt đi nếu Canvas con của bạn đã có sẵn ảnh nền.")]
    [SerializeField] private bool drawBarBackgroundImage = true;

    [Tooltip("Bật nếu muốn hiện chữ +Điểm nhỏ bay lên tại vị trí kẹo nổ. Mặc định tắt để ẩn hoàn toàn số điểm.")]
    [SerializeField] private bool showFloatingScoreOnBoard = false;

    private Board board;
    private GameManager gameManager;
    private LevelGoalTracker goalTracker;
    private Button nextOrReplayBtn;
    private Text nextOrReplayBtnLabel;

    // --- Tham chiếu Canvas hiện có ---
    private Canvas mainCanvas;
    private RectTransform rootRect;
    private RectTransform fxLayer;
    private bool isUIBuilt;

    // Top HUD - Lượt đi & Thanh tiến trình Sao (Không dùng Text điểm số)
    private Text movesText;
    private RectTransform movesBadgeRect;
    private RectTransform scoreContainerRect;
    private Image progressFillImage;
    private readonly List<RectTransform> starIcons = new List<RectTransform>();
    private readonly bool[] starReached = new bool[3];

    // Top HUD - Khu vực Mục tiêu thu thập (Ẩn đi nếu màn chơi chỉ có mục tiêu Điểm số)
    private RectTransform targetContainerRect;
    private Text targetTitleText;
    private RectTransform targetItemsParent;

    private class GoalSlotUI
    {
        public LevelGoalTracker.RuntimeGoal RuntimeGoal;
        public RectTransform IconRect;
        public Image IconImage;
        public Text CountText;
        public GameObject CheckmarkObj;
        public bool WasCompleted;
    }

    private readonly List<GoalSlotUI> activeGoalSlots = new List<GoalSlotUI>();

    // Thanh hướng dẫn khi đang kích hoạt Booster
    private RectTransform boosterPromptBar;
    private Text boosterPromptText;

    // Bottom Booster Buttons & Số lượng
    private readonly Dictionary<BoosterType, int> boosterCharges = new Dictionary<BoosterType, int>();
    private readonly Dictionary<BoosterType, Text> boosterQtyLabels = new Dictionary<BoosterType, Text>();
    private readonly Dictionary<BoosterType, RectTransform> boosterButtonRects = new Dictionary<BoosterType, RectTransform>();

    // Banner & Popup Thắng / Thua
    private RectTransform comboBannerRect;
    private Text comboBannerText;
    private CanvasGroup comboBannerGroup;
    private GameObject endPopupRoot;
    private Text endPopupTitleText;
    private Text endPopupSubText;
    private readonly List<RectTransform> endPopupStars = new List<RectTransform>();

    // --- Trạng thái Gameplay & Booster ---
    public BoosterType ActiveBooster { get; private set; } = BoosterType.None;
    private BackgroundTiile firstSwapTile;
    private int boosterActivatedFrame = -1;

    private int maxStarScoreThreshold = 1000;
    private int displayedScore;
    private int cascadeComboCount;
    private float lastMatchTimestamp;
    private bool isLevelEnded;

    private Coroutine scoreRollCoroutine;
    private Coroutine bannerCoroutine;

    // Tài nguyên hình học tự sinh
    private Font defaultFont;
    private Sprite roundedSprite;
    private Sprite circleSprite;
    private Sprite starSprite;

    // Bảng màu giao diện
    private readonly Color colHeaderBg = new Color(0.16f, 0.20f, 0.34f, 0.94f);
    private readonly Color colPanelInner = new Color(0.10f, 0.13f, 0.24f, 0.95f);
    private readonly Color colAccentGold = new Color(1.00f, 0.78f, 0.18f, 1f);
    private readonly Color colAccentPink = new Color(0.96f, 0.30f, 0.52f, 1f);
    private readonly Color colAccentCyan = new Color(0.20f, 0.82f, 0.92f, 1f);
    private readonly Color colAccentGreen = new Color(0.30f, 0.85f, 0.45f, 1f);

    public static Match3UIManager EnsureInstance()
    {
        if (Instance == null)
        {
            Instance = FindFirstObjectByType<Match3UIManager>(FindObjectsInactive.Include);
            if (Instance == null)
            {
                Canvas existingCanvas = FindFirstObjectByType<Canvas>();
                if (existingCanvas != null)
                {
                    Canvas rootCanvas = existingCanvas.rootCanvas != null ? existingCanvas.rootCanvas : existingCanvas;
                    Instance = rootCanvas.gameObject.AddComponent<Match3UIManager>();
                }
                else
                {
                    GameObject obj = new GameObject("Match3_UIManager");
                    Instance = obj.AddComponent<Match3UIManager>();
                }
            }
        }
        return Instance;
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            if (GetComponent<Canvas>() != null && Instance.GetComponent<Canvas>() == null)
            {
                Destroy(Instance.gameObject);
                Instance = this;
                return;
            }
            Destroy(this);
            return;
        }
        Instance = this;
    }

    private void OnDestroy()
    {
        UnsubscribeGoalTrackerEvents();
        if (Instance == this)
        {
            Instance = null;
        }
    }

    private void Start()
    {
        EnsureUIBuiltOnExistingCanvas();
    }

    public void InitializeWithBoard(Board targetBoard, GameManager gm)
    {
        board = targetBoard;
        gameManager = gm;

        EnsureUIBuiltOnExistingCanvas();
        BindGoalTrackerAndConfigureHUD();
    }

    private void EnsureUIBuiltOnExistingCanvas()
    {
        if (isUIBuilt) return;
        isUIBuilt = true;

        PrepareProceduralAssets();
        BindToExistingCanvasAndContainers();
        BuildTopHUD();
        BuildBottomBoosterBar();
        BuildComboBanner();
        BuildEndGamePopup();
    }

    // =========================================================================================
    // PHẦN 1: ĐỒNG BỘ HÓA LUỒNG DỮ LIỆU VỚI LEVELGOALTRACKER & LEVELDATA
    // =========================================================================================

    private void BindGoalTrackerAndConfigureHUD()
    {
        UnsubscribeGoalTrackerEvents();

        goalTracker = gameManager != null ? gameManager.GoalTracker : null;
        LevelData levelData = board != null ? board.CurrentLevelData : null;

        isLevelEnded = false;
        displayedScore = 0;
        cascadeComboCount = 0;
        CancelActiveBooster();

        if (endPopupRoot != null) endPopupRoot.SetActive(false);
        if (bottomBarContainer != null) bottomBarContainer.gameObject.SetActive(true);
        if (board != null) board.SetBoardVisible(true);

        boosterCharges[BoosterType.Hammer] = 3;
        boosterCharges[BoosterType.FreeSwap] = 3;
        boosterCharges[BoosterType.ColorBomb] = 3;
        boosterCharges[BoosterType.Shuffle] = 3;
        RefreshBoosterUI();

        maxStarScoreThreshold = DetermineMaxStarScore(levelData, goalTracker);

        for (int i = 0; i < starIcons.Count; i++)
        {
            starReached[i] = false;
            starIcons[i].GetComponent<Image>().color = new Color(0.35f, 0.4f, 0.5f, 1f);
            starIcons[i].localScale = Vector3.one;
        }

        RebuildGoalSlotsFromTracker();

        if (goalTracker != null)
        {
            goalTracker.OnMovesChanged += HandleMovesChanged;
            goalTracker.OnScoreChanged += HandleScoreChanged;
            goalTracker.OnGoalsUpdated += HandleGoalsUpdated;
            goalTracker.OnLevelWin += HandleLevelWin;
            goalTracker.OnLevelLose += HandleLevelLose;

            HandleMovesChanged(goalTracker.MovesRemaining);
            UpdateScoreImmediate(goalTracker.CurrentScore);
            HandleGoalsUpdated();
        }
    }

    private void UnsubscribeGoalTrackerEvents()
    {
        if (goalTracker == null) return;
        goalTracker.OnMovesChanged -= HandleMovesChanged;
        goalTracker.OnScoreChanged -= HandleScoreChanged;
        goalTracker.OnGoalsUpdated -= HandleGoalsUpdated;
        goalTracker.OnLevelWin -= HandleLevelWin;
        goalTracker.OnLevelLose -= HandleLevelLose;
    }

    private int DetermineMaxStarScore(LevelData levelData, LevelGoalTracker tracker)
    {
        int scoreGoalTarget = 0;
        if (tracker != null)
        {
            for (int i = 0; i < tracker.Goals.Count; i++)
            {
                if (tracker.Goals[i].GoalType == LevelGoalType.ReachScore)
                {
                    scoreGoalTarget = Mathf.Max(scoreGoalTarget, tracker.Goals[i].TargetAmount);
                }
            }
        }

        if (scoreGoalTarget > 0) return scoreGoalTarget;
        if (levelData != null && levelData.TargetScore > 0) return levelData.TargetScore;
        return 1500;
    }

    private void RebuildGoalSlotsFromTracker()
    {
        for (int i = targetItemsParent.childCount - 1; i >= 0; i--)
        {
            Destroy(targetItemsParent.GetChild(i).gameObject);
        }
        activeGoalSlots.Clear();

        List<LevelGoalTracker.RuntimeGoal> collectGoals = new List<LevelGoalTracker.RuntimeGoal>();
        if (goalTracker != null)
        {
            for (int i = 0; i < goalTracker.Goals.Count; i++)
            {
                var g = goalTracker.Goals[i];
                if (g.GoalType == LevelGoalType.CollectCandy || g.GoalType == LevelGoalType.ClearObstacles)
                {
                    collectGoals.Add(g);
                }
            }
        }

        // TRƯỜNG HỢP 1: Màn chơi CHỈ có mục tiêu Hoàn thành Điểm (ReachScore) -> Chỉ hiện Thanh Tiến Trình Sao!
        if (collectGoals.Count == 0)
        {
            targetContainerRect.gameObject.SetActive(false);
            scoreContainerRect.anchorMin = new Vector2(0.25f, 0.08f);
            scoreContainerRect.anchorMax = new Vector2(0.985f, 0.92f);
            return;
        }

        // TRƯỜNG HỢP 2: Màn chơi có Thu thập Kẹo hoặc Phá vật cản -> Hiện cả Thanh Tiến Trình Sao và Ô Mục tiêu!
        scoreContainerRect.anchorMin = new Vector2(0.25f, 0.08f);
        scoreContainerRect.anchorMax = new Vector2(0.75f, 0.92f);
        targetContainerRect.gameObject.SetActive(true);

        bool hasCandyGoal = false;
        bool hasObstacleGoal = false;
        for (int i = 0; i < collectGoals.Count; i++)
        {
            if (collectGoals[i].GoalType == LevelGoalType.CollectCandy) hasCandyGoal = true;
            if (collectGoals[i].GoalType == LevelGoalType.ClearObstacles) hasObstacleGoal = true;
        }

        if (hasCandyGoal && !hasObstacleGoal) targetTitleText.text = "THU THẬP KẸO";
        else if (hasObstacleGoal && !hasCandyGoal) targetTitleText.text = "PHÁ VẬT CẢN";
        else targetTitleText.text = "MỤC TIÊU";

        int count = collectGoals.Count;
        float slotWidth = 1f / count;

        for (int i = 0; i < count; i++)
        {
            var goal = collectGoals[i];
            float minX = i * slotWidth + 0.04f;
            float maxX = (i + 1) * slotWidth - 0.04f;

            RectTransform slotRect = CreateAnchoredContainer($"GoalSlot_{i}", targetItemsParent,
                new Vector2(minX, 0.05f), new Vector2(maxX, 0.95f));

            GetGoalVisualSpriteAndColor(goal, out Sprite iconSprite, out Color iconColor);

            Image iconImg = CreateSquareAspectImage("Target_Icon", slotRect, iconSprite, iconColor);
            RectTransform iconRect = iconImg.rectTransform;

            RectTransform badgeSlot = CreateAnchoredContainer("CountBadgeSlot", iconRect,
                new Vector2(0.48f, -0.15f), new Vector2(1.12f, 0.48f));
            RectTransform countBadge = CreateSquareAspectImage("CountBadge", badgeSlot, circleSprite, new Color(0.12f, 0.15f, 0.28f, 1f)).rectTransform;
            Text countTxt = CreateProportionalLabel("Target_Count", countBadge, goal.TargetAmount.ToString(), Color.white,
                new Vector2(0.08f, 0.08f), new Vector2(0.92f, 0.92f), 10, 28);

            RectTransform checkBadge = CreateSquareAspectImage("Target_Checkmark", badgeSlot, circleSprite, colAccentGreen).rectTransform;
            CreateProportionalLabel("Check_Symbol", checkBadge, "V", Color.white,
                new Vector2(0.1f, 0.1f), new Vector2(0.9f, 0.9f), 10, 28);
            checkBadge.gameObject.SetActive(false);

            activeGoalSlots.Add(new GoalSlotUI
            {
                RuntimeGoal = goal,
                IconRect = iconRect,
                IconImage = iconImg,
                CountText = countTxt,
                CheckmarkObj = checkBadge.gameObject,
                WasCompleted = false
            });
        }
    }

    private void GetGoalVisualSpriteAndColor(LevelGoalTracker.RuntimeGoal goal, out Sprite sprite, out Color color)
    {
        sprite = starSprite;
        color = colAccentCyan;

        if (board == null) return;

        if (goal.GoalType == LevelGoalType.CollectCandy)
        {
            GameObject[] prefabs = board.GetActiveCandyPrefabs();
            if (prefabs != null && goal.CandyTypeIndex >= 0 && goal.CandyTypeIndex < prefabs.Length)
            {
                GameObject candyPrefab = prefabs[goal.CandyTypeIndex];
                if (candyPrefab != null)
                {
                    SpriteRenderer sr = candyPrefab.GetComponent<SpriteRenderer>();
                    if (sr == null) sr = candyPrefab.GetComponentInChildren<SpriteRenderer>();
                    if (sr != null && sr.sprite != null)
                    {
                        sprite = sr.sprite;
                        color = sr.color;
                        return;
                    }
                }
            }
        }
        else if (goal.GoalType == LevelGoalType.ClearObstacles)
        {
            if (board.ObstaclePrefab != null)
            {
                SpriteRenderer sr = board.ObstaclePrefab.GetComponent<SpriteRenderer>();
                if (sr == null) sr = board.ObstaclePrefab.GetComponentInChildren<SpriteRenderer>();
                if (sr != null && sr.sprite != null)
                {
                    sprite = sr.sprite;
                    color = sr.color;
                    return;
                }
            }
            sprite = roundedSprite;
            color = new Color(0.85f, 0.55f, 0.30f, 1f);
        }
    }

    // =========================================================================================
    // PHẦN 2: CÁC HÀM NHẬN SỰ KIỆN TỪ LEVELGOALTRACKER & GAMEMANAGER
    // =========================================================================================

    private void HandleMovesChanged(int remainingMoves)
    {
        if (movesText != null)
        {
            movesText.text = remainingMoves.ToString();
        }
        if (movesBadgeRect != null && gameObject.activeInHierarchy)
        {
            StartCoroutine(AnimateScaleBounce(movesBadgeRect, 1.25f, 0.18f));
        }

        if (remainingMoves == 5 && !isLevelEnded)
        {
            ShowComboBanner("CÒN 5 LƯỢT ĐI!", colAccentPink);
        }
    }

    private void HandleScoreChanged(int newTotalScore)
    {
        if (!gameObject.activeInHierarchy)
        {
            UpdateScoreImmediate(newTotalScore);
            return;
        }

        if (scoreRollCoroutine != null)
        {
            StopCoroutine(scoreRollCoroutine);
        }
        scoreRollCoroutine = StartCoroutine(RollScoreRoutine(newTotalScore));
    }

    private void UpdateScoreImmediate(int score)
    {
        displayedScore = score;
        if (progressFillImage != null)
        {
            progressFillImage.fillAmount = Mathf.Clamp01((float)score / Mathf.Max(100, maxStarScoreThreshold));
        }
    }

    private void HandleGoalsUpdated()
    {
        for (int i = 0; i < activeGoalSlots.Count; i++)
        {
            GoalSlotUI slot = activeGoalSlots[i];
            int remaining = Mathf.Max(0, slot.RuntimeGoal.TargetAmount - slot.RuntimeGoal.CurrentAmount);
            slot.CountText.text = remaining.ToString();

            if (slot.RuntimeGoal.IsCompleted && !slot.WasCompleted)
            {
                slot.WasCompleted = true;
                slot.CountText.gameObject.SetActive(false);
                slot.CheckmarkObj.SetActive(true);
                if (gameObject.activeInHierarchy)
                {
                    StartCoroutine(AnimateScaleBounce(slot.CheckmarkObj.GetComponent<RectTransform>(), 1.38f, 0.24f));
                }
            }
        }
    }

    private void HandleLevelWin()
    {
        if (isLevelEnded) return;
        isLevelEnded = true;
        CancelActiveBooster();
        ShowComboBanner("HOÀN THÀNH MỤC TIÊU!", colAccentGreen);
        StartCoroutine(EndGameSequenceRoutine(isVictory: true));
    }

    private void HandleLevelLose()
    {
        if (isLevelEnded) return;
        isLevelEnded = true;
        CancelActiveBooster();
        ShowComboBanner("HẾT LƯỢT ĐI!", colAccentPink);
        StartCoroutine(EndGameSequenceRoutine(isVictory: false));
    }

    private IEnumerator EndGameSequenceRoutine(bool isVictory)
    {
        yield return new WaitForSeconds(0.75f);

        if (board != null)
        {
            board.SetBoardVisible(false);
        }
        if (bottomBarContainer != null)
        {
            bottomBarContainer.gameObject.SetActive(false);
        }

        ShowEndGamePopup(isVictory);
    }

    public void OnBoardCandyCleared(Vector3 worldPos, int candyTypeIndex, SpecialCandyType specialType, int scoreGained)
    {
        if (Time.timeSinceLevelLoad < 0.35f) return;

        Vector2 fxLocalPos = WorldToFxLocalPosition(worldPos);
        if (showFloatingScoreOnBoard && scoreGained > 0)
        {
            SpawnFloatingScoreText($"+{scoreGained}", fxLocalPos, specialType == SpecialCandyType.None ? colAccentGold : colAccentCyan);
        }

        if (Time.time - lastMatchTimestamp > 0.3f)
        {
            cascadeComboCount++;
            if (cascadeComboCount >= 2 && !isLevelEnded)
            {
                TriggerComboPraise(cascadeComboCount);
            }
        }
        lastMatchTimestamp = Time.time;

        for (int i = 0; i < activeGoalSlots.Count; i++)
        {
            GoalSlotUI slot = activeGoalSlots[i];
            if (slot.RuntimeGoal.GoalType == LevelGoalType.CollectCandy &&
                slot.RuntimeGoal.CandyTypeIndex == candyTypeIndex)
            {
                StartCoroutine(FlyCollectableToSlotRoutine(
                    fxLocalPos,
                    slot,
                    slot.IconImage.sprite,
                    slot.IconImage.color));
                break;
            }
        }
    }

    public void OnBoardObstacleCleared(Vector3 worldPos, int scoreGained)
    {
        Vector2 fxLocalPos = WorldToFxLocalPosition(worldPos);
        if (showFloatingScoreOnBoard && scoreGained > 0)
        {
            SpawnFloatingScoreText($"+{scoreGained}", fxLocalPos, colAccentGreen);
        }

        for (int i = 0; i < activeGoalSlots.Count; i++)
        {
            GoalSlotUI slot = activeGoalSlots[i];
            if (slot.RuntimeGoal.GoalType == LevelGoalType.ClearObstacles)
            {
                StartCoroutine(FlyCollectableToSlotRoutine(
                    fxLocalPos,
                    slot,
                    slot.IconImage.sprite,
                    slot.IconImage.color));
                break;
            }
        }
    }

    public void ResetCascadePraiseCounter()
    {
        cascadeComboCount = 0;
    }

    // =========================================================================================
    // PHẦN 3: LIÊN KẾT CANVAS HIỆN CÓ & DỰNG TOP HUD / BOTTOM BOOSTER
    // =========================================================================================

    private void BindToExistingCanvasAndContainers()
    {
        if (FindFirstObjectByType<EventSystem>() == null)
        {
            GameObject esObj = new GameObject("EventSystem");
            esObj.AddComponent<EventSystem>();
            esObj.AddComponent<StandaloneInputModule>();
        }

        mainCanvas = GetComponent<Canvas>();
        if (mainCanvas == null) mainCanvas = GetComponentInParent<Canvas>();
        if (mainCanvas == null && board != null) mainCanvas = board.GetComponentInParent<Canvas>();
        if (mainCanvas == null) mainCanvas = FindFirstObjectByType<Canvas>();

        if (mainCanvas == null)
        {
            mainCanvas = gameObject.AddComponent<Canvas>();
            mainCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080f, 1920f);
            scaler.matchWidthOrHeight = 0.5f;
        }

        if (mainCanvas.rootCanvas != null)
        {
            mainCanvas = mainCanvas.rootCanvas;
        }

        if (mainCanvas.GetComponent<GraphicRaycaster>() == null)
        {
            mainCanvas.gameObject.AddComponent<GraphicRaycaster>();
        }

        rootRect = mainCanvas.GetComponent<RectTransform>();

        AutoDetectTopAndBottomSubCanvases();

        if (topBarContainer == null)
        {
            topBarContainer = CreateAnchoredContainer(
                "TopHUD_Bar",
                rootRect,
                new Vector2(0.02f, 1f - TOP_HUD_SCREEN_RATIO),
                new Vector2(0.98f, 0.99f));
        }

        if (bottomBarContainer == null)
        {
            bottomBarContainer = CreateAnchoredContainer(
                "BottomHUD_BoosterBar",
                rootRect,
                new Vector2(0.02f, 0.01f),
                new Vector2(0.98f, BOTTOM_HUD_SCREEN_RATIO));
        }

        EnsureSubCanvasRaycaster(topBarContainer);
        EnsureSubCanvasRaycaster(bottomBarContainer);

        fxLayer = CreateAnchoredContainer("FX_Overlay_Layer", rootRect, Vector2.zero, Vector2.one);
        fxLayer.SetAsLastSibling();
    }

    private void AutoDetectTopAndBottomSubCanvases()
    {
        if (rootRect == null) return;
        if (topBarContainer != null && bottomBarContainer != null) return;

        for (int i = 0; i < rootRect.childCount; i++)
        {
            RectTransform child = rootRect.GetChild(i) as RectTransform;
            if (child == null || !child.gameObject.activeInHierarchy) continue;

            if (child.GetComponent<Board>() != null || (board != null && child == board.transform))
            {
                continue;
            }

            string lowerName = child.name.ToLowerInvariant();

            if (topBarContainer == null &&
                (lowerName.Contains("top") || lowerName.Contains("header") || lowerName.Contains("tren") || lowerName.Contains("upper")))
            {
                topBarContainer = child;
                continue;
            }

            if (bottomBarContainer == null &&
                (lowerName.Contains("bottom") || lowerName.Contains("footer") || lowerName.Contains("booster") || lowerName.Contains("duoi") || lowerName.Contains("lower")))
            {
                bottomBarContainer = child;
                continue;
            }

            if (child.GetComponent<Canvas>() != null)
            {
                Vector3 localPos = rootRect.InverseTransformPoint(child.position);
                if (localPos.y > 20f && topBarContainer == null)
                {
                    topBarContainer = child;
                }
                else if (localPos.y < -20f && bottomBarContainer == null)
                {
                    bottomBarContainer = child;
                }
            }
        }
    }

    private void EnsureSubCanvasRaycaster(RectTransform container)
    {
        if (container == null) return;
        Canvas subCanvas = container.GetComponent<Canvas>();
        if (subCanvas != null && container.GetComponent<GraphicRaycaster>() == null)
        {
            container.gameObject.AddComponent<GraphicRaycaster>();
        }
    }

    /// <summary>
    /// Dựng Top HUD: Khối giữa chỉ hiển thị THANH TIẾN TRÌNH SAO lớn và nổi bật, không hiển thị số điểm.
    /// </summary>
    private void BuildTopHUD()
    {
        if (drawBarBackgroundImage && topBarContainer.GetComponent<Image>() == null)
        {
            Image bg = topBarContainer.gameObject.AddComponent<Image>();
            bg.sprite = roundedSprite;
            bg.type = Image.Type.Sliced;
            bg.color = colHeaderBg;
            bg.raycastTarget = false;
        }

        // 1. Khối LƯỢT ĐI (Bên trái)
        RectTransform movesBox = CreateProportionalPanel("Moves_Container", topBarContainer, colPanelInner,
            new Vector2(0.015f, 0.08f), new Vector2(0.235f, 0.92f));

        CreateProportionalLabel("Moves_Title", movesBox, "LƯỢT ĐI", new Color(0.75f, 0.82f, 1f),
            new Vector2(0.05f, 0.70f), new Vector2(0.95f, 0.96f), 11, 26);

        RectTransform movesBadgeSlot = CreateAnchoredContainer("Moves_BadgeSlot", movesBox,
            new Vector2(0.12f, 0.06f), new Vector2(0.88f, 0.68f));
        movesBadgeRect = CreateSquareAspectImage("Moves_CircleBadge", movesBadgeSlot, circleSprite, colAccentPink).rectTransform;
        movesText = CreateProportionalLabel("Moves_Value", movesBadgeRect, "25", Color.white,
            new Vector2(0.1f, 0.1f), new Vector2(0.9f, 0.9f), 14, 52);

        // 2. Khối THANH TIẾN TRÌNH 3 SAO (Ở giữa - Không hiện số điểm, căn giữa thanh tiến trình Sao to và rõ)
        scoreContainerRect = CreateProportionalPanel("Star_Progress_Container", topBarContainer, colPanelInner,
            new Vector2(0.25f, 0.08f), new Vector2(0.75f, 0.92f));

        CreateProportionalLabel("Star_Title", scoreContainerRect, "TIẾN TRÌNH SAO", new Color(0.75f, 0.82f, 1f),
            new Vector2(0.05f, 0.66f), new Vector2(0.95f, 0.94f), 11, 24);

        RectTransform barBg = CreateProportionalPanel("StarBar_Bg", scoreContainerRect, new Color(0.05f, 0.07f, 0.14f, 1f),
            new Vector2(0.06f, 0.22f), new Vector2(0.94f, 0.50f));

        RectTransform fillRect = CreateAnchoredContainer("StarBar_Fill", barBg,
            new Vector2(0.01f, 0.12f), new Vector2(0.99f, 0.88f));
        progressFillImage = fillRect.gameObject.AddComponent<Image>();
        progressFillImage.sprite = roundedSprite;
        progressFillImage.type = Image.Type.Filled;
        progressFillImage.fillMethod = Image.FillMethod.Horizontal;
        progressFillImage.fillOrigin = (int)Image.OriginHorizontal.Left;
        progressFillImage.fillAmount = 0f;
        progressFillImage.color = colAccentGreen;
        progressFillImage.raycastTarget = false;

        starIcons.Clear();
        float[] starAnchorsX = { 0.33f, 0.66f, 0.96f };
        for (int i = 0; i < 3; i++)
        {
            float ax = starAnchorsX[i];
            RectTransform starSlot = CreateAnchoredContainer($"StarSlot_{i + 1}", barBg,
                new Vector2(ax - 0.06f, -0.42f), new Vector2(ax + 0.06f, 1.42f));
            Image starImg = CreateSquareAspectImage($"Star_Milestone_{i + 1}", starSlot, starSprite, new Color(0.35f, 0.4f, 0.5f, 1f));
            starIcons.Add(starImg.rectTransform);
        }

        // 3. Khối MỤC TIÊU THU THẬP KẸO / VẬT CẢN (Bên phải)
        targetContainerRect = CreateProportionalPanel("Target_Container", topBarContainer, colPanelInner,
            new Vector2(0.765f, 0.08f), new Vector2(0.985f, 0.92f));

        targetTitleText = CreateProportionalLabel("Target_Title", targetContainerRect, "THU THẬP KẸO", new Color(0.75f, 0.82f, 1f),
            new Vector2(0.04f, 0.70f), new Vector2(0.96f, 0.96f), 10, 22);

        targetItemsParent = CreateAnchoredContainer("Target_ItemsArea", targetContainerRect,
            new Vector2(0.06f, 0.08f), new Vector2(0.94f, 0.68f));
    }

    private void BuildBottomBoosterBar()
    {
        if (drawBarBackgroundImage && bottomBarContainer.GetComponent<Image>() == null)
        {
            Image bg = bottomBarContainer.gameObject.AddComponent<Image>();
            bg.sprite = roundedSprite;
            bg.type = Image.Type.Sliced;
            bg.color = colHeaderBg;
            bg.raycastTarget = false;
        }

        // Thanh hướng dẫn Booster tắt chặn Raycast (blocksRaycasts = false) để không bao giờ che khuất hàng kẹo dưới cùng
        boosterPromptBar = CreateProportionalPanel("Booster_PromptBar", bottomBarContainer, new Color(0.10f, 0.14f, 0.26f, 0.96f),
            new Vector2(0.04f, 1.04f), new Vector2(0.96f, 1.40f));
        CanvasGroup promptCg = boosterPromptBar.gameObject.AddComponent<CanvasGroup>();
        promptCg.blocksRaycasts = false;
        promptCg.interactable = false;

        boosterPromptText = CreateProportionalLabel("Prompt_Text", boosterPromptBar, "", colAccentGold,
            new Vector2(0.03f, 0.1f), new Vector2(0.97f, 0.9f), 11, 24);
        boosterPromptBar.gameObject.SetActive(false);

        BoosterType[] types = { BoosterType.Hammer, BoosterType.FreeSwap, BoosterType.ColorBomb, BoosterType.Shuffle };
        string[] names = { "Búa Phá", "Đổi Chỗ", "Bom Màu", "Xáo Trộn" };
        Color[] colors = { colAccentPink, colAccentCyan, colAccentGold, colAccentGreen };

        boosterQtyLabels.Clear();
        boosterButtonRects.Clear();

        const float totalLeft = 0.02f;
        const float totalRight = 0.98f;
        const float gap = 0.02f;
        float btnWidth = (totalRight - totalLeft - (gap * 3f)) / 4f;

        for (int i = 0; i < types.Length; i++)
        {
            BoosterType bType = types[i];
            float minX = totalLeft + i * (btnWidth + gap);
            float maxX = minX + btnWidth;

            Button btn = CreateProportionalButton(
                $"Booster_{bType}",
                bottomBarContainer,
                names[i],
                colors[i],
                new Vector2(minX, 0.12f),
                new Vector2(maxX, 0.88f));

            RectTransform btnRect = btn.GetComponent<RectTransform>();
            boosterButtonRects[bType] = btnRect;

            RectTransform badgeSlot = CreateAnchoredContainer("BoosterBadgeSlot", btnRect,
                new Vector2(0.72f, 0.62f), new Vector2(0.98f, 1.08f));
            RectTransform badge = CreateSquareAspectImage("BoosterBadge", badgeSlot, circleSprite, colPanelInner).rectTransform;
            Text qtyTxt = CreateProportionalLabel("Qty", badge, "3", colAccentGold,
                new Vector2(0.1f, 0.1f), new Vector2(0.9f, 0.9f), 10, 24);
            boosterQtyLabels[bType] = qtyTxt;

            btn.onClick.AddListener(() => OnBoosterButtonClicked(bType));
        }
    }

    private void BuildComboBanner()
    {
        comboBannerRect = CreateProportionalPanel("Combo_Banner", fxLayer, colAccentPink,
            new Vector2(0.20f, 0.78f), new Vector2(0.80f, 0.835f));
        comboBannerGroup = comboBannerRect.gameObject.AddComponent<CanvasGroup>();
        comboBannerGroup.alpha = 0f;
        comboBannerGroup.blocksRaycasts = false;

        comboBannerText = CreateProportionalLabel("Combo_Text", comboBannerRect, "SWEET!", Color.white,
            new Vector2(0.05f, 0.1f), new Vector2(0.95f, 0.9f), 16, 44);
    }

    private void BuildEndGamePopup()
    {
        RectTransform overlay = CreateProportionalPanel("EndGame_Popup_Overlay", rootRect, new Color(0f, 0f, 0f, 0.82f),
            Vector2.zero, Vector2.one, raycastTarget: true);
        endPopupRoot = overlay.gameObject;

        RectTransform dialog = CreateProportionalPanel("EndGame_Dialog", overlay, colHeaderBg,
            new Vector2(0.08f, 0.26f), new Vector2(0.92f, 0.74f), raycastTarget: true);

        endPopupTitleText = CreateProportionalLabel("End_Title", dialog, "HOÀN THÀNH MÀN CHƠI!", colAccentGold,
            new Vector2(0.06f, 0.78f), new Vector2(0.94f, 0.94f), 18, 44);

        endPopupStars.Clear();
        float[] starMinX = { 0.16f, 0.40f, 0.64f };
        float[] starMaxX = { 0.36f, 0.60f, 0.84f };
        float[] starMinY = { 0.46f, 0.50f, 0.46f };
        float[] starMaxY = { 0.72f, 0.76f, 0.72f };

        for (int i = 0; i < 3; i++)
        {
            RectTransform starSlot = CreateAnchoredContainer($"WinStar_Slot_{i}", dialog,
                new Vector2(starMinX[i], starMinY[i]), new Vector2(starMaxX[i], starMaxY[i]));
            Image starBg = CreateSquareAspectImage($"StarBg_{i}", starSlot, starSprite, new Color(0.1f, 0.12f, 0.2f, 1f));
            Image goldenStar = CreateSquareAspectImage($"WinStar_Gold_{i}", starBg.rectTransform, starSprite, colAccentGold);
            endPopupStars.Add(goldenStar.rectTransform);
        }

        endPopupSubText = CreateProportionalLabel("End_Sub", dialog, "", Color.white,
            new Vector2(0.08f, 0.28f), new Vector2(0.92f, 0.42f), 14, 30);

        // Nút bên trái: Quay về Scene Chọn Màn Chơi
        Button mapBtn = CreateProportionalButton("Btn_BackToMap", dialog, "Về Chọn Màn", colAccentCyan,
            new Vector2(0.06f, 0.07f), new Vector2(0.47f, 0.23f));
        mapBtn.onClick.AddListener(() =>
        {
            if (Application.CanStreamedLevelBeLoaded(LevelSession.LevelSelectSceneName))
            {
                SceneManager.LoadScene(LevelSession.LevelSelectSceneName);
            }
            else
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        });

        // Nút bên phải: Màn Tiếp Theo (nếu thắng) hoặc Chơi Lại (nếu thua)
        nextOrReplayBtn = CreateProportionalButton("Btn_NextOrReplay", dialog, "Màn Tiếp Theo", colAccentGreen,
            new Vector2(0.53f, 0.07f), new Vector2(0.94f, 0.23f));
        nextOrReplayBtnLabel = nextOrReplayBtn.transform.Find("Btn_Label").GetComponent<Text>();

        endPopupRoot.SetActive(false);
    }

    // =========================================================================================
    // PHẦN 4: XỬ LÝ TƯƠNG TÁC BOOSTER TRÊN BÀN CỜ (KHÔNG BỊ CHẶN BỞI CANVAS BACKGROUND)
    // =========================================================================================

    private void Update()
    {
        if (isLevelEnded) return;

        int remainingMoves = goalTracker != null ? goalTracker.MovesRemaining : 10;
        if (movesBadgeRect != null && remainingMoves > 0 && remainingMoves <= 5)
        {
            float pulse = 1f + Mathf.Sin(Time.time * 9f) * 0.08f;
            movesBadgeRect.localScale = new Vector3(pulse, pulse, 1f);
            movesText.color = Color.Lerp(Color.white, new Color(1f, 0.35f, 0.35f), (Mathf.Sin(Time.time * 9f) + 1f) * 0.5f);
        }
        else if (movesBadgeRect != null)
        {
            movesBadgeRect.localScale = Vector3.Lerp(movesBadgeRect.localScale, Vector3.one, Time.deltaTime * 10f);
            movesText.color = Color.white;
        }

        // Xử lý chọn kẹo trên bàn cờ khi đang bật Booster (Búa Phá, Bom Màu, Đổi Chỗ)
        if (ActiveBooster != BoosterType.None && Time.frameCount > boosterActivatedFrame)
        {
            if (Input.GetMouseButtonDown(0))
            {
                Vector2 screenPos = Input.mousePosition;
                // Chỉ bỏ qua nếu người chơi bấm trực tiếp vào vùng nút Booster ở đáy hoặc Top HUD
                if (!IsScreenPointOverHUDContainers(screenPos))
                {
                    HandleBoardPointerDownForBooster(screenPos);
                }
            }
            else if (ActiveBooster == BoosterType.FreeSwap && firstSwapTile != null && Input.GetMouseButton(0))
            {
                // Hỗ trợ thêm thao tác nhấn giữ viên kẹo 1 và kéo thẳng sang viên kẹo 2 bên cạnh cho công cụ Đổi Chỗ!
                Vector2 screenPos = Input.mousePosition;
                HandleFreeSwapDrag(screenPos);
            }
        }
    }

    /// <summary>
    /// Kiểm tra xem điểm click có nằm trong thanh Top HUD hoặc Bottom Booster Bar hay không.
    /// Giúp người chơi click chọn kẹo trên bàn cờ thoải mái ngay cả khi Canvas cha có tấm ảnh nền (Background Image).
    /// </summary>
    private bool IsScreenPointOverHUDContainers(Vector2 screenPos)
    {
        Camera uiCam = (mainCanvas != null && mainCanvas.renderMode != RenderMode.ScreenSpaceOverlay)
            ? (mainCanvas.worldCamera != null ? mainCanvas.worldCamera : Camera.main)
            : null;

        if (bottomBarContainer != null && bottomBarContainer.gameObject.activeInHierarchy &&
            RectTransformUtility.RectangleContainsScreenPoint(bottomBarContainer, screenPos, uiCam))
        {
            return true;
        }

        if (topBarContainer != null && topBarContainer.gameObject.activeInHierarchy &&
            RectTransformUtility.RectangleContainsScreenPoint(topBarContainer, screenPos, uiCam))
        {
            return true;
        }

        return false;
    }

    private void OnBoosterButtonClicked(BoosterType type)
    {
        if (isLevelEnded || board == null || (gameManager != null && gameManager.IsBusy)) return;

        if (ActiveBooster == type)
        {
            CancelActiveBooster();
            return;
        }

        if (!boosterCharges.TryGetValue(type, out int charges) || charges <= 0)
        {
            ShowComboBanner("ĐÃ HẾT LƯỢT DÙNG!", colAccentPink);
            return;
        }

        if (type == BoosterType.Shuffle)
        {
            CancelActiveBooster();
            if (board.ExecuteShuffleBooster())
            {
                ConsumeBoosterCharge(BoosterType.Shuffle);
                ShowComboBanner("XÁO TRỘN BÀN CỜ!", colAccentGreen);
            }
            return;
        }

        CancelActiveBooster();
        ActiveBooster = type;
        boosterActivatedFrame = Time.frameCount;
        StartCoroutine(AnimateScaleBounce(boosterButtonRects[type], 1.18f, 0.2f));

        boosterPromptBar.gameObject.SetActive(true);
        switch (type)
        {
            case BoosterType.Hammer:
                boosterPromptText.text = "BÚA PHÁ: Chạm vào 1 viên kẹo hoặc vật cản bất kỳ để đập vỡ!";
                break;
            case BoosterType.FreeSwap:
                boosterPromptText.text = "ĐỔI CHỖ: Chạm 2 viên kẹo cạnh nhau (hoặc kéo viên 1 sang viên 2)!";
                break;
            case BoosterType.ColorBomb:
                boosterPromptText.text = "BOM MÀU: Chạm vào 1 viên kẹo để biến thành Bom Màu!";
                break;
        }
    }

    public void CancelActiveBooster()
    {
        if (firstSwapTile != null && firstSwapTile.CurrentCandy != null)
        {
            firstSwapTile.CurrentCandy.SetSelectedVisual(false);
        }
        firstSwapTile = null;
        ActiveBooster = BoosterType.None;

        if (boosterPromptBar != null)
        {
            boosterPromptBar.gameObject.SetActive(false);
        }
    }

    private void HandleBoardPointerDownForBooster(Vector2 screenPos)
    {
        if (board == null || (gameManager != null && gameManager.IsBusy)) return;

        Vector3 mouseWorld = ScreenToBoardWorldPoint(screenPos);
        if (!board.TryGetGridCoordFromWorld(mouseWorld, out int gx, out int gy))
        {
            return;
        }

        switch (ActiveBooster)
        {
            case BoosterType.Hammer:
                if (board.ExecuteHammerBoosterAt(gx, gy))
                {
                    ConsumeBoosterCharge(BoosterType.Hammer);
                    ShowComboBanner("BÚA TẠ GIÁNG ĐÒN!", colAccentPink);
                    CancelActiveBooster();
                }
                break;

            case BoosterType.ColorBomb:
                if (board.ExecuteColorBombBoosterAt(gx, gy))
                {
                    ConsumeBoosterCharge(BoosterType.ColorBomb);
                    ShowComboBanner("TRIỆU HỒI BOM MÀU!", colAccentGold);
                    CancelActiveBooster();
                }
                break;

            case BoosterType.FreeSwap:
                BackgroundTiile clickedTile = board.GetTile(gx, gy);
                if (clickedTile == null || clickedTile.CurrentCandy == null) return;

                if (firstSwapTile == null)
                {
                    firstSwapTile = clickedTile;
                    firstSwapTile.CurrentCandy.SetSelectedVisual(true);
                    boosterPromptText.text = "ĐỔI CHỖ: Chạm hoặc kéo sang viên kẹo thứ 2 nằm sát cạnh!";
                }
                else if (clickedTile == firstSwapTile)
                {
                    firstSwapTile.CurrentCandy.SetSelectedVisual(false);
                    firstSwapTile = null;
                    boosterPromptText.text = "ĐỔI CHỖ: Chạm 2 viên kẹo cạnh nhau (hoặc kéo viên 1 sang viên 2)!";
                }
                else
                {
                    int manhattan = Mathf.Abs(clickedTile.X - firstSwapTile.X) + Mathf.Abs(clickedTile.Y - firstSwapTile.Y);
                    if (manhattan == 1)
                    {
                        ExecuteFreeSwapPair(firstSwapTile, clickedTile);
                    }
                    else
                    {
                        firstSwapTile.CurrentCandy.SetSelectedVisual(false);
                        firstSwapTile = clickedTile;
                        firstSwapTile.CurrentCandy.SetSelectedVisual(true);
                    }
                }
                break;
        }
    }

    private void HandleFreeSwapDrag(Vector2 screenPos)
    {
        if (board == null || firstSwapTile == null || (gameManager != null && gameManager.IsBusy)) return;

        Vector3 mouseWorld = ScreenToBoardWorldPoint(screenPos);
        if (!board.TryGetGridCoordFromWorld(mouseWorld, out int gx, out int gy))
        {
            return;
        }

        BackgroundTiile hoveredTile = board.GetTile(gx, gy);
        if (hoveredTile != null && hoveredTile != firstSwapTile && hoveredTile.CurrentCandy != null)
        {
            int manhattan = Mathf.Abs(hoveredTile.X - firstSwapTile.X) + Mathf.Abs(hoveredTile.Y - firstSwapTile.Y);
            if (manhattan == 1)
            {
                ExecuteFreeSwapPair(firstSwapTile, hoveredTile);
            }
        }
    }

    private void ExecuteFreeSwapPair(BackgroundTiile tileA, BackgroundTiile tileB)
    {
        if (tileA.CurrentCandy != null)
        {
            tileA.CurrentCandy.SetSelectedVisual(false);
        }

        if (board.ExecuteFreeSwapBooster(tileA, tileB))
        {
            ConsumeBoosterCharge(BoosterType.FreeSwap);
            CancelActiveBooster();
            ShowComboBanner("ĐỔI CHỖ TỰ DO!", colAccentCyan);
        }
    }

    /// <summary>
    /// Chuyển đổi tọa độ chuột trên màn hình sang đúng mặt phẳng Z của bàn cờ (hỗ trợ cả Camera Orthographic và Perspective).
    /// </summary>
    private Vector3 ScreenToBoardWorldPoint(Vector2 screenPos)
    {
        Camera cam = Camera.main;
        if (cam == null && mainCanvas != null && mainCanvas.worldCamera != null)
        {
            cam = mainCanvas.worldCamera;
        }
        if (cam == null)
        {
            cam = FindFirstObjectByType<Camera>();
        }
        if (cam == null)
        {
            return new Vector3(screenPos.x, screenPos.y, 0f);
        }

        float boardZ = board != null ? board.transform.position.z : 0f;
        float zDist = Mathf.Abs(boardZ - cam.transform.position.z);
        Vector3 world = cam.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, zDist));
        world.z = boardZ;
        return world;
    }

    private void ConsumeBoosterCharge(BoosterType type)
    {
        if (boosterCharges.ContainsKey(type) && boosterCharges[type] > 0)
        {
            boosterCharges[type]--;
            RefreshBoosterUI();
        }
    }

    private void RefreshBoosterUI()
    {
        foreach (var kvp in boosterQtyLabels)
        {
            int qty = boosterCharges.TryGetValue(kvp.Key, out int val) ? val : 0;
            kvp.Value.text = qty.ToString();
        }
    }

    public void ShowEndGamePopup(bool isVictory)
    {
        endPopupRoot.SetActive(true);
        endPopupRoot.transform.SetAsLastSibling();

        string levelTitle = (board != null && board.CurrentLevelData != null)
            ? board.CurrentLevelData.DisplayName
            : "MÀN CHƠI";

        nextOrReplayBtn.onClick.RemoveAllListeners();

        if (isVictory)
        {
            int earnedStars = (starReached[2] ? 3 : (starReached[1] ? 2 : 1));
            // Lưu số sao và mở khóa màn tiếp theo vào bộ nhớ
            LevelSession.RecordCurrentLevelVictory(earnedStars);

            endPopupTitleText.text = $"{levelTitle.ToUpper()} - CHIẾN THẮNG!";
            endPopupTitleText.color = colAccentGold;
            endPopupSubText.text = $"Hoàn thành xuất sắc! Lượt đi còn dư: {(goalTracker != null ? goalTracker.MovesRemaining : 0)}";

            if (LevelSession.HasNextLevel())
            {
                nextOrReplayBtnLabel.text = "Màn Tiếp Theo";
                nextOrReplayBtn.onClick.AddListener(() =>
                {
                    LevelSession.AdvanceToNextLevel();
                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
                });
            }
            else
            {
                nextOrReplayBtnLabel.text = "Chơi Lại";
                nextOrReplayBtn.onClick.AddListener(() => SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex));
            }

            StartCoroutine(PlayVictoryStarsAnimation(earnedStars));
        }
        else
        {
            endPopupTitleText.text = $"{levelTitle.ToUpper()} - HẾT LƯỢT!";
            endPopupTitleText.color = colAccentPink;
            endPopupSubText.text = "Bạn chưa hoàn thành mục tiêu màn chơi. Hãy thử lại nhé!";

            nextOrReplayBtnLabel.text = "Thử Lại";
            nextOrReplayBtn.onClick.AddListener(() => SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex));

            int earnedStars = (starReached[2] ? 3 : (starReached[1] ? 2 : (starReached[0] ? 1 : 0)));
            StartCoroutine(PlayVictoryStarsAnimation(earnedStars));
        }
    }

    private IEnumerator FlyCollectableToSlotRoutine(Vector2 startLocalPos, GoalSlotUI targetSlot, Sprite iconSprite, Color iconColor)
    {
        if (targetSlot == null || targetSlot.IconRect == null) yield break;

        GameObject flyObj = new GameObject("Flying_Target");
        flyObj.transform.SetParent(fxLayer, false);
        RectTransform itemRect = flyObj.AddComponent<RectTransform>();
        itemRect.sizeDelta = new Vector2(58f, 58f);
        itemRect.anchoredPosition = startLocalPos;

        Image flyingItem = flyObj.AddComponent<Image>();
        flyingItem.sprite = iconSprite != null ? iconSprite : starSprite;
        flyingItem.color = iconColor;
        flyingItem.preserveAspect = true;
        flyingItem.raycastTarget = false;

        Vector2 endLocalPos = WorldToFxLocalPosition(targetSlot.IconRect.position);
        Vector2 controlPoint = (startLocalPos + endLocalPos) * 0.5f + new Vector2(Random.Range(-160f, 160f), 130f);

        float duration = 0.48f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            float smoothT = t * t * (3f - 2f * t);
            float oneMinusT = 1f - smoothT;

            Vector2 pos = (oneMinusT * oneMinusT * startLocalPos)
                        + (2f * oneMinusT * smoothT * controlPoint)
                        + (smoothT * smoothT * endLocalPos);

            itemRect.anchoredPosition = pos;
            itemRect.localRotation = Quaternion.Euler(0f, 0f, elapsed * 360f);
            yield return null;
        }

        Destroy(flyObj);

        if (targetSlot.IconRect != null)
        {
            StartCoroutine(AnimateScaleBounce(targetSlot.IconRect, 1.25f, 0.18f));
        }
    }

    private void TriggerComboPraise(int comboStep)
    {
        string[] praises = { "SWEET!", "TASTY!", "DELICIOUS!", "DIVINE!", "SUGAR CRUSH!" };
        Color[] colors = { colAccentCyan, colAccentGreen, colAccentGold, colAccentPink, new Color(0.75f, 0.4f, 1f) };

        int idx = Mathf.Clamp(comboStep - 2, 0, praises.Length - 1);
        ShowComboBanner(praises[idx], colors[idx]);
    }

    public void ShowComboBanner(string message, Color bannerColor)
    {
        if (bannerCoroutine != null) StopCoroutine(bannerCoroutine);
        bannerCoroutine = StartCoroutine(ComboBannerRoutine(message, bannerColor));
    }

    private IEnumerator ComboBannerRoutine(string message, Color bannerColor)
    {
        comboBannerText.text = message;
        comboBannerRect.GetComponent<Image>().color = bannerColor;
        comboBannerGroup.alpha = 1f;

        float elapsed = 0f;
        float popDuration = 0.22f;
        while (elapsed < popDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / popDuration;
            float scale = Mathf.Sin(t * Mathf.PI * 0.5f) * 1.12f;
            comboBannerRect.localScale = new Vector3(scale, scale, 1f);
            yield return null;
        }
        comboBannerRect.localScale = Vector3.one;

        yield return new WaitForSeconds(0.65f);

        elapsed = 0f;
        float fadeDuration = 0.22f;
        while (elapsed < fadeDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / fadeDuration;
            comboBannerGroup.alpha = 1f - t;
            yield return null;
        }
        comboBannerGroup.alpha = 0f;
    }

    private void SpawnFloatingScoreText(string content, Vector2 localPos, Color color)
    {
        GameObject obj = new GameObject("FloatingScore");
        obj.transform.SetParent(fxLayer, false);
        RectTransform rect = obj.AddComponent<RectTransform>();
        rect.anchoredPosition = localPos;
        rect.sizeDelta = new Vector2(220f, 60f);

        Text txt = obj.AddComponent<Text>();
        txt.font = defaultFont;
        txt.text = content;
        txt.fontSize = 34;
        txt.fontStyle = FontStyle.Bold;
        txt.alignment = TextAnchor.MiddleCenter;
        txt.color = color;
        txt.raycastTarget = false;
        txt.horizontalOverflow = HorizontalWrapMode.Overflow;
        txt.verticalOverflow = VerticalWrapMode.Overflow;

        Shadow shadow = obj.AddComponent<Shadow>();
        shadow.effectColor = new Color(0f, 0f, 0f, 0.65f);
        shadow.effectDistance = new Vector2(2f, -2f);

        StartCoroutine(FloatingTextRoutine(rect, txt));
    }

    private IEnumerator FloatingTextRoutine(RectTransform rect, Text txt)
    {
        Vector2 startPos = rect.anchoredPosition;
        Vector2 endPos = startPos + new Vector2(0f, 95f);
        Color baseCol = txt.color;

        float duration = 0.72f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);

            rect.anchoredPosition = Vector2.Lerp(startPos, endPos, 1f - Mathf.Pow(1f - t, 2f));
            float scale = t < 0.2f ? Mathf.Lerp(0.4f, 1.2f, t / 0.2f) : Mathf.Lerp(1.2f, 1f, (t - 0.2f) / 0.8f);
            rect.localScale = new Vector3(scale, scale, 1f);

            if (t > 0.5f)
            {
                txt.color = new Color(baseCol.r, baseCol.g, baseCol.b, Mathf.Lerp(1f, 0f, (t - 0.5f) / 0.5f));
            }
            yield return null;
        }

        Destroy(rect.gameObject);
    }

    /// <summary>
    /// Cập nhật mượt Thanh Tiến Trình Sao và bật sáng từng Ngôi Sao (Không dùng scoreText).
    /// </summary>
    private IEnumerator RollScoreRoutine(int targetScore)
    {
        int startScore = displayedScore;
        float startFill = progressFillImage != null ? progressFillImage.fillAmount : 0f;
        float targetFill = Mathf.Clamp01((float)targetScore / Mathf.Max(100, maxStarScoreThreshold));

        float duration = 0.38f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);

            displayedScore = Mathf.RoundToInt(Mathf.Lerp(startScore, targetScore, t));
            if (progressFillImage != null)
            {
                progressFillImage.fillAmount = Mathf.Lerp(startFill, targetFill, t);
            }

            float[] thresholds = { 0.33f, 0.66f, 0.99f };
            for (int i = 0; i < starIcons.Count; i++)
            {
                if (!starReached[i] && progressFillImage != null && progressFillImage.fillAmount >= thresholds[i])
                {
                    starReached[i] = true;
                    starIcons[i].GetComponent<Image>().color = colAccentGold;
                    StartCoroutine(AnimateScaleBounce(starIcons[i], 1.5f, 0.28f));
                }
            }
            yield return null;
        }

        displayedScore = targetScore;
        if (progressFillImage != null)
        {
            progressFillImage.fillAmount = targetFill;
        }
    }

    private IEnumerator PlayVictoryStarsAnimation(int starCount)
    {
        RectTransform dialog = endPopupRoot.transform.Find("EndGame_Dialog").GetComponent<RectTransform>();
        StartCoroutine(AnimateScaleBounce(dialog, 1.08f, 0.25f));

        for (int i = 0; i < endPopupStars.Count; i++)
        {
            endPopupStars[i].localScale = Vector3.zero;
        }

        for (int i = 0; i < Mathf.Min(starCount, endPopupStars.Count); i++)
        {
            yield return new WaitForSeconds(0.26f);
            RectTransform star = endPopupStars[i];
            float elapsed = 0f;
            float duration = 0.26f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float scale = Mathf.Lerp(2.2f, 1f, t);
                star.localScale = new Vector3(scale, scale, 1f);
                star.localRotation = Quaternion.Euler(0f, 0f, Mathf.Lerp(-35f, 0f, t));
                yield return null;
            }
            star.localScale = Vector3.one;
            star.localRotation = Quaternion.identity;
            StartCoroutine(AnimateScaleBounce(star, 1.25f, 0.15f));
        }
    }

    private IEnumerator AnimateScaleBounce(RectTransform target, float peakScale, float duration)
    {
        if (target == null) yield break;
        float half = duration * 0.5f;
        float elapsed = 0f;
        while (elapsed < half)
        {
            elapsed += Time.deltaTime;
            float s = Mathf.Lerp(1f, peakScale, elapsed / half);
            target.localScale = new Vector3(s, s, 1f);
            yield return null;
        }
        elapsed = 0f;
        while (elapsed < half)
        {
            elapsed += Time.deltaTime;
            float s = Mathf.Lerp(peakScale, 1f, elapsed / half);
            target.localScale = new Vector3(s, s, 1f);
            yield return null;
        }
        target.localScale = Vector3.one;
    }

    // =========================================================================================
    // PHẦN 5: HÀM TIỆN ÍCH TẠO ELEMENT UI (TẮT RAYCAST TARGET TRÊN CÁC HÌNH TRANG TRÍ)
    // =========================================================================================

    private RectTransform CreateAnchoredContainer(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent, false);

        RectTransform rect = obj.AddComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        rect.localScale = Vector3.one;
        return rect;
    }

    private RectTransform CreateProportionalPanel(string name, Transform parent, Color color, Vector2 anchorMin, Vector2 anchorMax, bool raycastTarget = false)
    {
        RectTransform rect = CreateAnchoredContainer(name, parent, anchorMin, anchorMax);
        Image img = rect.gameObject.AddComponent<Image>();
        img.sprite = roundedSprite;
        img.type = Image.Type.Sliced;
        img.color = color;
        img.raycastTarget = raycastTarget;
        return rect;
    }

    private Image CreateSquareAspectImage(string name, Transform parent, Sprite sprite, Color color)
    {
        RectTransform rect = CreateAnchoredContainer(name, parent, Vector2.zero, Vector2.one);
        Image img = rect.gameObject.AddComponent<Image>();
        img.sprite = sprite;
        img.color = color;
        img.preserveAspect = true;
        img.raycastTarget = false;

        AspectRatioFitter fitter = rect.gameObject.AddComponent<AspectRatioFitter>();
        fitter.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
        fitter.aspectRatio = 1f;
        return img;
    }

    private Text CreateProportionalLabel(string name, Transform parent, string content, Color color, Vector2 anchorMin, Vector2 anchorMax, int minFontSize, int maxFontSize)
    {
        RectTransform rect = CreateAnchoredContainer(name, parent, anchorMin, anchorMax);

        Text txt = rect.gameObject.AddComponent<Text>();
        txt.font = defaultFont;
        txt.text = content;
        txt.fontStyle = FontStyle.Bold;
        txt.alignment = TextAnchor.MiddleCenter;
        txt.color = color;
        txt.raycastTarget = false;
        txt.resizeTextForBestFit = true;
        txt.resizeTextMinSize = minFontSize;
        txt.resizeTextMaxSize = maxFontSize;
        txt.horizontalOverflow = HorizontalWrapMode.Wrap;
        txt.verticalOverflow = VerticalWrapMode.Truncate;

        Shadow shadow = rect.gameObject.AddComponent<Shadow>();
        shadow.effectColor = new Color(0f, 0f, 0f, 0.65f);
        shadow.effectDistance = new Vector2(1.5f, -1.5f);
        return txt;
    }

    private Button CreateProportionalButton(string name, Transform parent, string labelText, Color bgColor, Vector2 anchorMin, Vector2 anchorMax)
    {
        RectTransform btnRect = CreateProportionalPanel(name, parent, bgColor, anchorMin, anchorMax, raycastTarget: true);
        Button btn = btnRect.gameObject.AddComponent<Button>();
        CreateProportionalLabel("Btn_Label", btnRect, labelText, Color.white,
            new Vector2(0.06f, 0.12f), new Vector2(0.94f, 0.88f), 11, 28);
        return btn;
    }

    private Vector2 WorldToFxLocalPosition(Vector3 worldPos)
    {
        if (fxLayer == null) return Vector2.zero;

        Camera worldCam = (mainCanvas != null && mainCanvas.worldCamera != null) ? mainCanvas.worldCamera : Camera.main;
        Vector2 screenPos = RectTransformUtility.WorldToScreenPoint(worldCam, worldPos);
        Camera uiCam = (mainCanvas != null && mainCanvas.renderMode == RenderMode.ScreenSpaceOverlay) ? null : worldCam;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(fxLayer, screenPos, uiCam, out Vector2 localPoint);
        return localPoint;
    }

    private void PrepareProceduralAssets()
    {
        defaultFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (defaultFont == null) defaultFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
        if (defaultFont == null) defaultFont = Font.CreateDynamicFontFromOSFont("Arial", 32);

        roundedSprite = CreateRoundedRectSprite(64, 64, 16);
        circleSprite = CreateRoundedRectSprite(64, 64, 31);
        starSprite = CreateStarPolygonSprite(96);
    }

    private Sprite CreateRoundedRectSprite(int width, int height, float radius)
    {
        Texture2D tex = new Texture2D(width, height, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;

        Vector2 halfSize = new Vector2(width * 0.5f, height * 0.5f);
        Vector2 innerHalf = halfSize - new Vector2(radius + 1f, radius + 1f);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                Vector2 p = new Vector2(x + 0.5f, y + 0.5f) - halfSize;
                Vector2 q = new Vector2(Mathf.Abs(p.x), Mathf.Abs(p.y)) - innerHalf;
                float dist = Vector2.Max(q, Vector2.zero).magnitude + Mathf.Min(Mathf.Max(q.x, q.y), 0f) - radius;
                float alpha = Mathf.Clamp01(0.5f - dist);
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
            }
        }
        tex.Apply();
        Vector4 border = new Vector4(radius, radius, radius, radius);
        return Sprite.Create(tex, new Rect(0, 0, width, height), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
    }

    private Sprite CreateStarPolygonSprite(int size)
    {
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;

        Vector2 center = new Vector2(size * 0.5f, size * 0.5f);
        float maxR = size * 0.44f;
        float minR = size * 0.20f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                Vector2 dir = new Vector2(x + 0.5f, y + 0.5f) - center;
                float dist = dir.magnitude;
                float angle = Mathf.Atan2(dir.y, dir.x) - Mathf.PI * 0.5f;
                float sector = Mathf.Repeat(angle, Mathf.PI * 2f / 5f);
                float halfSector = Mathf.PI / 5f;
                float starFactor = Mathf.Abs(sector - halfSector) / halfSector;
                float targetRadius = Mathf.Lerp(minR, maxR, starFactor);
                float alpha = Mathf.Clamp01((targetRadius - dist) * 0.8f);
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
            }
        }
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
    }
}