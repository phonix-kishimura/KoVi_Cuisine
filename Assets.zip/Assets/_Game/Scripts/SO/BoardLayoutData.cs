using UnityEngine;

/// <summary>
/// Ý nghĩa của một ô trong layout.
/// - Playable (#): Ô chơi được, chứa Candy.
/// - Empty (.): Khoảng trống không gian, kẹo không thể rơi vào.
/// - Obstacle (X): Ô có vật cản. Khi vật cản bị phá hủy sẽ mở khóa thành ô Playable!
/// </summary>
public enum BoardCellType
{
    Playable, // # : ô chơi được, có thể chứa Candy
    Empty,    // . : khoảng trống, không tạo GameObject
    Obstacle, // X : tạo obstaclePrefab, khi phá vỡ sẽ mở khóa ô nền bên dưới
    Invalid
}

/// <summary>
/// Dữ liệu tái sử dụng cho hình dạng một board.
/// Row 0 được nhập là hàng TRÊN CÙNG; khi truy vấn tọa độ Unity (y=0 ở dưới),
/// dữ liệu tự đổi hàng tương ứng.
/// </summary>
[CreateAssetMenu(fileName = "BoardLayout_New", menuName = "Match 3/Board Layout Data", order = 1)]
public class BoardLayoutData : ScriptableObject
{
    [Header("Dimensions")]
    [SerializeField, Min(3)] private int width = 8;
    [SerializeField, Min(3)] private int height = 8;

    [Header("Layout Rows")]
    [Tooltip("Nhập từ hàng TRÊN xuống hàng DƯỚI. Mỗi hàng phải có đúng Width ký tự. # = ô chơi được, . = khoảng trống, X = vật cản.")]
    [SerializeField] private string[] rows =
    {
        "########",
        "########",
        "########",
        "########",
        "########",
        "########",
        "########",
        "########"
    };

    public int Width => width;
    public int Height => height;
    public int RowCount => rows == null ? 0 : rows.Length;

    /// <summary>
    /// Trả về ký hiệu theo tọa độ Unity. x tăng từ trái sang phải, y tăng từ dưới lên trên.
    /// </summary>
    public char GetSymbol(int x, int y)
    {
        if (x < 0 || x >= width || y < 0 || y >= height || rows == null)
        {
            return '.';
        }

        int rowIndex = height - 1 - y;
        if (rowIndex < 0 || rowIndex >= rows.Length || string.IsNullOrEmpty(rows[rowIndex]))
        {
            return '.';
        }

        string row = rows[rowIndex];
        if (x >= row.Length)
        {
            return '.';
        }

        return row[x];
    }

    public BoardCellType GetCellType(int x, int y)
    {
        switch (GetSymbol(x, y))
        {
            case '#': return BoardCellType.Playable;
            case '.': return BoardCellType.Empty;
            case 'X': return BoardCellType.Obstacle;
            default: return BoardCellType.Invalid;
        }
    }

    /// <summary>Kiểm tra layout trước khi Board tạo GameObject.</summary>
    public bool Validate(out string error, out int playableCount, out bool hasObstacle)
    {
        playableCount = 0;
        hasObstacle = false;
        error = null;

        if (width < 3 || height < 3)
        {
            error = "BoardLayoutData cần Width và Height tối thiểu bằng 3.";
            return false;
        }

        if (rows == null || rows.Length != height)
        {
            error = $"Layout cần đúng {height} hàng nhưng hiện có {(rows == null ? 0 : rows.Length)} hàng.";
            return false;
        }

        for (int rowIndex = 0; rowIndex < rows.Length; rowIndex++)
        {
            string row = rows[rowIndex];
            if (string.IsNullOrEmpty(row) || row.Length != width)
            {
                error = $"Hàng layout {rowIndex} phải có đúng {width} ký tự.";
                return false;
            }

            for (int col = 0; col < row.Length; col++)
            {
                switch (row[col])
                {
                    case '#':
                        playableCount++;
                        break;
                    case '.':
                        break;
                    case 'X':
                        hasObstacle = true;
                        break;
                    default:
                        error = $"Ký tự '{row[col]}' không hợp lệ ở hàng {rowIndex}, cột {col}. Chỉ dùng #, . và X.";
                        return false;
                }
            }
        }

        if (playableCount < 3)
        {
            error = "Layout phải có ít nhất 3 ô chơi được (#).";
            return false;
        }

        return true;
    }
}
