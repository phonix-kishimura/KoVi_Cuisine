﻿using UnityEngine;

/// <summary>
/// ScriptableObject cấu hình dữ liệu cho một Vật cản (Obstacle).
/// - Mỗi Obstacle trên bàn cờ chỉ cần 1 lần va chạm là vỡ ngay lập tức.
/// - Khi vỡ, dựa vào 'spawnCount' (số lần sinh ra obstacle mới), hệ thống sẽ đẻ ra
///   một Obstacle mới tại đúng ô đó với Sprite là hình ảnh bị nứt/vỡ tương ứng.
/// </summary>
[CreateAssetMenu(fileName = "ObstacleData_New", menuName = "Match 3/Obstacle Data", order = 3)]
public class ObstacleData : ScriptableObject
{
    [Header("Thông tin chung")]
    [SerializeField] private string obstacleName = "Vật Cản";

    [Header("Hình ảnh ban đầu (Khi chưa bị va chạm)")]
    [Tooltip("Sprite của Obstacle lúc còn nguyên vẹn (nếu để trống sẽ giữ nguyên Sprite mặc định trên Prefab).")]
    [SerializeField] private Sprite intactSprite;

    [Header("Cấu hình Sinh Obstacle Mới Khi Vỡ (Hiệu ứng vỡ dần)")]
    [Tooltip("Số lần đẻ ra Obstacle mới sau khi Obstacle ban đầu bị vỡ.\n" +
             "- 0: Chạm 1 lần là vỡ hẳn, không đẻ thêm.\n" +
             "- 1: Vỡ 1 lần -> Đẻ ra Obstacle bị nứt (tổng cộng cần 2 lần chạm).\n" +
             "- 2: Vỡ lần 1 -> Đẻ Obstacle nứt 1 -> Vỡ lần 2 -> Đẻ Obstacle nứt 2 (tổng cộng cần 3 lần chạm).")]
    [SerializeField, Min(0)] private int spawnCount = 1;

    [Tooltip("Danh sách các Sprite hình ảnh Obstacle bị vỡ/nứt tương ứng cho từng lần đẻ ra:\n" +
             "- Element 0: Hình ảnh của Obstacle sinh ra ở lần vỡ thứ 1.\n" +
             "- Element 1: Hình ảnh của Obstacle sinh ra ở lần vỡ thứ 2...")]
    [SerializeField] private Sprite[] crackedSprites;

    [Header("Tùy chọn Nâng cao (Không bắt buộc)")]
    [Tooltip("Nếu bạn muốn khi vỡ sẽ sinh ra một file ObstacleData khác hoàn toàn, hãy gán vào đây.")]
    [SerializeField] private ObstacleData nextObstacleData;

    [Tooltip("Prefab riêng cho loại Obstacle này (nếu để trống sẽ dùng Obstacle Prefab chung trên Board).")]
    [SerializeField] private GameObject customObstaclePrefab;

    public string ObstacleName => obstacleName;
    public Sprite IntactSprite => intactSprite;
    public int SpawnCount => spawnCount;
    public Sprite[] CrackedSprites => crackedSprites;
    public ObstacleData NextObstacleData => nextObstacleData;
    public GameObject CustomObstaclePrefab => customObstaclePrefab;

    /// <summary>
    /// Lấy Sprite tương ứng với bước vỡ hiện tại:
    /// - crackStep = 0: Trả về hình ảnh nguyên vẹn ban đầu (intactSprite).
    /// - crackStep >= 1: Trả về hình ảnh bị vỡ trong mảng crackedSprites[crackStep - 1].
    /// </summary>
    public Sprite GetSpriteForCrackStep(int crackStep)
    {
        if (crackStep <= 0)
        {
            return intactSprite;
        }

        if (crackedSprites != null && crackedSprites.Length > 0)
        {
            int index = Mathf.Clamp(crackStep - 1, 0, crackedSprites.Length - 1);
            return crackedSprites[index];
        }

        return intactSprite;
    }
}