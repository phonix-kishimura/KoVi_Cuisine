using System;
using UnityEngine;

public enum LevelGoalType
{
    ReachScore,
    CollectCandy,
    ClearObstacles
}

/// <summary>
/// Cấu trúc một mục tiêu thành phần (dùng khi màn chơi có nhiều mục tiêu kết hợp).
/// </summary>
[Serializable]
public struct LevelGoalEntry
{
    public LevelGoalType goalType;
    [Min(1)] public int targetAmount;
    [Tooltip("Chỉ dùng khi goalType = CollectCandy")]
    [Min(0)] public int candyTypeIndex;
}

/// <summary>
/// Cấu hình của một màn chơi.
/// Hỗ trợ cấu hình ObstacleData (ScriptableObject) để tạo hiệu ứng Obstacle vỡ và đẻ ra Obstacle bị nứt.
/// </summary>
[CreateAssetMenu(fileName = "Level_New", menuName = "Match 3/Level Data", order = 2)]
public class LevelData : ScriptableObject
{
    [Header("Level Information")]
    [SerializeField, Min(1)] private int levelNumber = 1;
    [SerializeField] private string displayName = "Level 1";

    [Header("Board Layout")]
    [SerializeField] private BoardLayoutData boardLayout;

    [Header("Candy Configuration (Optional Override)")]
    [Tooltip("Nếu gán danh sách kẹo ở đây, màn chơi sẽ dùng danh sách này thay vì mảng dots trên BackgroundTiile.")]
    [SerializeField] private GameObject[] customCandyPrefabs;

    [Header("Obstacle Configuration (ScriptableObject)")]
    [Tooltip("Cấu hình Obstacle mặc định cho ký hiệu 'X' trong màn chơi này (Quy định số lần sinh ra Obstacle bị vỡ và các Sprite bị vỡ).")]
    [SerializeField] private ObstacleData obstacleData;

    [Tooltip("Tùy chọn: Nếu trong BoardLayoutData bạn dùng các ký hiệu số '1', '2', '3'... bạn có thể gán từng file ObstacleData tương ứng vào mảng này (Element 0 cho '1', Element 1 cho '2'...).")]
    [SerializeField] private ObstacleData[] customObstaclePalette;

    [Tooltip("Dự phòng: Nếu chưa gán file ObstacleData ở trên, số lần sinh ra Obstacle mới sẽ bằng (obstacleHitPoints - 1).")]
    [SerializeField, Min(1)] private int obstacleHitPoints = 1;

    [Header("Primary Goal Settings")]
    [SerializeField] private LevelGoalType goalType = LevelGoalType.ReachScore;
    [SerializeField, Min(1)] private int moveLimit = 25;
    [SerializeField, Min(0)] private int targetScore = 1000;
    [Tooltip("Index của loại kẹo trong mảng dots. Chỉ dùng khi Goal Type = CollectCandy.")]
    [SerializeField, Min(0)] private int targetCandyTypeIndex = 0;
    [SerializeField, Min(0)] private int targetCandyCount = 20;
    [SerializeField, Min(0)] private int targetObstacleCount = 0;

    [Header("Multi-Goal Extension (Tùy chọn thêm nhiều mục tiêu)")]
    [Tooltip("Có thể thêm nhiều mục tiêu phụ tại đây (ví dụ: vừa ăn 20 kẹo Đỏ vừa phá 5 Vật cản).")]
    [SerializeField] private LevelGoalEntry[] additionalGoals;

    public int LevelNumber => levelNumber;
    public string DisplayName => displayName;
    public BoardLayoutData BoardLayout => boardLayout;
    public GameObject[] CustomCandyPrefabs => customCandyPrefabs;
    public ObstacleData PrimaryObstacleData => obstacleData;
    public ObstacleData[] CustomObstaclePalette => customObstaclePalette;
    public int ObstacleHitPoints => obstacleHitPoints;
    public LevelGoalType GoalType => goalType;
    public int MoveLimit => moveLimit;
    public int TargetScore => targetScore;
    public int TargetCandyTypeIndex => targetCandyTypeIndex;
    public int TargetCandyCount => targetCandyCount;
    public int TargetObstacleCount => targetObstacleCount;
    public LevelGoalEntry[] AdditionalGoals => additionalGoals;

    /// <summary>
    /// Lấy ObstacleData tương ứng với ký hiệu trên BoardLayoutData ('X' hoặc '1'..'9').
    /// </summary>
    public ObstacleData GetObstacleDataForSymbol(char symbol, ObstacleData fallbackOnBoard)
    {
        if (symbol >= '1' && symbol <= '9')
        {
            int index = symbol - '1';
            if (customObstaclePalette != null && index >= 0 && index < customObstaclePalette.Length && customObstaclePalette[index] != null)
            {
                return customObstaclePalette[index];
            }
        }

        return obstacleData != null ? obstacleData : fallbackOnBoard;
    }
}