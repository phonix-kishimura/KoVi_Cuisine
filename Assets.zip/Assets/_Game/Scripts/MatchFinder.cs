using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Đại diện cho một cụm kẹo được nối với nhau tạo thành Match hợp lệ.
/// </summary>
public class MatchGroup
{
    public int CandyType;
    public List<BackgroundTiile> Cells = new List<BackgroundTiile>();
    public SpecialCandyType SpawnedSpecialType = SpecialCandyType.None;
    public BackgroundTiile SpawnCell;
}

/// <summary>
/// Bộ máy phân tích chuỗi Match-3 hỗ trợ KẸO ĐẶC BIỆT TRUNG TÍNH (Wildcard):
/// -----------------------------------------------------------------------------------------
/// - Nguyên tắc Trung Tính: Mọi Kẹo Đặc Biệt đều không phân màu và có thể ghép chung với
///   BẤT KỲ màu kẹo thường nào để tạo thành chuỗi Match-3, Match-4, Match-5, L/T hoặc Vuông 2x2.
///   Ví dụ: [Đỏ] + [Kẹo Đặc Biệt] + [Đỏ] -> Tạo thành Match 3 hợp lệ!
/// -----------------------------------------------------------------------------------------
/// Thứ tự ưu tiên sinh Kẹo Đặc Biệt:
/// 1. MATCH 5+ (Thẳng hàng >= 5 viên) -> Tạo BOM MÀU (ColorBomb).
/// 2. MATCH L / T (Giao điểm ngang >= 3 và dọc >= 3) -> Tạo KẸO GÓI (Wrapped).
/// 3. MATCH 4 (Thẳng hàng 4 viên) -> Tạo KẸO SỌC (StripedVertical / StripedHorizontal).
/// 4. MATCH SQUARE (Khối vuông 2x2) -> Tạo KẸO CÁ (SugarFish).
/// 5. MATCH 3 (3 viên cơ bản) -> Xóa kẹo và kích hoạt nổ nếu trong chuỗi có sẵn Kẹo Đặc Biệt.
/// </summary>
public class MatchFinder
{
    private readonly Board board;

    private struct LineSegment
    {
        public int type; // Mã màu của chuỗi (-1 nếu cả chuỗi toàn là Kẹo Đặc Biệt)
        public bool isHorizontal;
        public List<BackgroundTiile> cells;
    }

    private struct SquareBlock
    {
        public int type;
        public List<BackgroundTiile> cells;
    }

    public MatchFinder(Board board)
    {
        this.board = board;
    }

    /// <summary>
    /// Quét toàn bộ bàn cờ, tìm các chuỗi ngang, dọc, ô vuông 2x2 (có tính Kẹo Đặc Biệt là trung tính)
    /// và gom thành các cụm MatchGroup.
    /// </summary>
    public List<MatchGroup> FindAllMatchGroups(BackgroundTiile swappedA = null, BackgroundTiile swappedB = null)
    {
        List<LineSegment> segments = new List<LineSegment>();
        List<SquareBlock> squares = new List<SquareBlock>();

        // BƯỚC 1: Quét tất cả chuỗi NGANG >= 3
        for (int y = 0; y < board.Height; y++)
        {
            ScanLineForMatches(isHorizontal: true, fixedIndex: y, segments);
        }

        // BƯỚC 2: Quét tất cả chuỗi DỌC >= 3
        for (int x = 0; x < board.Width; x++)
        {
            ScanLineForMatches(isHorizontal: false, fixedIndex: x, segments);
        }

        // BƯỚC 3: Quét tất cả khối vuông 2x2 (MATCH SQUARE)
        for (int x = 0; x < board.Width - 1; x++)
        {
            for (int y = 0; y < board.Height - 1; y++)
            {
                BackgroundTiile c00 = board.GetTile(x, y);
                BackgroundTiile c10 = board.GetTile(x + 1, y);
                BackgroundTiile c01 = board.GetTile(x, y + 1);
                BackgroundTiile c11 = board.GetTile(x + 1, y + 1);

                if (AreTilesCompatibleGroup(out int resolvedColor, c00, c10, c01, c11))
                {
                    squares.Add(new SquareBlock
                    {
                        type = resolvedColor,
                        cells = new List<BackgroundTiile> { c00, c10, c01, c11 }
                    });
                }
            }
        }

        if (segments.Count == 0 && squares.Count == 0)
        {
            return new List<MatchGroup>();
        }

        // BƯỚC 4: Gom các đoạn thẳng và khối vuông giao nhau thành từng cụm MatchGroup
        return BuildConnectedMatchGroups(segments, squares, swappedA, swappedB);
    }

    /// <summary>
    /// Quét một hàng ngang hoặc một cột dọc để tìm các chuỗi >= 3 viên khớp nhau.
    /// Hỗ trợ Kẹo Đặc Biệt làm cầu nối trung tính (Wildcard) giữa các viên kẹo.
    /// </summary>
    private void ScanLineForMatches(bool isHorizontal, int fixedIndex, List<LineSegment> outputSegments)
    {
        int maxLen = isHorizontal ? board.Width : board.Height;
        int i = 0;

        while (i < maxLen)
        {
            BackgroundTiile startCell = GetCellAlongLine(isHorizontal, fixedIndex, i);
            if (startCell == null || startCell.CurrentCandy == null)
            {
                i++;
                continue;
            }

            // lockedColor lưu màu của kẹo thường trong chuỗi đang xét.
            // Nếu viên đầu tiên là Kẹo Đặc Biệt trung tính, lockedColor tạm thời là -1 (chưa khóa màu)
            // cho đến khi gặp viên kẹo thường đầu tiên.
            int lockedColor = startCell.CurrentCandy.IsNeutralSpecial
                ? Candy.NEUTRAL_COLOR_ID
                : startCell.CurrentCandy.TypeIndex;

            int end = i + 1;
            while (end < maxLen)
            {
                BackgroundTiile nextCell = GetCellAlongLine(isHorizontal, fixedIndex, end);
                if (nextCell == null || nextCell.CurrentCandy == null)
                {
                    break;
                }

                Candy nextCandy = nextCell.CurrentCandy;

                if (nextCandy.IsNeutralSpecial)
                {
                    // Kẹo đặc biệt trung tính luôn ghép được vào chuỗi hiện tại
                    end++;
                }
                else if (lockedColor == Candy.NEUTRAL_COLOR_ID)
                {
                    // Chuỗi bắt đầu bằng Kẹo Đặc Biệt và giờ gặp viên kẹo thường đầu tiên -> Khóa màu theo viên này
                    lockedColor = nextCandy.TypeIndex;
                    end++;
                }
                else if (nextCandy.TypeIndex == lockedColor)
                {
                    // Kẹo thường cùng màu với chuỗi hiện tại
                    end++;
                }
                else
                {
                    // Gặp kẹo thường khác màu -> Dừng chuỗi
                    break;
                }
            }

            int length = end - i;
            if (length >= 3)
            {
                LineSegment seg = new LineSegment
                {
                    type = lockedColor,
                    isHorizontal = isHorizontal,
                    cells = new List<BackgroundTiile>(length)
                };

                for (int idx = i; idx < end; idx++)
                {
                    seg.cells.Add(GetCellAlongLine(isHorizontal, fixedIndex, idx));
                }

                outputSegments.Add(seg);
            }

            // XỬ LÝ LÙI CHỈ SỐ KHI CUỐI CHUỖI LÀ KẸO ĐẶC BIỆT TRUNG TÍNH:
            // Ví dụ hàng ngang có: [Đỏ] - [Đỏ] - [Kẹo Đặc Biệt] - [Xanh] - [Xanh].
            // Sau khi quét xong [Đỏ, Đỏ, Kẹo Đặc Biệt], nếu nhảy thẳng sang [Xanh] thì sẽ bỏ sót
            // chuỗi [Kẹo Đặc Biệt, Xanh, Xanh]. Do đó ta lùi lại qua các viên Kẹo Đặc Biệt ở cuối chuỗi.
            if (end < maxLen)
            {
                BackgroundTiile stoppedAtCell = GetCellAlongLine(isHorizontal, fixedIndex, end);
                if (stoppedAtCell != null && stoppedAtCell.CurrentCandy != null)
                {
                    int rollback = end;
                    while (rollback > i + 1)
                    {
                        BackgroundTiile prevCell = GetCellAlongLine(isHorizontal, fixedIndex, rollback - 1);
                        if (prevCell != null && prevCell.CurrentCandy != null && prevCell.CurrentCandy.IsNeutralSpecial)
                        {
                            rollback--;
                        }
                        else
                        {
                            break;
                        }
                    }
                    i = rollback;
                    continue;
                }
            }

            i = end;
        }
    }

    private BackgroundTiile GetCellAlongLine(bool isHorizontal, int fixedIndex, int runningIndex)
    {
        return isHorizontal
            ? board.GetTile(runningIndex, fixedIndex)
            : board.GetTile(fixedIndex, runningIndex);
    }

    private List<MatchGroup> BuildConnectedMatchGroups(
        List<LineSegment> segments,
        List<SquareBlock> squares,
        BackgroundTiile swappedA,
        BackgroundTiile swappedB)
    {
        List<MatchGroup> results = new List<MatchGroup>();
        bool[] usedSegments = new bool[segments.Count];
        bool[] usedSquares = new bool[squares.Count];

        for (int i = 0; i < segments.Count; i++)
        {
            if (usedSegments[i]) continue;

            usedSegments[i] = true;
            int groupType = segments[i].type;

            HashSet<BackgroundTiile> clusterCells = new HashSet<BackgroundTiile>(segments[i].cells);
            List<LineSegment> clusterSegments = new List<LineSegment> { segments[i] };
            List<SquareBlock> clusterSquares = new List<SquareBlock>();

            // Mở rộng cụm nếu có các đoạn thẳng hoặc ô vuông 2x2 tương thích màu giao nhau
            bool addedNew;
            do
            {
                addedNew = false;

                for (int j = 0; j < segments.Count; j++)
                {
                    if (usedSegments[j] || !AreGroupTypesCompatible(groupType, segments[j].type)) continue;
                    if (Overlaps(clusterCells, segments[j].cells))
                    {
                        usedSegments[j] = true;
                        if (groupType == Candy.NEUTRAL_COLOR_ID && segments[j].type != Candy.NEUTRAL_COLOR_ID)
                        {
                            groupType = segments[j].type;
                        }
                        clusterSegments.Add(segments[j]);
                        foreach (var c in segments[j].cells) clusterCells.Add(c);
                        addedNew = true;
                    }
                }

                for (int k = 0; k < squares.Count; k++)
                {
                    if (usedSquares[k] || !AreGroupTypesCompatible(groupType, squares[k].type)) continue;
                    if (Overlaps(clusterCells, squares[k].cells))
                    {
                        usedSquares[k] = true;
                        if (groupType == Candy.NEUTRAL_COLOR_ID && squares[k].type != Candy.NEUTRAL_COLOR_ID)
                        {
                            groupType = squares[k].type;
                        }
                        clusterSquares.Add(squares[k]);
                        foreach (var c in squares[k].cells) clusterCells.Add(c);
                        addedNew = true;
                    }
                }
            } while (addedNew);

            MatchGroup group = ClassifyCluster(groupType, clusterCells, clusterSegments, clusterSquares, swappedA, swappedB);
            results.Add(group);
        }

        // Xử lý các khối vuông 2x2 độc lập (không giao với đoạn thẳng >= 3 nào)
        for (int k = 0; k < squares.Count; k++)
        {
            if (usedSquares[k]) continue;

            usedSquares[k] = true;
            int groupType = squares[k].type;
            HashSet<BackgroundTiile> clusterCells = new HashSet<BackgroundTiile>(squares[k].cells);
            List<SquareBlock> clusterSquares = new List<SquareBlock> { squares[k] };

            for (int m = k + 1; m < squares.Count; m++)
            {
                if (usedSquares[m] || !AreGroupTypesCompatible(groupType, squares[m].type)) continue;
                if (Overlaps(clusterCells, squares[m].cells))
                {
                    usedSquares[m] = true;
                    if (groupType == Candy.NEUTRAL_COLOR_ID && squares[m].type != Candy.NEUTRAL_COLOR_ID)
                    {
                        groupType = squares[m].type;
                    }
                    clusterSquares.Add(squares[m]);
                    foreach (var c in squares[m].cells) clusterCells.Add(c);
                }
            }

            MatchGroup group = ClassifyCluster(groupType, clusterCells, new List<LineSegment>(), clusterSquares, swappedA, swappedB);
            results.Add(group);
        }

        return results;
    }

    /// <summary>
    /// Kiểm tra 2 nhóm màu có thể gộp chung thành cụm L/T hay không.
    /// Cho phép gộp nếu cùng màu hoặc một trong hai chuỗi toàn là Kẹo Đặc Biệt trung tính (-1).
    /// </summary>
    private bool AreGroupTypesCompatible(int typeA, int typeB)
    {
        if (typeA == Candy.NEUTRAL_COLOR_ID || typeB == Candy.NEUTRAL_COLOR_ID)
        {
            return true;
        }
        return typeA == typeB;
    }

    private MatchGroup ClassifyCluster(
        int candyType,
        HashSet<BackgroundTiile> clusterCells,
        List<LineSegment> clusterSegments,
        List<SquareBlock> clusterSquares,
        BackgroundTiile swappedA,
        BackgroundTiile swappedB)
    {
        // Đảm bảo CandyType luôn >= 0 để nếu Board gọi CandyPool.SpawnCandy(group.CandyType) luôn hợp lệ
        int safeCandyType = candyType >= 0 ? candyType : 0;

        MatchGroup group = new MatchGroup
        {
            CandyType = safeCandyType,
            Cells = new List<BackgroundTiile>(clusterCells),
            SpawnedSpecialType = SpecialCandyType.None
        };

        int maxHorizontalLen = 0;
        int maxVerticalLen = 0;
        bool hasHorizontal = false;
        bool hasVertical = false;

        for (int i = 0; i < clusterSegments.Count; i++)
        {
            int len = clusterSegments[i].cells.Count;
            if (clusterSegments[i].isHorizontal)
            {
                hasHorizontal = true;
                if (len > maxHorizontalLen) maxHorizontalLen = len;
            }
            else
            {
                hasVertical = true;
                if (len > maxVerticalLen) maxVerticalLen = len;
            }
        }

        // 1. Ưu tiên 1: MATCH 5+ thẳng hàng -> Tạo Bom Màu (ColorBomb)
        if (maxHorizontalLen >= 5 || maxVerticalLen >= 5)
        {
            group.SpawnedSpecialType = SpecialCandyType.ColorBomb;
        }
        // 2. Ưu tiên 2: Giao điểm chữ L hoặc chữ T -> Tạo Kẹo Gói (Wrapped)
        else if (hasHorizontal && hasVertical)
        {
            group.SpawnedSpecialType = SpecialCandyType.Wrapped;
        }
        // 3. Ưu tiên 3: MATCH 4 thẳng hàng -> Tạo Kẹo Sọc (Striped)
        else if (maxHorizontalLen == 4)
        {
            group.SpawnedSpecialType = SpecialCandyType.StripedVertical;
        }
        else if (maxVerticalLen == 4)
        {
            group.SpawnedSpecialType = SpecialCandyType.StripedHorizontal;
        }
        // 4. Ưu tiên 4: MATCH SQUARE (Khối vuông 2x2) -> Tạo Kẹo Cá (SugarFish)
        else if (clusterSquares.Count > 0)
        {
            group.SpawnedSpecialType = SpecialCandyType.SugarFish;
        }

        // Chọn ô sinh ra Kẹo Đặc Biệt mới:
        // Ưu tiên đặt tại ô người chơi vừa vuốt (và ưu tiên ô đang là kẹo thường để không đè lên kẹo đặc biệt cũ đang chuẩn bị nổ)
        if (group.SpawnedSpecialType != SpecialCandyType.None)
        {
            if (swappedB != null && clusterCells.Contains(swappedB) && !IsTileHoldingSpecial(swappedB))
            {
                group.SpawnCell = swappedB;
            }
            else if (swappedA != null && clusterCells.Contains(swappedA) && !IsTileHoldingSpecial(swappedA))
            {
                group.SpawnCell = swappedA;
            }
            else
            {
                group.SpawnCell = FindBestSpawnCell(group.Cells, clusterSegments);
            }
        }

        return group;
    }

    private bool IsTileHoldingSpecial(BackgroundTiile tile)
    {
        return tile != null && tile.CurrentCandy != null && tile.CurrentCandy.IsNeutralSpecial;
    }

    private BackgroundTiile FindBestSpawnCell(List<BackgroundTiile> cells, List<LineSegment> segments)
    {
        // 1. Tìm ô giao điểm giữa đoạn ngang và đoạn dọc (nếu là Match L/T) mà chưa chứa kẹo đặc biệt
        if (segments.Count >= 2)
        {
            for (int i = 0; i < segments.Count; i++)
            {
                for (int j = i + 1; j < segments.Count; j++)
                {
                    foreach (var cell in segments[i].cells)
                    {
                        if (segments[j].cells.Contains(cell) && !IsTileHoldingSpecial(cell))
                        {
                            return cell;
                        }
                    }
                }
            }
        }

        // 2. Ưu tiên chọn một ô kẹo thường trong cụm để sinh Kẹo Đặc Biệt mới
        for (int i = 0; i < cells.Count; i++)
        {
            if (!IsTileHoldingSpecial(cells[i]))
            {
                return cells[i];
            }
        }

        return cells[cells.Count / 2];
    }

    private bool Overlaps(HashSet<BackgroundTiile> set, List<BackgroundTiile> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            if (set.Contains(list[i]))
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Kiểm tra nhanh tại đúng tọa độ (x, y) xem có tạo thành Match-3 ngang, Match-3 dọc,
    /// hoặc Match Square 2x2 hay không (có hỗ trợ Kẹo Đặc Biệt trung tính).
    /// Cách kiểm tra: Bất kỳ chuỗi Match >= 3 nào đi qua (x, y) đều phải chứa ít nhất 1 bộ 3 ô liên tiếp đi qua (x, y).
    /// </summary>
    public bool HasMatchAt(int x, int y)
    {
        BackgroundTiile center = board.GetTile(x, y);
        if (center == null || center.CurrentCandy == null)
        {
            return false;
        }

        // 1. Kiểm tra 3 cửa sổ ngang (3 ô liên tiếp) đi qua (x, y): [x-2..x], [x-1..x+1], [x..x+2]
        if (IsThreeInARowCompatible(board.GetTile(x - 2, y), board.GetTile(x - 1, y), center) ||
            IsThreeInARowCompatible(board.GetTile(x - 1, y), center, board.GetTile(x + 1, y)) ||
            IsThreeInARowCompatible(center, board.GetTile(x + 1, y), board.GetTile(x + 2, y)))
        {
            return true;
        }

        // 2. Kiểm tra 3 cửa sổ dọc (3 ô liên tiếp) đi qua (x, y): [y-2..y], [y-1..y+1], [y..y+2]
        if (IsThreeInARowCompatible(board.GetTile(x, y - 2), board.GetTile(x, y - 1), center) ||
            IsThreeInARowCompatible(board.GetTile(x, y - 1), center, board.GetTile(x, y + 1)) ||
            IsThreeInARowCompatible(center, board.GetTile(x, y + 1), board.GetTile(x, y + 2)))
        {
            return true;
        }

        // 3. Kiểm tra 4 góc khối vuông 2x2 có chứa ô (x, y)
        if (IsSquareMatchAtBottomLeft(x, y) ||
            IsSquareMatchAtBottomLeft(x - 1, y) ||
            IsSquareMatchAtBottomLeft(x, y - 1) ||
            IsSquareMatchAtBottomLeft(x - 1, y - 1))
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Kiểm tra 3 ô liên tiếp có tạo thành Match-3 hợp lệ hay không (Zero GC Allocation).
    /// Hợp lệ khi cả 3 ô đều có kẹo, và tất cả các viên kẹo thường trong 3 ô đó có cùng màu
    /// (các viên Kẹo Đặc Biệt trung tính tự động khớp với mọi màu).
    /// </summary>
    private bool IsThreeInARowCompatible(BackgroundTiile a, BackgroundTiile b, BackgroundTiile c)
    {
        if (a?.CurrentCandy == null || b?.CurrentCandy == null || c?.CurrentCandy == null)
        {
            return false;
        }

        int lockedColor = Candy.NEUTRAL_COLOR_ID;

        if (!CheckCandyCompatibility(a.CurrentCandy, ref lockedColor)) return false;
        if (!CheckCandyCompatibility(b.CurrentCandy, ref lockedColor)) return false;
        if (!CheckCandyCompatibility(c.CurrentCandy, ref lockedColor)) return false;

        return true;
    }

    private bool IsSquareMatchAtBottomLeft(int blX, int blY)
    {
        if (blX < 0 || blY < 0 || blX + 1 >= board.Width || blY + 1 >= board.Height)
        {
            return false;
        }

        return AreTilesCompatibleGroup(
            out _,
            board.GetTile(blX, blY),
            board.GetTile(blX + 1, blY),
            board.GetTile(blX, blY + 1),
            board.GetTile(blX + 1, blY + 1));
    }

    /// <summary>
    /// Kiểm tra 4 ô của khối vuông 2x2 có khớp màu nhau (hoặc là Kẹo Đặc Biệt trung tính) hay không.
    /// </summary>
    private bool AreTilesCompatibleGroup(
        out int resolvedColor,
        BackgroundTiile t1,
        BackgroundTiile t2,
        BackgroundTiile t3,
        BackgroundTiile t4)
    {
        resolvedColor = Candy.NEUTRAL_COLOR_ID;

        if (t1?.CurrentCandy == null || t2?.CurrentCandy == null ||
            t3?.CurrentCandy == null || t4?.CurrentCandy == null)
        {
            return false;
        }

        if (!CheckCandyCompatibility(t1.CurrentCandy, ref resolvedColor)) return false;
        if (!CheckCandyCompatibility(t2.CurrentCandy, ref resolvedColor)) return false;
        if (!CheckCandyCompatibility(t3.CurrentCandy, ref resolvedColor)) return false;
        if (!CheckCandyCompatibility(t4.CurrentCandy, ref resolvedColor)) return false;

        return true;
    }

    /// <summary>
    /// Hàm phụ trợ kiểm tra từng viên kẹo:
    /// - Nếu là Kẹo Đặc Biệt trung tính -> Luôn hợp lệ.
    /// - Nếu là Kẹo Thường -> Phải khớp với lockedColor (hoặc gán làm lockedColor nếu chưa có).
    /// </summary>
    private bool CheckCandyCompatibility(Candy candy, ref int lockedColor)
    {
        if (candy.IsNeutralSpecial)
        {
            return true;
        }

        if (lockedColor == Candy.NEUTRAL_COLOR_ID)
        {
            lockedColor = candy.TypeIndex;
            return true;
        }

        return candy.TypeIndex == lockedColor;
    }

    /// <summary>
    /// Kiểm tra bàn cờ hiện tại có bất kỳ Match nào đang tồn tại hay không.
    /// </summary>
    public bool HasAnyMatchOnBoard()
    {
        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile tile = board.PlayableTiles[i];
            if (HasMatchAt(tile.X, tile.Y))
            {
                return true;
            }
        }
        return false;
    }
}