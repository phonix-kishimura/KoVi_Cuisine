using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Xử lý toàn bộ logic kích hoạt nổ của Kẹo Đặc Biệt và các pha kết hợp (Combo) 2 Kẹo Đặc Biệt.
/// Tích hợp trực tiếp với Match3VFXManager để vẽ tia nổ ngang, dọc, sóng xung kích 3x3/5x5,
/// tia sét Bom Màu và đường bơi của Kẹo Cá.
/// </summary>
public class SpecialCandyProcessor
{
    private readonly Board board;

    public SpecialCandyProcessor(Board board)
    {
        this.board = board;
    }

    /// <summary>
    /// Mở rộng danh sách các ô cần xóa nếu bên trong có chứa Kẹo Đặc Biệt (Xử lý nổ dây chuyền)
    /// và phát hiệu ứng hình ảnh đặc trưng cho từng loại Kẹo Đặc Biệt.
    /// </summary>
    public void ExpandSpecialChainReactions(
        HashSet<BackgroundTiile> cellsToClear,
        HashSet<Vector2Int> blastedCoordinates,
        int preferredTargetColor = -1)
    {
        Queue<BackgroundTiile> queue = new Queue<BackgroundTiile>(cellsToClear);
        HashSet<BackgroundTiile> triggeredSpecials = new HashSet<BackgroundTiile>();

        while (queue.Count > 0)
        {
            BackgroundTiile current = queue.Dequeue();
            if (current == null || current.CurrentCandy == null)
            {
                continue;
            }

            Candy candy = current.CurrentCandy;
            if (candy.SpecialType == SpecialCandyType.None || triggeredSpecials.Contains(current))
            {
                continue;
            }

            triggeredSpecials.Add(current);
            List<BackgroundTiile> newlyAffected = new List<BackgroundTiile>();
            Vector3 originWorldPos = current.transform.position;

            switch (candy.SpecialType)
            {
                case SpecialCandyType.StripedHorizontal:
                    CollectRow(current.Y, newlyAffected, blastedCoordinates);
                    Match3VFXManager.Instance?.PlayStripedBeam(originWorldPos, isHorizontal: true, board);
                    break;

                case SpecialCandyType.StripedVertical:
                    CollectColumn(current.X, newlyAffected, blastedCoordinates);
                    Match3VFXManager.Instance?.PlayStripedBeam(originWorldPos, isHorizontal: false, board);
                    break;

                case SpecialCandyType.Wrapped:
                    CollectArea(current.X, current.Y, 1, newlyAffected, blastedCoordinates);
                    Match3VFXManager.Instance?.PlayWrappedBlast(originWorldPos, radius: 1, board);
                    break;

                case SpecialCandyType.ColorBomb:
                    int targetColor = preferredTargetColor >= 0 ? preferredTargetColor : GetMostFrequentColorOnBoard();
                    CollectByColor(targetColor, newlyAffected, blastedCoordinates);
                    Match3VFXManager.Instance?.PlayColorBombLightning(originWorldPos, newlyAffected, board.CellSize);
                    break;

                case SpecialCandyType.SugarFish:
                    CollectFishTargets(current, newlyAffected, blastedCoordinates);
                    break;
            }

            for (int i = 0; i < newlyAffected.Count; i++)
            {
                BackgroundTiile affected = newlyAffected[i];
                if (affected != null && cellsToClear.Add(affected))
                {
                    queue.Enqueue(affected);
                }
            }
        }
    }

    public bool CanTriggerDirectSpecialSwap(BackgroundTiile cellA, BackgroundTiile cellB)
    {
        if (cellA?.CurrentCandy == null || cellB?.CurrentCandy == null)
        {
            return false;
        }

        SpecialCandyType spA = cellA.CurrentCandy.SpecialType;
        SpecialCandyType spB = cellB.CurrentCandy.SpecialType;

        if (spA == SpecialCandyType.ColorBomb || spB == SpecialCandyType.ColorBomb)
        {
            return true;
        }

        if (spA == SpecialCandyType.SugarFish || spB == SpecialCandyType.SugarFish)
        {
            return true;
        }

        return spA != SpecialCandyType.None && spB != SpecialCandyType.None;
    }

    /// <summary>
    /// Thực thi hiệu ứng kết hợp khi người chơi vuốt trực tiếp 2 Kẹo Đặc Biệt (hoặc Bom Màu/Kẹo Cá + kẹo thường).
    /// </summary>
    public void CollectDirectSpecialCombo(
        BackgroundTiile cellA,
        BackgroundTiile cellB,
        HashSet<BackgroundTiile> cellsToClear,
        HashSet<Vector2Int> blastedCoordinates)
    {
        Candy candyA = cellA.CurrentCandy;
        Candy candyB = cellB.CurrentCandy;
        if (candyA == null || candyB == null)
        {
            return;
        }

        SpecialCandyType spA = candyA.SpecialType;
        SpecialCandyType spB = candyB.SpecialType;

        cellsToClear.Add(cellA);
        cellsToClear.Add(cellB);

        List<BackgroundTiile> affected = new List<BackgroundTiile>();
        Vector3 comboOrigin = cellB.transform.position;

        // TRƯỜNG HỢP 1: Cả 2 đều là Bom Màu -> Đại hồng thủy quét sạch toàn bộ bàn cờ!
        if (spA == SpecialCandyType.ColorBomb && spB == SpecialCandyType.ColorBomb)
        {
            for (int x = 0; x < board.Width; x++)
            {
                for (int y = 0; y < board.Height; y++)
                {
                    blastedCoordinates.Add(new Vector2Int(x, y));
                    BackgroundTiile t = board.GetTile(x, y);
                    if (t != null) affected.Add(t);
                }
            }
            Match3VFXManager.Instance?.PlayWrappedBlast(board.BoardWorldCenter, Mathf.Max(board.Width, board.Height), board);
            Match3VFXManager.Instance?.PlayColorBombLightning(comboOrigin, affected, board.CellSize);
        }
        // TRƯỜNG HỢP 2: Một viên là Bom Màu + một viên kẹo khác
        else if (spA == SpecialCandyType.ColorBomb || spB == SpecialCandyType.ColorBomb)
        {
            Candy bombCandy = spA == SpecialCandyType.ColorBomb ? candyA : candyB;
            Candy otherCandy = spA == SpecialCandyType.ColorBomb ? candyB : candyA;
            Vector3 bombPos = bombCandy.transform.position;

            if (otherCandy.IsNeutralSpecial)
            {
                int mostFrequentColor = GetMostFrequentColorOnBoard();
                for (int i = 0; i < board.PlayableTiles.Count; i++)
                {
                    BackgroundTiile tile = board.PlayableTiles[i];
                    if (tile.CurrentCandy != null &&
                        !tile.CurrentCandy.IsNeutralSpecial &&
                        tile.CurrentCandy.TypeIndex == mostFrequentColor)
                    {
                        tile.CurrentCandy.SetSpecialType(otherCandy.SpecialType);
                        affected.Add(tile);
                    }
                }
            }
            else
            {
                CollectByColor(otherCandy.TypeIndex, affected, blastedCoordinates);
            }

            Match3VFXManager.Instance?.PlayColorBombLightning(bombPos, affected, board.CellSize);
        }
        // TRƯỜNG HỢP 3: Kẹo Gói + Kẹo Gói -> Đại chấn động vùng 5x5!
        else if (spA == SpecialCandyType.Wrapped && spB == SpecialCandyType.Wrapped)
        {
            CollectArea(cellB.X, cellB.Y, 2, affected, blastedCoordinates);
            Match3VFXManager.Instance?.PlayWrappedBlast(comboOrigin, radius: 2, board);
        }
        // TRƯỜNG HỢP 4: Kẹo Gói + Kẹo Sọc -> Nổ 3 hàng ngang và 3 cột dọc khổng lồ!
        else if ((spA == SpecialCandyType.Wrapped && IsStriped(spB)) ||
                 (spB == SpecialCandyType.Wrapped && IsStriped(spA)))
        {
            for (int offset = -1; offset <= 1; offset++)
            {
                CollectRow(cellB.Y + offset, affected, blastedCoordinates);
                CollectColumn(cellB.X + offset, affected, blastedCoordinates);

                Vector2 rowPos = board.GetCellPosition(cellB.X, Mathf.Clamp(cellB.Y + offset, 0, board.Height - 1));
                Vector2 colPos = board.GetCellPosition(Mathf.Clamp(cellB.X + offset, 0, board.Width - 1), cellB.Y);
                Match3VFXManager.Instance?.PlayStripedBeam(rowPos, isHorizontal: true, board);
                Match3VFXManager.Instance?.PlayStripedBeam(colPos, isHorizontal: false, board);
            }
        }
        // TRƯỜNG HỢP 5: Kẹo Sọc + Kẹo Sọc -> Nổ chữ thập (+) gồm 1 hàng ngang và 1 cột dọc qua tâm!
        else if (IsStriped(spA) && IsStriped(spB))
        {
            CollectRow(cellB.Y, affected, blastedCoordinates);
            CollectColumn(cellB.X, affected, blastedCoordinates);
            Match3VFXManager.Instance?.PlayStripedBeam(comboOrigin, isHorizontal: true, board);
            Match3VFXManager.Instance?.PlayStripedBeam(comboOrigin, isHorizontal: false, board);
        }

        for (int i = 0; i < affected.Count; i++)
        {
            if (affected[i] != null)
            {
                cellsToClear.Add(affected[i]);
            }
        }

        ExpandSpecialChainReactions(cellsToClear, blastedCoordinates);
    }

    private bool IsStriped(SpecialCandyType type)
    {
        return type == SpecialCandyType.StripedHorizontal || type == SpecialCandyType.StripedVertical;
    }

    private void CollectRow(int y, List<BackgroundTiile> output, HashSet<Vector2Int> blastedCoords)
    {
        if (y < 0 || y >= board.Height) return;
        for (int x = 0; x < board.Width; x++)
        {
            blastedCoords.Add(new Vector2Int(x, y));
            BackgroundTiile tile = board.GetTile(x, y);
            if (tile != null) output.Add(tile);
        }
    }

    private void CollectColumn(int x, List<BackgroundTiile> output, HashSet<Vector2Int> blastedCoords)
    {
        if (x < 0 || x >= board.Width) return;
        for (int y = 0; y < board.Height; y++)
        {
            blastedCoords.Add(new Vector2Int(x, y));
            BackgroundTiile tile = board.GetTile(x, y);
            if (tile != null) output.Add(tile);
        }
    }

    private void CollectArea(int centerX, int centerY, int radius, List<BackgroundTiile> output, HashSet<Vector2Int> blastedCoords)
    {
        for (int x = centerX - radius; x <= centerX + radius; x++)
        {
            for (int y = centerY - radius; y <= centerY + radius; y++)
            {
                if (x < 0 || x >= board.Width || y < 0 || y >= board.Height) continue;
                blastedCoords.Add(new Vector2Int(x, y));
                BackgroundTiile tile = board.GetTile(x, y);
                if (tile != null) output.Add(tile);
            }
        }
    }

    private void CollectByColor(int targetTypeIndex, List<BackgroundTiile> output, HashSet<Vector2Int> blastedCoords)
    {
        if (targetTypeIndex < 0) return;

        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            BackgroundTiile tile = board.PlayableTiles[i];
            if (tile.CurrentCandy != null &&
                !tile.CurrentCandy.IsNeutralSpecial &&
                tile.CurrentCandy.TypeIndex == targetTypeIndex)
            {
                output.Add(tile);
                blastedCoords.Add(new Vector2Int(tile.X, tile.Y));
            }
        }
    }

    private void CollectFishTargets(BackgroundTiile origin, List<BackgroundTiile> output, HashSet<Vector2Int> blastedCoords)
    {
        blastedCoords.Add(new Vector2Int(origin.X, origin.Y));
        Vector3 originWorld = origin.transform.position;

        // 1. Ưu tiên tìm các vật cản đang còn trên bảng
        List<Vector2Int> obstaclePositions = new List<Vector2Int>();
        for (int x = 0; x < board.Width; x++)
        {
            for (int y = 0; y < board.Height; y++)
            {
                if (board.GetObstacle(x, y) != null)
                {
                    obstaclePositions.Add(new Vector2Int(x, y));
                }
            }
        }

        if (obstaclePositions.Count > 0)
        {
            Vector2Int chosenObs = obstaclePositions[Random.Range(0, obstaclePositions.Count)];
            blastedCoords.Add(chosenObs);
            Match3VFXManager.Instance?.PlaySugarFishProjectile(originWorld, board.GetCellPosition(chosenObs.x, chosenObs.y), board.CellSize);
        }

        // 2. Đồng thời chọn ngẫu nhiên tối đa 2 viên kẹo khác trên bàn cờ để phá hủy
        if (board.PlayableTiles.Count > 0)
        {
            int picks = Mathf.Min(2, board.PlayableTiles.Count);
            for (int i = 0; i < picks; i++)
            {
                BackgroundTiile randomTile = board.PlayableTiles[Random.Range(0, board.PlayableTiles.Count)];
                if (randomTile != null && randomTile != origin)
                {
                    output.Add(randomTile);
                    blastedCoords.Add(new Vector2Int(randomTile.X, randomTile.Y));
                    Match3VFXManager.Instance?.PlaySugarFishProjectile(originWorld, randomTile.transform.position, board.CellSize);
                }
            }
        }
    }

    private int GetMostFrequentColorOnBoard()
    {
        Dictionary<int, int> counts = new Dictionary<int, int>();
        int bestType = 0;
        int bestCount = -1;

        for (int i = 0; i < board.PlayableTiles.Count; i++)
        {
            Candy c = board.PlayableTiles[i].CurrentCandy;
            if (c == null || c.IsNeutralSpecial || c.TypeIndex < 0)
            {
                continue;
            }

            counts.TryGetValue(c.TypeIndex, out int cur);
            cur++;
            counts[c.TypeIndex] = cur;

            if (cur > bestCount)
            {
                bestCount = cur;
                bestType = c.TypeIndex;
            }
        }

        return bestType;
    }
}