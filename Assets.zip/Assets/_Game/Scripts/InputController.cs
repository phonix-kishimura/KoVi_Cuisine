using System;
using UnityEngine;

/// <summary>
/// Quản lý thao tác Chạm (Tap) và Vuốt (Swipe) của người chơi.
/// Đã khắc phục điểm yếu cảm giác vuốt bị trễ: Ngay khi ngón tay/chuột kéo vượt qua
/// ngưỡng swipeThresholdPixels, sự kiện đổi kẹo sẽ kích hoạt NGAY LẬP TỨC mà không cần chờ nhả tay.
/// Đồng thời hiển thị hiệu ứng phóng nhẹ khi người chơi chọn ô bằng thao tác Tap.
/// </summary>
public class InputController
{
    private readonly Board board;
    private readonly float swipeThresholdPixels;
    private readonly Action<BackgroundTiile, BackgroundTiile> onSwapRequested;
    private readonly Action onUserActivity;

    private BackgroundTiile selectedCell;
    private BackgroundTiile pointerStartCell;
    private Vector2 pointerStartPosition;
    private bool pointerPressed;
    private bool swipeTriggeredDuringDrag;

    public InputController(
        Board board,
        float swipeThresholdPixels,
        Action<BackgroundTiile, BackgroundTiile> onSwapRequested,
        Action onUserActivity)
    {
        this.board = board;
        this.swipeThresholdPixels = Mathf.Max(5f, swipeThresholdPixels);
        this.onSwapRequested = onSwapRequested;
        this.onUserActivity = onUserActivity;
    }

    public void ProcessInput()
    {
        // 1. Khi bắt đầu chạm/nhấn chuột
        if (TryReadPointerDown(out Vector2 downPos))
        {
            onUserActivity?.Invoke();
            pointerPressed = true;
            swipeTriggeredDuringDrag = false;
            pointerStartPosition = downPos;
            pointerStartCell = GetCellAtScreenPosition(downPos);
            return;
        }

        // 2. Khi đang giữ và kéo (Xử lý vuốt tức thì - Immediate Swipe)
        if (pointerPressed && !swipeTriggeredDuringDrag && TryReadPointerHeld(out Vector2 currentPos))
        {
            if (pointerStartCell != null)
            {
                Vector2 dragDelta = currentPos - pointerStartPosition;
                if (dragDelta.sqrMagnitude >= swipeThresholdPixels * swipeThresholdPixels)
                {
                    swipeTriggeredDuringDrag = true;
                    onUserActivity?.Invoke();
                    ClearSelectedCell();

                    BackgroundTiile targetCell = GetSwipeTarget(pointerStartCell, dragDelta);
                    if (targetCell != null)
                    {
                        onSwapRequested?.Invoke(pointerStartCell, targetCell);
                    }
                }
            }
        }

        // 3. Khi nhả tay/chuột (Xử lý Tap từng ô nếu chưa vuốt)
        if (pointerPressed && TryReadPointerUp(out _))
        {
            pointerPressed = false;
            if (!swipeTriggeredDuringDrag)
            {
                HandleTap(pointerStartCell);
            }
            pointerStartCell = null;
        }
    }

    public void ResetState()
    {
        pointerPressed = false;
        swipeTriggeredDuringDrag = false;
        pointerStartCell = null;
        ClearSelectedCell();
    }

    private void HandleTap(BackgroundTiile tappedCell)
    {
        if (tappedCell == null || tappedCell.CurrentCandy == null)
        {
            ClearSelectedCell();
            return;
        }

        if (selectedCell == null)
        {
            SelectCell(tappedCell);
            return;
        }

        if (selectedCell == tappedCell)
        {
            ClearSelectedCell();
            return;
        }

        if (AreAdjacent(selectedCell, tappedCell))
        {
            BackgroundTiile first = selectedCell;
            ClearSelectedCell();
            onSwapRequested?.Invoke(first, tappedCell);
        }
        else
        {
            SelectCell(tappedCell);
        }
    }

    private void SelectCell(BackgroundTiile cell)
    {
        ClearSelectedCell();
        selectedCell = cell;
        if (selectedCell != null && selectedCell.CurrentCandy != null)
        {
            selectedCell.CurrentCandy.SetSelectedVisual(true);
        }
    }

    private void ClearSelectedCell()
    {
        if (selectedCell != null && selectedCell.CurrentCandy != null)
        {
            selectedCell.CurrentCandy.SetSelectedVisual(false);
        }
        selectedCell = null;
    }

    private bool AreAdjacent(BackgroundTiile a, BackgroundTiile b)
    {
        if (a == null || b == null) return false;
        return Mathf.Abs(a.X - b.X) + Mathf.Abs(a.Y - b.Y) == 1;
    }

    private BackgroundTiile GetSwipeTarget(BackgroundTiile startCell, Vector2 dragDelta)
    {
        int targetX = startCell.X;
        int targetY = startCell.Y;

        if (Mathf.Abs(dragDelta.x) > Mathf.Abs(dragDelta.y))
        {
            targetX += dragDelta.x > 0f ? 1 : -1;
        }
        else
        {
            targetY += dragDelta.y > 0f ? 1 : -1;
        }

        return board.GetTile(targetX, targetY);
    }

    private BackgroundTiile GetCellAtScreenPosition(Vector2 screenPosition)
    {
        Camera mainCamera = Camera.main;
        if (mainCamera == null) return null;

        Vector3 screenPoint = new Vector3(
            screenPosition.x,
            screenPosition.y,
            Mathf.Abs(mainCamera.transform.position.z));
        Vector2 worldPoint = mainCamera.ScreenToWorldPoint(screenPoint);

        Collider2D[] hits = Physics2D.OverlapPointAll(worldPoint);
        for (int i = 0; i < hits.Length; i++)
        {
            Candy candy = hits[i].GetComponent<Candy>();
            if (candy == null) candy = hits[i].GetComponentInParent<Candy>();
            if (candy != null && candy.Cell != null)
            {
                return candy.Cell;
            }
        }

        return null;
    }

    private bool TryReadPointerDown(out Vector2 screenPosition)
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButtonDown(0))
        {
            screenPosition = Input.mousePosition;
            return true;
        }
#endif
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began)
            {
                screenPosition = touch.position;
                return true;
            }
        }
        screenPosition = Vector2.zero;
        return false;
    }

    private bool TryReadPointerHeld(out Vector2 screenPosition)
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButton(0))
        {
            screenPosition = Input.mousePosition;
            return true;
        }
#endif
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Stationary)
            {
                screenPosition = touch.position;
                return true;
            }
        }
        screenPosition = Vector2.zero;
        return false;
    }

    private bool TryReadPointerUp(out Vector2 screenPosition)
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButtonUp(0))
        {
            screenPosition = Input.mousePosition;
            return true;
        }
#endif
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
            {
                screenPosition = touch.position;
                return true;
            }
        }
        screenPosition = Vector2.zero;
        return false;
    }
}
