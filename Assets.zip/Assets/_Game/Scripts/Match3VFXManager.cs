﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Quản lý toàn bộ hiệu ứng thị giác (Visual Effects) của kẹo bằng Code thuần:
/// 1. Kẹo thường khi Match: Phình ra và nổ "Pop" như bong bóng kèm các hạt nước/kẹo văng tung tóe.
/// 2. Kẹo Sọc Ngang (StripedHorizontal): Phóng tia Laser năng lượng quét ngang toàn bộ hàng.
/// 3. Kẹo Sọc Dọc (StripedVertical): Phóng tia Laser năng lượng quét dọc toàn bộ cột.
/// 4. Kẹo Gói (Wrapped): Vụ nổ sóng xung kích (Shockwave) bung rộng vùng 3x3 (hoặc 5x5) + rung nhẹ bàn cờ.
/// 5. Bom Màu (ColorBomb): Phóng các tia sét cầu vồng nối từ tâm Bom Màu tới mọi viên kẹo bị hủy.
/// 6. Kẹo Cá (SugarFish): Phóng bóng cá phát sáng bơi vòng cung tới thẳng ô mục tiêu/vật cản.
/// </summary>
public class Match3VFXManager : MonoBehaviour
{
    public static Match3VFXManager Instance { get; private set; }

    /// <summary>
    /// Cờ tạm ngắt hiệu ứng nổ khi bàn cờ đang khởi tạo ban đầu hoặc đang xáo trộn (Shuffle).
    /// </summary>
    public bool SuppressVFX { get; set; }

    // Bộ nhớ đệm các Sprite hiệu ứng tự sinh bằng thuật toán
    private Sprite ringSprite;
    private Sprite softCircleSprite;
    private Sprite beamSprite;
    private Sprite diamondSprite;

    // Bảng màu tươi sáng dùng cho hiệu ứng nổ bong bóng theo mã màu kẹo
    private readonly Color[] paletteColors =
    {
        new Color(1.00f, 0.32f, 0.42f), // Đỏ hồng
        new Color(0.25f, 0.78f, 1.00f), // Xanh dương
        new Color(1.00f, 0.82f, 0.20f), // Vàng
        new Color(0.35f, 0.92f, 0.48f), // Xanh lá
        new Color(0.75f, 0.42f, 1.00f), // Tím
        new Color(1.00f, 0.55f, 0.22f)  // Cam
    };

    public static Match3VFXManager EnsureInstance()
    {
        if (Instance == null)
        {
            Instance = FindAnyObjectByType<Match3VFXManager>();
            if (Instance == null)
            {
                GameObject obj = new GameObject("Match3_VFXManager");
                Instance = obj.AddComponent<Match3VFXManager>();
            }
        }
        return Instance;
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        GenerateProceduralVFXSprites();
    }

    // =========================================================================================
    // 1. HIỆU ỨNG POP BONG BÓNG KHI KẸO ĐƯỢC MATCH
    // =========================================================================================

    /// <summary>
    /// Tạo hiệu ứng viên kẹo phình căng như bong bóng rồi vỡ tung thành vòng sóng + các giọt hạt bay ra.
    /// </summary>
    public void PlayBubblePop(Vector3 worldPos, int colorIndex, float cellSize = 1f)
    {
        if (SuppressVFX || Time.timeSinceLevelLoad < 0.35f) return;

        Color popColor = GetColorForType(colorIndex);
        StartCoroutine(BubblePopRoutine(worldPos, popColor, cellSize));
    }

    private IEnumerator BubblePopRoutine(Vector3 pos, Color color, float cellSize)
    {
        GameObject root = new GameObject("VFX_BubblePop");
        root.transform.position = pos;

        // 1. Thân bong bóng phình to nhanh trước khi vỡ (0.07 giây)
        SpriteRenderer bubbleBody = CreateVFXRenderer("BubbleCore", root.transform, softCircleSprite, color, 25);
        float swellTime = 0.075f;
        float elapsed = 0f;
        while (elapsed < swellTime)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / swellTime;
            float scale = Mathf.Lerp(0.75f, 1.35f, t) * cellSize;
            bubbleBody.transform.localScale = new Vector3(scale, scale, 1f);
            bubbleBody.color = Color.Lerp(color, Color.white, t * 0.6f);
            yield return null;
        }
        Destroy(bubbleBody.gameObject);

        // 2. Vòng màng bong bóng (Bubble Ring) bung rộng và7 giọt bong bóng nhỏ văng ra xung quanh
        SpriteRenderer ring = CreateVFXRenderer("BubbleRing", root.transform, ringSprite, new Color(color.r, color.g, color.b, 0.95f), 26);

        const int dropletCount = 7;
        Transform[] droplets = new Transform[dropletCount];
        SpriteRenderer[] dropletRenderers = new SpriteRenderer[dropletCount];
        Vector2[] velocities = new Vector2[dropletCount];

        for (int i = 0; i < dropletCount; i++)
        {
            float angle = (i * Mathf.PI * 2f / dropletCount) + Random.Range(-0.25f, 0.25f);
            float speed = Random.Range(2.2f, 3.8f) * cellSize;
            velocities[i] = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * speed;

            SpriteRenderer drop = CreateVFXRenderer($"Drop_{i}", root.transform, softCircleSprite, Color.Lerp(color, Color.white, 0.25f), 27);
            drop.transform.localScale = Vector3.one * (0.28f * cellSize);
            droplets[i] = drop.transform;
            dropletRenderers[i] = drop;
        }

        float burstDuration = 0.24f;
        elapsed = 0f;
        while (elapsed < burstDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / burstDuration);
            float easeOut = 1f - Mathf.Pow(1f - t, 3f);

            // Vòng sóng bung ra và mờ dần
            float ringScale = Mathf.Lerp(0.4f, 1.45f, easeOut) * cellSize;
            ring.transform.localScale = new Vector3(ringScale, ringScale, 1f);
            ring.color = new Color(1f, 1f, 1f, 1f - t);

            // Các giọt bong bóng bay ra và thu nhỏ
            for (int i = 0; i < dropletCount; i++)
            {
                droplets[i].localPosition += (Vector3)(velocities[i] * Time.deltaTime);
                velocities[i] *= 0.92f; // Lực cản không khí
                float dropScale = Mathf.Lerp(0.28f, 0.02f, t) * cellSize;
                droplets[i].localScale = new Vector3(dropScale, dropScale, 1f);

                Color c = dropletRenderers[i].color;
                c.a = 1f - t;
                dropletRenderers[i].color = c;
            }

            yield return null;
        }

        Destroy(root);
    }

    // =========================================================================================
    // 2. HIỆU ỨNG ĐẶC THÙ CHO TỪNG LOẠI KẸO ĐẶC BIỆT
    // =========================================================================================

    /// <summary>
    /// Hiệu ứng KẸO SỌC (StripedHorizontal / StripedVertical):
    /// Phóng một đường tia Laser sáng rực quét dọc hoặc ngang toàn bộ bàn cờ.
    /// </summary>
    public void PlayStripedBeam(Vector3 originPos, bool isHorizontal, Board board)
    {
        if (SuppressVFX) return;

        float cellSize = board != null ? board.CellSize : 1f;
        float length = isHorizontal
            ? (board != null ? board.Width * cellSize * 1.15f : 9f)
            : (board != null ? board.Height * cellSize * 1.15f : 9f);

        Vector3 beamCenter = originPos;
        if (board != null)
        {
            Vector2 boardCenter = board.BoardWorldCenter;
            beamCenter = isHorizontal
                ? new Vector3(boardCenter.x, originPos.y, 0f)
                : new Vector3(originPos.x, boardCenter.y, 0f);
        }

        StartCoroutine(StripedBeamRoutine(beamCenter, originPos, isHorizontal, length, cellSize));
    }

    private IEnumerator StripedBeamRoutine(Vector3 beamCenter, Vector3 originPos, bool isHorizontal, float maxLength, float cellSize)
    {
        GameObject root = new GameObject(isHorizontal ? "VFX_StripedHorizontalBeam" : "VFX_StripedVerticalBeam");

        // Tia ngoài (Outer Glow màu xanh cyan) và lõi tia (Core màu trắng sáng)
        SpriteRenderer outerBeam = CreateVFXRenderer("OuterBeam", root.transform, beamSprite, new Color(0.2f, 0.88f, 1f, 0.9f), 30);
        SpriteRenderer innerCore = CreateVFXRenderer("InnerCore", root.transform, beamSprite, Color.white, 31);
        outerBeam.transform.position = beamCenter;
        innerCore.transform.position = beamCenter;

        // 2 đầu sóng xung kích chạy dọc theo tia nổ ra 2 phía
        SpriteRenderer waveHeadA = CreateVFXRenderer("WaveHeadA", root.transform, diamondSprite, Color.white, 32);
        SpriteRenderer waveHeadB = CreateVFXRenderer("WaveHeadB", root.transform, diamondSprite, Color.white, 32);

        float duration = 0.32f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);

            // Tia kéo dài cực nhanh trong 30% thời gian đầu, sau đó thu hẹp bề ngang và mờ dần
            float expandT = Mathf.Clamp01(t / 0.28f);
            float fadeT = t > 0.28f ? (t - 0.28f) / 0.72f : 0f;

            float currentLen = Mathf.Lerp(cellSize, maxLength, expandT);
            float outerThickness = Mathf.Lerp(0.85f * cellSize, 0.05f * cellSize, fadeT);
            float innerThickness = outerThickness * 0.45f;

            if (isHorizontal)
            {
                outerBeam.transform.localScale = new Vector3(currentLen, outerThickness, 1f);
                innerCore.transform.localScale = new Vector3(currentLen, innerThickness, 1f);

                float headOffset = (currentLen * 0.5f) * expandT;
                waveHeadA.transform.position = originPos + new Vector3(headOffset, 0f, 0f);
                waveHeadB.transform.position = originPos - new Vector3(headOffset, 0f, 0f);
            }
            else
            {
                outerBeam.transform.localScale = new Vector3(outerThickness, currentLen, 1f);
                innerCore.transform.localScale = new Vector3(innerThickness, currentLen, 1f);

                float headOffset = (currentLen * 0.5f) * expandT;
                waveHeadA.transform.position = originPos + new Vector3(0f, headOffset, 0f);
                waveHeadB.transform.position = originPos - new Vector3(0f, headOffset, 0f);
            }

            float headScale = Mathf.Lerp(0.75f, 0.1f, fadeT) * cellSize;
            waveHeadA.transform.localScale = new Vector3(headScale, headScale, 1f);
            waveHeadB.transform.localScale = new Vector3(headScale, headScale, 1f);

            float alpha = 1f - fadeT;
            outerBeam.color = new Color(0.2f, 0.88f, 1f, alpha * 0.9f);
            innerCore.color = new Color(1f, 1f, 1f, alpha);
            waveHeadA.color = new Color(1f, 0.95f, 0.6f, alpha);
            waveHeadB.color = new Color(1f, 0.95f, 0.6f, alpha);

            yield return null;
        }

        Destroy(root);
    }

    /// <summary>
    /// Hiệu ứng KẸO GÓI (Wrapped Candy):
    /// Nổ vùng sóng xung kích 3x3 (radius = 1) hoặc 5x5 (radius = 2) kèm rung nhẹ bàn cờ.
    /// </summary>
    public void PlayWrappedBlast(Vector3 centerPos, int radius, Board board)
    {
        if (SuppressVFX) return;

        float cellSize = board != null ? board.CellSize : 1f;
        float targetDiameter = ((radius * 2) + 1.2f) * cellSize;

        if (board != null)
        {
            StartCoroutine(ShakeTransformRoutine(board.transform, 0.18f, 0.12f * cellSize));
        }

        StartCoroutine(WrappedBlastRoutine(centerPos, targetDiameter, cellSize));
    }

    private IEnumerator WrappedBlastRoutine(Vector3 centerPos, float maxDiameter, float cellSize)
    {
        GameObject root = new GameObject("VFX_WrappedBlast");
        root.transform.position = centerPos;

        // Vùng sáng cam vàng 3x3/5x5 + Vòng sóng chấn động
        SpriteRenderer areaFlash = CreateVFXRenderer("AreaFlash", root.transform, beamSprite, new Color(1f, 0.65f, 0.15f, 0.75f), 29);
        SpriteRenderer shockRing = CreateVFXRenderer("ShockwaveRing", root.transform, ringSprite, new Color(1f, 0.9f, 0.35f, 1f), 31);

        float duration = 0.34f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            float easeOut = 1f - Mathf.Pow(1f - t, 3f);

            float size = Mathf.Lerp(0.5f * cellSize, maxDiameter, easeOut);
            areaFlash.transform.localScale = new Vector3(size, size, 1f);
            shockRing.transform.localScale = new Vector3(size * 1.12f, size * 1.12f, 1f);
            shockRing.transform.localRotation = Quaternion.Euler(0f, 0f, elapsed * 180f);

            areaFlash.color = new Color(1f, 0.55f, 0.15f, (1f - t) * 0.65f);
            shockRing.color = new Color(1f, 0.92f, 0.4f, 1f - t);

            yield return null;
        }

        Destroy(root);
    }

    /// <summary>
    /// Hiệu ứng BOM MÀU (ColorBomb):
    /// Phóng các tia năng lượng cầu vồng từ tâm Bom Màu tới từng viên kẹo mục tiêu trên bàn cờ.
    /// </summary>
    public void PlayColorBombLightning(Vector3 originPos, List<BackgroundTiile> targets, float cellSize = 1f)
    {
        if (SuppressVFX || targets == null || targets.Count == 0) return;

        List<Vector3> targetPositions = new List<Vector3>(targets.Count);
        for (int i = 0; i < targets.Count; i++)
        {
            if (targets[i] != null)
            {
                targetPositions.Add(targets[i].transform.position);
            }
        }

        StartCoroutine(ColorBombLightningRoutine(originPos, targetPositions, cellSize));
    }

    private IEnumerator ColorBombLightningRoutine(Vector3 originPos, List<Vector3> targetPositions, float cellSize)
    {
        GameObject root = new GameObject("VFX_ColorBombRays");

        // Quả cầu năng lượng ở tâm Bom Màu
        SpriteRenderer coreOrb = CreateVFXRenderer("CoreOrb", root.transform, softCircleSprite, Color.white, 33);
        coreOrb.transform.position = originPos;

        List<SpriteRenderer> rays = new List<SpriteRenderer>(targetPositions.Count);
        List<SpriteRenderer> targetSparks = new List<SpriteRenderer>(targetPositions.Count);

        for (int i = 0; i < targetPositions.Count; i++)
        {
            Color rayColor = Color.HSVToRGB((i * 0.17f) % 1f, 0.8f, 1f);
            Vector3 targetPos = targetPositions[i];
            Vector3 diff = targetPos - originPos;
            float dist = diff.magnitude;

            SpriteRenderer ray = CreateVFXRenderer($"Ray_{i}", root.transform, beamSprite, rayColor, 32);
            ray.transform.position = originPos + diff * 0.5f;
            float angle = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
            ray.transform.rotation = Quaternion.Euler(0f, 0f, angle);
            ray.transform.localScale = new Vector3(dist, 0.18f * cellSize, 1f);
            rays.Add(ray);

            SpriteRenderer spark = CreateVFXRenderer($"Spark_{i}", root.transform, diamondSprite, Color.white, 34);
            spark.transform.position = targetPos;
            spark.transform.localScale = Vector3.one * (0.65f * cellSize);
            targetSparks.Add(spark);
        }

        float duration = 0.35f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);

            float orbScale = Mathf.Lerp(1.3f, 0.1f, t) * cellSize;
            coreOrb.transform.localScale = new Vector3(orbScale, orbScale, 1f);
            coreOrb.color = Color.HSVToRGB(Mathf.Repeat(Time.time * 4f, 1f), 0.7f, 1f);

            for (int i = 0; i < rays.Count; i++)
            {
                float thickness = (0.18f + Mathf.Sin(elapsed * 45f + i) * 0.06f) * (1f - t) * cellSize;
                Vector3 curScale = rays[i].transform.localScale;
                rays[i].transform.localScale = new Vector3(curScale.x, Mathf.Max(0.01f, thickness), 1f);

                Color c = rays[i].color;
                c.a = 1f - t;
                rays[i].color = c;

                targetSparks[i].transform.localRotation = Quaternion.Euler(0f, 0f, elapsed * 360f);
                targetSparks[i].transform.localScale = Vector3.one * (Mathf.Lerp(0.75f, 0.1f, t) * cellSize);
            }

            yield return null;
        }

        Destroy(root);
    }

    /// <summary>
    /// Hiệu ứng KẸO CÁ (SugarFish):
    /// Phóng bóng cá ngọc lam lượn theo đường cong tới mục tiêu và nổ tung thành vòng sóng nước.
    /// </summary>
    public void PlaySugarFishProjectile(Vector3 startPos, Vector3 targetPos, float cellSize = 1f)
    {
        if (SuppressVFX) return;
        StartCoroutine(SugarFishSwimRoutine(startPos, targetPos, cellSize));
    }

    private IEnumerator SugarFishSwimRoutine(Vector3 startPos, Vector3 targetPos, float cellSize)
    {
        GameObject fishObj = new GameObject("VFX_SugarFish");
        SpriteRenderer fishRenderer = CreateVFXRenderer("FishBody", fishObj.transform, diamondSprite, new Color(0.2f, 0.95f, 0.9f, 1f), 35);
        fishRenderer.transform.localScale = new Vector3(0.75f * cellSize, 0.45f * cellSize, 1f);

        Vector3 midPoint = (startPos + targetPos) * 0.5f + new Vector3(Random.Range(-1.5f, 1.5f), 1.8f, 0f) * cellSize;
        float swimDuration = 0.32f;
        float elapsed = 0f;

        Vector3 prevPos = startPos;
        while (elapsed < swimDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / swimDuration);
            float oneMinusT = 1f - t;

            Vector3 currentPos = (oneMinusT * oneMinusT * startPos)
                               + (2f * oneMinusT * t * midPoint)
                               + (t * t * targetPos);

            Vector3 dir = currentPos - prevPos;
            if (dir.sqrMagnitude > 0.0001f)
            {
                float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
                fishObj.transform.rotation = Quaternion.Euler(0f, 0f, angle);
            }

            fishObj.transform.position = currentPos;
            prevPos = currentPos;
            yield return null;
        }

        Destroy(fishObj);
        // Nổ sóng nước tại ô đích
        PlayBubblePop(targetPos, 1, cellSize * 1.25f);
    }

    /// <summary>
    /// Hiệu ứng khi người chơi dùng BÚA PHÁ (Hammer Booster) đập vào 1 ô trên bàn cờ.
    /// </summary>
    public void PlayHammerSmash(Vector3 targetPos, Board board)
    {
        float cellSize = board != null ? board.CellSize : 1f;
        if (board != null)
        {
            StartCoroutine(ShakeTransformRoutine(board.transform, 0.16f, 0.1f * cellSize));
        }
        StartCoroutine(HammerSmashRoutine(targetPos, cellSize));
    }

    private IEnumerator HammerSmashRoutine(Vector3 targetPos, float cellSize)
    {
        GameObject root = new GameObject("VFX_HammerSmash");
        root.transform.position = targetPos;

        // Đầu búa giáng xuống từ góc trên phải
        SpriteRenderer hammer = CreateVFXRenderer("HammerHead", root.transform, beamSprite, new Color(1f, 0.35f, 0.55f, 1f), 40);
        hammer.transform.localPosition = new Vector3(0.6f * cellSize, 0.8f * cellSize, 0f);
        hammer.transform.localScale = new Vector3(0.9f * cellSize, 0.5f * cellSize, 1f);

        float strikeTime = 0.12f;
        float elapsed = 0f;
        while (elapsed < strikeTime)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / strikeTime;
            hammer.transform.localPosition = Vector3.Lerp(new Vector3(0.6f * cellSize, 0.8f * cellSize, 0f), Vector3.zero, t * t);
            hammer.transform.localRotation = Quaternion.Euler(0f, 0f, Mathf.Lerp(-45f, 20f, t));
            yield return null;
        }

        Destroy(hammer.gameObject);
        PlayWrappedBlast(targetPos, 0, null);
        Destroy(root, 0.35f);
    }

    private IEnumerator ShakeTransformRoutine(Transform target, float duration, float magnitude)
    {
        if (target == null) yield break;
        Vector3 origin = target.position;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            if (target == null) yield break;
            float damper = 1f - (elapsed / duration);
            Vector2 offset = Random.insideUnitCircle * (magnitude * damper);
            target.position = origin + new Vector3(offset.x, offset.y, 0f);
            yield return null;
        }

        if (target != null)
        {
            target.position = origin;
        }
    }

    // =========================================================================================
    // 3. TẠO SPRITE HIỆU ỨNG TRONG BỘ NHỚ
    // =========================================================================================

    private SpriteRenderer CreateVFXRenderer(string name, Transform parent, Sprite sprite, Color color, int sortingOrder)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent, false);
        SpriteRenderer sr = obj.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = sortingOrder;
        return sr;
    }

    private Color GetColorForType(int typeIndex)
    {
        if (typeIndex < 0) return new Color(0.85f, 0.95f, 1f);
        return paletteColors[typeIndex % paletteColors.Length];
    }

    private void GenerateProceduralVFXSprites()
    {
        const int size = 64;
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float maxR = size * 0.46f;

        // 1. Vòng tròn rỗng (Bubble Ring / Shockwave Ring)
        Texture2D ringTex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        // 2. Hình tròn mềm (Bubble Body / Droplet)
        Texture2D circleTex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        // 3. Tia sáng (Laser Beam)
        Texture2D beamTex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        // 4. Hình thoi sắc nét (Spark / Fish)
        Texture2D diamondTex = new Texture2D(size, size, TextureFormat.RGBA32, false);

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dist = Vector2.Distance(new Vector2(x, y), center);

                // Ring
                float ringDist = Mathf.Abs(dist - (maxR * 0.78f));
                float ringAlpha = Mathf.Clamp01(1f - (ringDist / (size * 0.08f)));
                ringTex.SetPixel(x, y, new Color(1f, 1f, 1f, ringAlpha));

                // Soft Circle (Bóng sáng ở viền như bong bóng xà phòng)
                float circleAlpha = Mathf.Clamp01((maxR - dist) * 0.35f);
                float rim = Mathf.Clamp01(dist / maxR);
                float brightness = Mathf.Lerp(0.85f, 1f, rim);
                circleTex.SetPixel(x, y, new Color(brightness, brightness, brightness, circleAlpha));

                // Beam
                float normY = Mathf.Abs(y - center.y) / (size * 0.5f);
                float beamAlpha = Mathf.Clamp01(1f - normY);
                beamTex.SetPixel(x, y, new Color(1f, 1f, 1f, beamAlpha * beamAlpha));

                // Diamond
                float manhattan = (Mathf.Abs(x - center.x) + Mathf.Abs(y - center.y)) / maxR;
                float diaAlpha = Mathf.Clamp01((1f - manhattan) * 3f);
                diamondTex.SetPixel(x, y, new Color(1f, 1f, 1f, diaAlpha));
            }
        }

        ringTex.Apply();
        circleTex.Apply();
        beamTex.Apply();
        diamondTex.Apply();

        ringSprite = Sprite.Create(ringTex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 64f);
        softCircleSprite = Sprite.Create(circleTex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 64f);
        beamSprite = Sprite.Create(beamTex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 64f);
        diamondSprite = Sprite.Create(diamondTex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 64f);
    }
}