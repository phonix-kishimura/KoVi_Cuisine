using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Quản lý điểm số, số lượt đi còn lại, tiến độ hoàn thành mục tiêu từ LevelData
/// và kiểm tra điều kiện Thắng / Thua.
/// Hỗ trợ các sự kiện (Events) để kết nối với Canvas UI sau này.
/// </summary>
public class LevelGoalTracker
{
    public class RuntimeGoal
    {
        public LevelGoalType GoalType;
        public int TargetAmount;
        public int CurrentAmount;
        public int CandyTypeIndex;
        public bool IsCompleted => CurrentAmount >= TargetAmount;
    }

    public int CurrentScore { get; private set; }
    public int MovesRemaining { get; private set; }
    public bool IsGameOver { get; private set; }
    public bool IsLevelWon { get; private set; }
    public List<RuntimeGoal> Goals { get; } = new List<RuntimeGoal>();

    public event Action<int> OnScoreChanged;
    public event Action<int> OnMovesChanged;
    public event Action OnGoalsUpdated;
    public event Action OnLevelWin;
    public event Action OnLevelLose;

    public void Initialize(LevelData levelData, int initialBoardObstacles)
    {
        CurrentScore = 0;
        IsGameOver = false;
        IsLevelWon = false;
        Goals.Clear();

        if (levelData == null)
        {
            MovesRemaining = 30;
            Goals.Add(new RuntimeGoal
            {
                GoalType = LevelGoalType.ReachScore,
                TargetAmount = 1500,
                CurrentAmount = 0
            });
            return;
        }

        MovesRemaining = Mathf.Max(1, levelData.MoveLimit);

        // Thêm mục tiêu chính từ LevelData
        Goals.Add(CreateRuntimeGoal(
            levelData.GoalType,
            levelData.TargetScore,
            levelData.TargetCandyCount,
            levelData.TargetObstacleCount,
            levelData.TargetCandyTypeIndex,
            initialBoardObstacles));

        // Thêm các mục tiêu phụ (nếu có cấu hình Multi-Goal)
        if (levelData.AdditionalGoals != null)
        {
            for (int i = 0; i < levelData.AdditionalGoals.Length; i++)
            {
                LevelGoalEntry entry = levelData.AdditionalGoals[i];
                Goals.Add(new RuntimeGoal
                {
                    GoalType = entry.goalType,
                    TargetAmount = Mathf.Max(1, entry.targetAmount),
                    CandyTypeIndex = entry.candyTypeIndex,
                    CurrentAmount = 0
                });
            }
        }
    }

    private RuntimeGoal CreateRuntimeGoal(
        LevelGoalType type,
        int targetScore,
        int targetCandy,
        int targetObstacle,
        int candyTypeIndex,
        int initialBoardObstacles)
    {
        int amount = 1000;
        switch (type)
        {
            case LevelGoalType.ReachScore:
                amount = Mathf.Max(100, targetScore);
                break;
            case LevelGoalType.CollectCandy:
                amount = Mathf.Max(1, targetCandy);
                break;
            case LevelGoalType.ClearObstacles:
                amount = targetObstacle > 0 ? targetObstacle : Mathf.Max(1, initialBoardObstacles);
                break;
        }

        return new RuntimeGoal
        {
            GoalType = type,
            TargetAmount = amount,
            CandyTypeIndex = candyTypeIndex,
            CurrentAmount = 0
        };
    }

    public void ConsumeMove()
    {
        if (IsGameOver) return;
        MovesRemaining = Mathf.Max(0, MovesRemaining - 1);
        OnMovesChanged?.Invoke(MovesRemaining);
    }

    public void AddScore(int points)
    {
        if (points <= 0) return;
        CurrentScore += points;

        for (int i = 0; i < Goals.Count; i++)
        {
            if (Goals[i].GoalType == LevelGoalType.ReachScore)
            {
                Goals[i].CurrentAmount = CurrentScore;
            }
        }

        OnScoreChanged?.Invoke(CurrentScore);
        OnGoalsUpdated?.Invoke();
    }

    public void RecordCandyCollected(int candyTypeIndex, int count = 1)
    {
        for (int i = 0; i < Goals.Count; i++)
        {
            if (Goals[i].GoalType == LevelGoalType.CollectCandy && Goals[i].CandyTypeIndex == candyTypeIndex)
            {
                Goals[i].CurrentAmount += count;
            }
        }
        OnGoalsUpdated?.Invoke();
    }

    public void RecordObstacleCleared(int count = 1)
    {
        for (int i = 0; i < Goals.Count; i++)
        {
            if (Goals[i].GoalType == LevelGoalType.ClearObstacles)
            {
                Goals[i].CurrentAmount += count;
            }
        }
        OnGoalsUpdated?.Invoke();
    }

    /// <summary>
    /// Kiểm tra xem người chơi đã hoàn thành toàn bộ mục tiêu hoặc hết lượt đi hay chưa.
    /// Chỉ gọi sau khi toàn bộ chuỗi Cascade đã dừng hẳn.
    /// </summary>
    public void EvaluateEndOfTurnState()
    {
        if (IsGameOver) return;

        bool allCompleted = true;
        for (int i = 0; i < Goals.Count; i++)
        {
            if (!Goals[i].IsCompleted)
            {
                allCompleted = false;
                break;
            }
        }

        if (allCompleted)
        {
            IsGameOver = true;
            IsLevelWon = true;
            OnLevelWin?.Invoke();
            
            return;
        }

        if (MovesRemaining <= 0)
        {
            IsGameOver = true;
            IsLevelWon = false;
            OnLevelLose?.Invoke();
            
        }
    }
}
