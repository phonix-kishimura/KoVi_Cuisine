using UnityEngine;

/// <summary>
/// Đại diện cho một Vật cản (Obstacle) đặt đè lên trên BackgroundTiile.
/// - Mỗi ObstacleTile chỉ cần 1 lần va chạm duy nhất là vỡ.
/// - Khi vỡ, nếu RemainingSpawns > 0 (hoặc có NextObstacleData), Board sẽ hủy Obstacle này
///   và lập tức sinh ra một ObstacleTile mới mang Sprite bị vỡ ở bước tiếp theo.
/// </summary>
public class ObstacleTile : MonoBehaviour
{
    [Header("Dữ liệu Obstacle (Có thể gán trên Prefab hoặc truyền từ LevelData/Board)")]
    [SerializeField] private ObstacleData defaultObstacleData;

    public int X { get; private set; }
    public int Y { get; private set; }
    public Board OwnerBoard { get; private set; }

    /// <summary>
    /// Cấu hình ScriptableObject hiện tại của Obstacle này.
    /// </summary>
    public ObstacleData Data { get; private set; }

    /// <summary>
    /// Số lần còn lại sẽ đẻ ra Obstacle mới sau khi Obstacle hiện tại bị vỡ.
    /// </summary>
    public int RemainingSpawns { get; private set; }

    /// <summary>
    /// Bước vỡ hiện tại (0 = Nguyên vẹn, 1 = Lần vỡ 1, 2 = Lần vỡ 2...).
    /// </summary>
    public int CrackStep { get; private set; }

    public bool IsDestroyed { get; private set; }

    private SpriteRenderer mainRenderer;
    private Color baseColor = Color.white;

    private void Awake()
    {
        mainRenderer = GetComponent<SpriteRenderer>();
        if (mainRenderer == null)
        {
            mainRenderer = GetComponentInChildren<SpriteRenderer>();
        }

        if (mainRenderer != null)
        {
            baseColor = mainRenderer.color;
        }

        if (GetComponent<Collider2D>() == null)
        {
            gameObject.AddComponent<BoxCollider2D>();
        }
    }

    /// <summary>
    /// Khởi tạo Obstacle từ ScriptableObject (ObstacleData).
    /// </summary>
    /// <param name="board">Bàn cờ chứa Obstacle.</param>
    /// <param name="x">Tọa độ cột X.</param>
    /// <param name="y">Tọa độ hàng Y.</param>
    /// <param name="data">File cấu hình ObstacleData.</param>
    /// <param name="remainingSpawns">Số lần còn lại sẽ sinh ra Obstacle mới khi vỡ.</param>
    /// <param name="crackStep">Bước nứt/vỡ hiện tại (0 = nguyên vẹn, 1 = vỡ lần 1...).</param>
    /// <param name="sortingOrder">Thứ tự vẽ cao hơn BackgroundTiile bên dưới.</param>
    public void InitializeWithData(
        Board board,
        int x,
        int y,
        ObstacleData data,
        int remainingSpawns,
        int crackStep,
        int sortingOrder)
    {
        OwnerBoard = board;
        X = x;
        Y = y;
        Data = data != null ? data : defaultObstacleData;
        RemainingSpawns = Mathf.Max(0, remainingSpawns);
        CrackStep = Mathf.Max(0, crackStep);
        IsDestroyed = false;

        ApplyVisualState(sortingOrder);
    }

    /// <summary>
    /// Hàm khởi tạo tương thích ngược nếu gọi không truyền ObstacleData.
    /// (Nếu hitPoints = 3 -> tương đương 1 bản gốc + 2 lần đẻ Obstacle mới khi vỡ).
    /// </summary>
    public void Initialize(Board board, int x, int y, int fallbackHitPoints = 1)
    {
        ObstacleData activeData = defaultObstacleData;
        int spawns = activeData != null
            ? activeData.SpawnCount
            : Mathf.Max(0, fallbackHitPoints - 1);

        InitializeWithData(board, x, y, activeData, spawns, 0, 2);
    }

    private void ApplyVisualState(int sortingOrder)
    {
        if (mainRenderer == null) return;

        mainRenderer.sortingOrder = sortingOrder;
        mainRenderer.color = baseColor;

        if (Data != null)
        {
            Sprite targetSprite = Data.GetSpriteForCrackStep(CrackStep);
            if (targetSprite != null)
            {
                mainRenderer.sprite = targetSprite;
                return;
            }
        }

        // Dự phòng trực quan: Nếu người dùng đang test mà chưa kịp gán Sprite bị vỡ vào ObstacleData,
        // tự động làm sẫm nhẹ màu và thu nhỏ nhẹ kích thước để vẫn nhìn thấy rõ hiệu ứng vừa vỡ sang bước mới!
        if (CrackStep > 0)
        {
            float darken = Mathf.Clamp01(CrackStep * 0.18f);
            mainRenderer.color = Color.Lerp(baseColor, new Color(0.55f, 0.45f, 0.40f, 0.92f), darken);
        }
    }

    /// <summary>
    /// Kiểm tra xem khi Obstacle này vỡ (sau 1 lần va chạm), nó có đẻ ra Obstacle mới hay không.
    /// </summary>
    public bool TryGetNextSpawnInfo(
        out ObstacleData nextData,
        out int nextRemainingSpawns,
        out int nextCrackStep)
    {
        // Trường hợp 1: Đang dùng mảng crackedSprites và spawnCount trong cùng 1 file ObstacleData
        if (RemainingSpawns > 0)
        {
            nextData = Data;
            nextRemainingSpawns = RemainingSpawns - 1;
            nextCrackStep = CrackStep + 1;
            return true;
        }

        // Trường hợp 2: Người dùng nối chuỗi sang một file ObstacleData tiếp theo (nextObstacleData)
        if (Data != null && Data.NextObstacleData != null)
        {
            nextData = Data.NextObstacleData;
            nextRemainingSpawns = nextData.SpawnCount;
            nextCrackStep = 0;
            return true;
        }

        nextData = null;
        nextRemainingSpawns = 0;
        nextCrackStep = 0;
        return false;
    }

    /// <summary>
    /// Mỗi Obstacle chỉ cần 1 lần va chạm là vỡ ngay lập tức.
    /// </summary>
    public bool TakeDamage(int damage = 1)
    {
        if (IsDestroyed) return false;
        IsDestroyed = true;
        return true;
    }

    public void MarkDestroyed()
    {
        IsDestroyed = true;
    }
}