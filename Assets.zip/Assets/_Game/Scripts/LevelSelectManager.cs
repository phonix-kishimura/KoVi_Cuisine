﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

/// <summary>
/// Lớp tĩnh lưu trữ thông tin màn chơi đang được chọn giữa các Scene
/// và quản lý việc lưu/mở khóa màn chơi + số Sao vào bộ nhớ máy (PlayerPrefs).
/// </summary>
public static class LevelSession
{
    private const string PREF_UNLOCKED_INDEX = "Match3_UnlockedLevelIndex";
    private const string PREF_STAR_PREFIX = "Match3_LevelStars_";

    /// <summary>
    /// Dữ liệu màn chơi được chọn từ Scene Chọn Màn để truyền sang cho Board.cs.
    /// </summary>
    public static LevelData SelectedLevelData { get; private set; }
    public static int SelectedLevelIndex { get; private set; } = -1;
    public static LevelData[] AllLevelsList { get; private set; }

    public static string LevelSelectSceneName { get; set; } = "LevelSelectScene";
    public static string GameplaySceneName { get; set; } = "SampleScene";

    /// <summary>
    /// Chọn một màn chơi từ danh sách và lưu vào phiên hiện tại.
    /// </summary>
    public static void SelectLevel(LevelData data, int index, LevelData[] allLevels)
    {
        SelectedLevelData = data;
        SelectedLevelIndex = index;
        AllLevelsList = allLevels;
    }

    /// <summary>
    /// Kiểm tra xem còn màn chơi tiếp theo trong danh sách hay không.
    /// </summary>
    public static bool HasNextLevel()
    {
        return AllLevelsList != null &&
               SelectedLevelIndex >= 0 &&
               SelectedLevelIndex + 1 < AllLevelsList.Length &&
               AllLevelsList[SelectedLevelIndex + 1] != null;
    }

    /// <summary>
    /// Chuyển con trỏ sang màn chơi kế tiếp (dùng cho nút "Màn Tiếp Theo" khi thắng).
    /// </summary>
    public static bool AdvanceToNextLevel()
    {
        if (!HasNextLevel()) return false;
        SelectedLevelIndex++;
        SelectedLevelData = AllLevelsList[SelectedLevelIndex];
        return true;
    }

    /// <summary>
    /// Lấy chỉ số màn cao nhất đã được mở khóa (Mặc định màn đầu tiên - index 0 luôn mở).
    /// </summary>
    public static int GetHighestUnlockedIndex()
    {
        return PlayerPrefs.GetInt(PREF_UNLOCKED_INDEX, 0);
    }

    /// <summary>
    /// Lấy số sao đã đạt được (0..3) của một màn chơi.
    /// </summary>
    public static int GetStarsForLevel(int levelIndex)
    {
        return PlayerPrefs.GetInt(PREF_STAR_PREFIX + levelIndex, 0);
    }

    /// <summary>
    /// Ghi nhận chiến thắng màn chơi hiện tại, lưu số sao cao nhất và mở khóa màn kế tiếp.
    /// </summary>
    public static void RecordCurrentLevelVictory(int earnedStars)
    {
        int index = Mathf.Max(0, SelectedLevelIndex);
        int oldStars = GetStarsForLevel(index);
        if (earnedStars > oldStars)
        {
            PlayerPrefs.SetInt(PREF_STAR_PREFIX + index, Mathf.Clamp(earnedStars, 1, 3));
        }

        int currentUnlocked = GetHighestUnlockedIndex();
        if (index + 1 > currentUnlocked)
        {
            PlayerPrefs.SetInt(PREF_UNLOCKED_INDEX, index + 1);
        }

        PlayerPrefs.Save();
    }

    /// <summary>
    /// Xóa toàn bộ dữ liệu lưu để test lại từ Màn 1.
    /// </summary>
    public static void ResetAllProgress(int totalLevels = 50)
    {
        PlayerPrefs.DeleteKey(PREF_UNLOCKED_INDEX);
        for (int i = 0; i < totalLevels; i++)
        {
            PlayerPrefs.DeleteKey(PREF_STAR_PREFIX + i);
        }
        PlayerPrefs.Save();
    }
}

/// <summary>
/// Script gắn trực tiếp vào CANVAS của Scene Chọn Màn Chơi (LevelSelectScene):
/// - Tự động đọc mảng LevelData[] được kéo vào Inspector.
/// - Tự động dựng giao diện lưới các nút Màn 1, Màn 2, Màn 3... kèm hiển thị 3 Ngôi Sao,
///   số lượt đi, loại mục tiêu và trạng thái Khóa/Mở khóa.
/// </summary>
[DisallowMultipleComponent]
public class LevelSelectManager : MonoBehaviour
{
    [Header("Danh sách Màn Chơi (Kéo các file LevelData vào đây)")]
    [Tooltip("Kéo lần lượt Level_1, Level_2, Level_3... từ cửa sổ Project vào danh sách này.")]
    [SerializeField] private LevelData[] levels;

    [Header("Cấu hình Chuyển Cảnh (Scene Names)")]
    [Tooltip("Tên chính xác của Scene Chơi Game (Scene chứa Board và GameManager).")]
    [SerializeField] private string gameplaySceneName = "SampleScene";

    [Header("Khung Chứa Tùy Chọn (Để trống sẽ tự tạo trong Canvas)")]
    [SerializeField] private RectTransform customGridContainer;

    private Canvas mainCanvas;
    private RectTransform rootRect;
    private RectTransform cardsContainer;
    private Text totalStarsText;

    // Tài nguyên hình học tự sinh
    private Font defaultFont;
    private Sprite roundedSprite;
    private Sprite circleSprite;
    private Sprite starSprite;

    // Bảng màu đồng bộ với Match3UIManager
    private readonly Color colBgDark = new Color(0.09f, 0.12f, 0.22f, 1f);
    private readonly Color colHeaderBg = new Color(0.16f, 0.20f, 0.34f, 0.96f);
    private readonly Color colCardUnlocked = new Color(0.18f, 0.25f, 0.44f, 1f);
    private readonly Color colCardLocked = new Color(0.12f, 0.14f, 0.22f, 0.85f);
    private readonly Color colAccentGold = new Color(1.00f, 0.78f, 0.18f, 1f);
    private readonly Color colAccentPink = new Color(0.96f, 0.30f, 0.52f, 1f);
    private readonly Color colAccentCyan = new Color(0.20f, 0.82f, 0.92f, 1f);
    private readonly Color colAccentGreen = new Color(0.30f, 0.85f, 0.45f, 1f);

    private void Start()
    {
        // Lưu lại tên Scene Chọn Màn hiện tại và Scene Gameplay vào LevelSession
        LevelSession.LevelSelectSceneName = SceneManager.GetActiveScene().name;
        if (!string.IsNullOrEmpty(gameplaySceneName))
        {
            LevelSession.GameplaySceneName = gameplaySceneName;
        }

        PrepareProceduralAssets();
        BindCanvasAndEventSystem();
        BuildLevelSelectUI();
        PopulateLevelCards();
    }

    private void BindCanvasAndEventSystem()
    {
        if (FindFirstObjectByType<EventSystem>() == null)
        {
            GameObject esObj = new GameObject("EventSystem");
            esObj.AddComponent<EventSystem>();
            esObj.AddComponent<StandaloneInputModule>();
        }

        mainCanvas = GetComponent<Canvas>();
        if (mainCanvas == null) mainCanvas = GetComponentInParent<Canvas>();
        if (mainCanvas == null) mainCanvas = FindFirstObjectByType<Canvas>();

        if (mainCanvas == null)
        {
            mainCanvas = gameObject.AddComponent<Canvas>();
            mainCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080f, 1920f);
            scaler.matchWidthOrHeight = 0.5f;
        }

        if (mainCanvas.rootCanvas != null)
        {
            mainCanvas = mainCanvas.rootCanvas;
        }

        if (mainCanvas.GetComponent<GraphicRaycaster>() == null)
        {
            mainCanvas.gameObject.AddComponent<GraphicRaycaster>();
        }

        rootRect = mainCanvas.GetComponent<RectTransform>();
    }

    private void BuildLevelSelectUI()
    {
        // 1. Nền tổng thể (chỉ tạo nếu Canvas chưa có ảnh nền)
        if (rootRect.GetComponent<Image>() == null)
        {
            Image bg = rootRect.gameObject.AddComponent<Image>();
            bg.color = colBgDark;
        }

        // 2. Thanh Tiêu Đề Phía Trên (Top Header)
        RectTransform header = CreateProportionalPanel("Header_Bar", rootRect, colHeaderBg,
            new Vector2(0.03f, 0.86f), new Vector2(0.97f, 0.97f));

        CreateProportionalLabel("Title_Label", header, "BẢN ĐỒ MÀN CHƠI", colAccentGold,
            new Vector2(0.04f, 0.45f), new Vector2(0.65f, 0.92f), 16, 44, TextAnchor.MiddleLeft);

        CreateProportionalLabel("Sub_Label", header, "Chọn một màn chơi bên dưới để bắt đầu", new Color(0.78f, 0.86f, 1f),
            new Vector2(0.04f, 0.10f), new Vector2(0.65f, 0.45f), 12, 24, TextAnchor.MiddleLeft);

        // Khung tổng số Sao đã đạt được ở góc phải Header
        RectTransform starBox = CreateProportionalPanel("TotalStars_Box", header, new Color(0.10f, 0.13f, 0.24f, 1f),
            new Vector2(0.68f, 0.18f), new Vector2(0.96f, 0.82f));

        RectTransform starIconSlot = CreateAnchoredContainer("StarIconSlot", starBox,
            new Vector2(0.06f, 0.15f), new Vector2(0.32f, 0.85f));
        CreateSquareAspectImage("StarIcon", starIconSlot, starSprite, colAccentGold);

        totalStarsText = CreateProportionalLabel("TotalStars_Value", starBox, "0 / 0", Color.white,
            new Vector2(0.35f, 0.15f), new Vector2(0.94f, 0.85f), 14, 34, TextAnchor.MiddleCenter);

        // 3. Vùng Chứa Danh Sách Thẻ Màn Chơi (Có hỗ trợ cuộn dọc nếu nhiều màn)
        if (customGridContainer != null)
        {
            cardsContainer = customGridContainer;
        }
        else
        {
            RectTransform scrollArea = CreateProportionalPanel("Levels_ScrollArea", rootRect, new Color(0.12f, 0.16f, 0.28f, 0.75f),
                new Vector2(0.04f, 0.13f), new Vector2(0.96f, 0.83f), raycastTarget: true);

            ScrollRect scrollRect = scrollArea.gameObject.AddComponent<ScrollRect>();
            scrollRect.horizontal = false;
            scrollRect.vertical = true;
            scrollRect.movementType = ScrollRect.MovementType.Elastic;
            scrollRect.scrollSensitivity = 35f;

            RectTransform viewport = CreateAnchoredContainer("Viewport", scrollArea,
                new Vector2(0.02f, 0.02f), new Vector2(0.98f, 0.98f));
            Image vpImg = viewport.gameObject.AddComponent<Image>();
            vpImg.color = new Color(1f, 1f, 1f, 0.01f);
            Mask mask = viewport.gameObject.AddComponent<Mask>();
            mask.showMaskGraphic = false;

            cardsContainer = CreateAnchoredContainer("Content_Grid", viewport, new Vector2(0f, 1f), new Vector2(1f, 1f));
            cardsContainer.pivot = new Vector2(0.5f, 1f);

            scrollRect.viewport = viewport;
            scrollRect.content = cardsContainer;
        }

        // 4. Thanh Công Cụ Phía Dưới (Nút mở khóa nhanh để test & Nút xóa dữ liệu lưu)
        RectTransform footer = CreateProportionalPanel("Footer_Bar", rootRect, colHeaderBg,
            new Vector2(0.04f, 0.02f), new Vector2(0.96f, 0.105f));

        Button btnUnlockAll = CreateProportionalButton("Btn_UnlockAll", footer, "Mở Khóa Tất Cả (Test)", colAccentCyan,
            new Vector2(0.04f, 0.16f), new Vector2(0.48f, 0.84f));
        btnUnlockAll.onClick.AddListener(() =>
        {
            int count = levels != null ? levels.Length : 10;
            PlayerPrefs.SetInt("Match3_UnlockedLevelIndex", count);
            PlayerPrefs.Save();
            PopulateLevelCards();
        });

        Button btnReset = CreateProportionalButton("Btn_ResetSave", footer, "Xóa Tiến Độ Lưu", colAccentPink,
            new Vector2(0.52f, 0.16f), new Vector2(0.96f, 0.84f));
        btnReset.onClick.AddListener(() =>
        {
            int count = levels != null ? levels.Length : 50;
            LevelSession.ResetAllProgress(count);
            PopulateLevelCards();
        });
    }

    /// <summary>
    /// Đọc danh sách LevelData[] trong Inspector và sinh các thẻ màn chơi theo dạng lưới 3 cột.
    /// </summary>
    public void PopulateLevelCards()
    {
        for (int i = cardsContainer.childCount - 1; i >= 0; i--)
        {
            Destroy(cardsContainer.GetChild(i).gameObject);
        }

        if (levels == null || levels.Length == 0)
        {
            CreateProportionalLabel("Empty_Warning", cardsContainer,
                "Chưa có màn chơi nào!\nHãy kéo các file LevelData vào mục 'Levels' trên Inspector của Canvas.",
                colAccentGold, new Vector2(0.05f, 0.2f), new Vector2(0.95f, 0.8f), 16, 32);
            return;
        }

        // Cấu hình GridLayoutGroup tự động co giãn theo chiều rộng khung chứa
        GridLayoutGroup grid = cardsContainer.GetComponent<GridLayoutGroup>();
        if (grid == null)
        {
            grid = cardsContainer.gameObject.AddComponent<GridLayoutGroup>();
        }

        Canvas.ForceUpdateCanvases();
        float containerWidth = cardsContainer.rect.width > 100f ? cardsContainer.rect.width : 900f;
        int columns = 3;
        float spacing = 26f;
        float padding = 24f;
        float cellWidth = (containerWidth - (padding * 2f) - (spacing * (columns - 1))) / columns;
        float cellHeight = cellWidth * 1.18f;

        grid.padding = new RectOffset((int)padding, (int)padding, (int)padding, (int)padding);
        grid.spacing = new Vector2(spacing, spacing);
        grid.cellSize = new Vector2(Mathf.Max(160f, cellWidth), Mathf.Max(190f, cellHeight));
        grid.startCorner = GridLayoutGroup.Corner.UpperLeft;
        grid.startAxis = GridLayoutGroup.Axis.Horizontal;
        grid.childAlignment = TextAnchor.UpperCenter;
        grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        grid.constraintCount = columns;

        ContentSizeFitter fitter = cardsContainer.GetComponent<ContentSizeFitter>();
        if (fitter == null)
        {
            fitter = cardsContainer.gameObject.AddComponent<ContentSizeFitter>();
        }
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        int highestUnlocked = LevelSession.GetHighestUnlockedIndex();
        int earnedStarsTotal = 0;
        int maxPossibleStars = levels.Length * 3;

        for (int i = 0; i < levels.Length; i++)
        {
            LevelData data = levels[i];
            int levelIndex = i;
            bool isUnlocked = (i <= highestUnlocked);
            int stars = LevelSession.GetStarsForLevel(i);
            earnedStarsTotal += stars;

            BuildSingleLevelCard(levelIndex, data, isUnlocked, stars);
        }

        if (totalStarsText != null)
        {
            totalStarsText.text = $"{earnedStarsTotal} / {maxPossibleStars}";
        }
    }

    private void BuildSingleLevelCard(int index, LevelData data, bool isUnlocked, int earnedStars)
    {
        Color cardColor = isUnlocked ? colCardUnlocked : colCardLocked;
        RectTransform cardRect = CreateProportionalPanel($"LevelCard_{index + 1}", cardsContainer, cardColor,
            Vector2.zero, Vector2.one, raycastTarget: true);

        Button btn = cardRect.gameObject.AddComponent<Button>();
        btn.interactable = isUnlocked && data != null;

        // 1. Huy hiệu Số Thứ Tự Màn Chơi
        string levelTitle = data != null && !string.IsNullOrEmpty(data.DisplayName)
            ? data.DisplayName
            : $"Màn {index + 1}";

        CreateProportionalLabel("Level_Title", cardRect, levelTitle,
            isUnlocked ? Color.white : new Color(0.55f, 0.6f, 0.7f),
            new Vector2(0.08f, 0.72f), new Vector2(0.92f, 0.94f), 14, 32);

        // 2. Thông tin Mục tiêu & Lượt đi của màn chơi (Đọc trực tiếp từ LevelData)
        string goalDescription = GetGoalSummaryText(data);
        CreateProportionalLabel("Goal_Summary", cardRect, goalDescription,
            isUnlocked ? colAccentCyan : new Color(0.45f, 0.5f, 0.6f),
            new Vector2(0.08f, 0.42f), new Vector2(0.92f, 0.70f), 10, 22);

        // 3. Hiển thị 3 Ngôi Sao hoặc Trạng thái Khóa
        if (isUnlocked)
        {
            float[] starCentersX = { 0.25f, 0.50f, 0.75f };
            for (int s = 0; s < 3; s++)
            {
                float cx = starCentersX[s];
                RectTransform starSlot = CreateAnchoredContainer($"Star_{s + 1}", cardRect,
                    new Vector2(cx - 0.11f, 0.10f), new Vector2(cx + 0.11f, 0.36f));

                Color sColor = (s < earnedStars) ? colAccentGold : new Color(0.08f, 0.10f, 0.18f, 0.9f);
                CreateSquareAspectImage($"StarImg_{s + 1}", starSlot, starSprite, sColor);
            }
        }
        else
        {
            RectTransform lockBadge = CreateProportionalPanel("Lock_Badge", cardRect, new Color(0.06f, 0.08f, 0.14f, 0.9f),
                new Vector2(0.18f, 0.12f), new Vector2(0.82f, 0.34f));
            CreateProportionalLabel("Lock_Text", lockBadge, "ĐANG KHÓA", new Color(0.65f, 0.7f, 0.8f),
                new Vector2(0.05f, 0.1f), new Vector2(0.95f, 0.9f), 10, 20);
        }

        // Sự kiện khi người chơi bấm chọn màn chơi
        btn.onClick.AddListener(() => OnLevelCardClicked(index, data, cardRect));
    }

    private string GetGoalSummaryText(LevelData data)
    {
        if (data == null) return "Chưa gán LevelData";

        string goalText;
        switch (data.GoalType)
        {
            case LevelGoalType.CollectCandy:
                goalText = $"Thu thập: {data.TargetCandyCount} Kẹo";
                break;
            case LevelGoalType.ClearObstacles:
                goalText = "Phá hủy Vật cản";
                break;
            case LevelGoalType.ReachScore:
            default:
                goalText = $"Đạt {data.TargetScore:N0} điểm";
                break;
        }

        return $"{goalText}\n({data.MoveLimit} lượt đi)";
    }

    private void OnLevelCardClicked(int index, LevelData data, RectTransform cardRect)
    {
        if (data == null) return;
        StartCoroutine(SelectAndLoadRoutine(index, data, cardRect));
    }

    private IEnumerator SelectAndLoadRoutine(int index, LevelData data, RectTransform cardRect)
    {
        // Hiệu ứng nảy thẻ màn chơi trước khi chuyển cảnh
        float duration = 0.16f;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float s = 1f + Mathf.Sin((elapsed / duration) * Mathf.PI) * 0.15f;
            if (cardRect != null) cardRect.localScale = new Vector3(s, s, 1f);
            yield return null;
        }

        // Lưu LevelData đã chọn vào LevelSession và tải Scene Gameplay
        LevelSession.SelectLevel(data, index, levels);
        SceneManager.LoadScene(LevelSession.GameplaySceneName);
    }

    // =========================================================================================
    // CÁC HÀM TIỆN ÍCH VẼ UI VÀ SPRITE TỰ ĐỘNG
    // =========================================================================================

    private RectTransform CreateAnchoredContainer(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent, false);

        RectTransform rect = obj.AddComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        rect.localScale = Vector3.one;
        return rect;
    }

    private RectTransform CreateProportionalPanel(string name, Transform parent, Color color, Vector2 anchorMin, Vector2 anchorMax, bool raycastTarget = false)
    {
        RectTransform rect = CreateAnchoredContainer(name, parent, anchorMin, anchorMax);
        Image img = rect.gameObject.AddComponent<Image>();
        img.sprite = roundedSprite;
        img.type = Image.Type.Sliced;
        img.color = color;
        img.raycastTarget = raycastTarget;
        return rect;
    }

    private Image CreateSquareAspectImage(string name, Transform parent, Sprite sprite, Color color)
    {
        RectTransform rect = CreateAnchoredContainer(name, parent, Vector2.zero, Vector2.one);
        Image img = rect.gameObject.AddComponent<Image>();
        img.sprite = sprite;
        img.color = color;
        img.preserveAspect = true;
        img.raycastTarget = false;

        AspectRatioFitter fitter = rect.gameObject.AddComponent<AspectRatioFitter>();
        fitter.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
        fitter.aspectRatio = 1f;
        return img;
    }

    private Text CreateProportionalLabel(
        string name,
        Transform parent,
        string content,
        Color color,
        Vector2 anchorMin,
        Vector2 anchorMax,
        int minFontSize,
        int maxFontSize,
        TextAnchor alignment = TextAnchor.MiddleCenter)
    {
        RectTransform rect = CreateAnchoredContainer(name, parent, anchorMin, anchorMax);

        Text txt = rect.gameObject.AddComponent<Text>();
        txt.font = defaultFont;
        txt.text = content;
        txt.fontStyle = FontStyle.Bold;
        txt.alignment = alignment;
        txt.color = color;
        txt.raycastTarget = false;
        txt.resizeTextForBestFit = true;
        txt.resizeTextMinSize = minFontSize;
        txt.resizeTextMaxSize = maxFontSize;
        txt.horizontalOverflow = HorizontalWrapMode.Wrap;
        txt.verticalOverflow = VerticalWrapMode.Truncate;

        Shadow shadow = rect.gameObject.AddComponent<Shadow>();
        shadow.effectColor = new Color(0f, 0f, 0f, 0.65f);
        shadow.effectDistance = new Vector2(1.5f, -1.5f);
        return txt;
    }

    private Button CreateProportionalButton(string name, Transform parent, string labelText, Color bgColor, Vector2 anchorMin, Vector2 anchorMax)
    {
        RectTransform btnRect = CreateProportionalPanel(name, parent, bgColor, anchorMin, anchorMax, raycastTarget: true);
        Button btn = btnRect.gameObject.AddComponent<Button>();
        CreateProportionalLabel("Btn_Label", btnRect, labelText, Color.white,
            new Vector2(0.06f, 0.12f), new Vector2(0.94f, 0.88f), 11, 26);
        return btn;
    }

    private void PrepareProceduralAssets()
    {
        defaultFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (defaultFont == null) defaultFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
        if (defaultFont == null) defaultFont = Font.CreateDynamicFontFromOSFont("Arial", 32);

        roundedSprite = CreateRoundedRectSprite(64, 64, 16);
        circleSprite = CreateRoundedRectSprite(64, 64, 31);
        starSprite = CreateStarPolygonSprite(96);
    }

    private Sprite CreateRoundedRectSprite(int width, int height, float radius)
    {
        Texture2D tex = new Texture2D(width, height, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;

        Vector2 halfSize = new Vector2(width * 0.5f, height * 0.5f);
        Vector2 innerHalf = halfSize - new Vector2(radius + 1f, radius + 1f);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                Vector2 p = new Vector2(x + 0.5f, y + 0.5f) - halfSize;
                Vector2 q = new Vector2(Mathf.Abs(p.x), Mathf.Abs(p.y)) - innerHalf;
                float dist = Vector2.Max(q, Vector2.zero).magnitude + Mathf.Min(Mathf.Max(q.x, q.y), 0f) - radius;
                float alpha = Mathf.Clamp01(0.5f - dist);
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
            }
        }
        tex.Apply();
        Vector4 border = new Vector4(radius, radius, radius, radius);
        return Sprite.Create(tex, new Rect(0, 0, width, height), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
    }

    private Sprite CreateStarPolygonSprite(int size)
    {
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;

        Vector2 center = new Vector2(size * 0.5f, size * 0.5f);
        float maxR = size * 0.44f;
        float minR = size * 0.20f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                Vector2 dir = new Vector2(x + 0.5f, y + 0.5f) - center;
                float dist = dir.magnitude;
                float angle = Mathf.Atan2(dir.y, dir.x) - Mathf.PI * 0.5f;
                float sector = Mathf.Repeat(angle, Mathf.PI * 2f / 5f);
                float halfSector = Mathf.PI / 5f;
                float starFactor = Mathf.Abs(sector - halfSector) / halfSector;
                float targetRadius = Mathf.Lerp(minR, maxR, starFactor);
                float alpha = Mathf.Clamp01((targetRadius - dist) * 0.8f);
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
            }
        }
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
    }
}