using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Hệ thống Object Pooling quản lý việc tái sử dụng các viên kẹo.
/// Tự động đồng bộ kích thước kẹo theo Board.CellSize và phát hiệu ứng Pop Bong Bóng khi kẹo nổ.
/// </summary>
public class CandyPool : MonoBehaviour
{
    private GameObject[] candyPrefabs;
    private Transform poolContainer;
    private Board ownerBoard;

    private readonly Dictionary<int, Queue<Candy>> poolByPrefabIndex = new Dictionary<int, Queue<Candy>>();

    public int CandyTypeCount => candyPrefabs != null ? candyPrefabs.Length : 0;

    public void Initialize(GameObject[] prefabs, Transform container)
    {
        candyPrefabs = prefabs;
        poolContainer = container;
        ownerBoard = GetComponent<Board>();
        poolByPrefabIndex.Clear();

        if (candyPrefabs == null)
        {
            return;
        }

        for (int i = 0; i < candyPrefabs.Length; i++)
        {
            poolByPrefabIndex[i] = new Queue<Candy>();

            if (candyPrefabs[i] != null)
            {
                if (candyPrefabs[i].GetComponent<Candy>() == null)
                {
                    Debug.LogWarning($"Prefab '{candyPrefabs[i].name}' chưa gắn sẵn Candy.cs. Hệ thống sẽ tự thêm khi khởi tạo.", candyPrefabs[i]);
                }
                if (candyPrefabs[i].GetComponent<Collider2D>() == null)
                {
                    Debug.LogWarning($"Prefab '{candyPrefabs[i].name}' chưa gắn sẵn Collider2D. Hệ thống sẽ tự thêm BoxCollider2D.", candyPrefabs[i]);
                }
            }
        }
    }

    public Candy SpawnCandy(int typeIndex, Vector3 position, SpecialCandyType specialType = SpecialCandyType.None)
    {
        if (candyPrefabs == null || candyPrefabs.Length == 0)
        {
            Debug.LogError("CandyPool: Chưa gán danh sách candyPrefabs!");
            return null;
        }

        int prefabIndex = (typeIndex >= 0 && typeIndex < candyPrefabs.Length) ? typeIndex : 0;
        if (candyPrefabs[prefabIndex] == null)
        {
            Debug.LogError($"CandyPool: Prefab tại vị trí {prefabIndex} bị trống (null)!");
            return null;
        }

        if (!poolByPrefabIndex.TryGetValue(prefabIndex, out Queue<Candy> queue))
        {
            queue = new Queue<Candy>();
            poolByPrefabIndex[prefabIndex] = queue;
        }

        Candy candy = null;
        while (queue.Count > 0 && candy == null)
        {
            candy = queue.Dequeue();
        }

        if (candy == null)
        {
            GameObject obj = Instantiate(candyPrefabs[prefabIndex], position, Quaternion.identity, poolContainer);
            if (ownerBoard != null)
            {
                obj.transform.localScale *= ownerBoard.CellSize;
            }

            candy = obj.GetComponent<Candy>();
            if (candy == null)
            {
                candy = obj.AddComponent<Candy>();
            }
            if (obj.GetComponent<Collider2D>() == null)
            {
                obj.AddComponent<BoxCollider2D>();
            }
        }
        else
        {
            candy.transform.position = position;
            candy.gameObject.SetActive(true);
        }

        candy.Initialize(prefabIndex, specialType);

        if (Time.timeSinceLevelLoad > 0.35f && gameObject.activeInHierarchy)
        {
            StartCoroutine(SpawnBounceRoutine(candy));
        }

        return candy;
    }

    private IEnumerator SpawnBounceRoutine(Candy candy)
    {
        if (candy == null) yield break;
        Vector3 baseScale = candy.GetBaseScale();
        float duration = 0.18f;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            if (candy == null || !candy.gameObject.activeInHierarchy) yield break;
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float factor = Mathf.Sin(t * Mathf.PI * 0.5f) * 1.12f;
            candy.transform.localScale = baseScale * factor;
            yield return null;
        }

        if (candy != null && candy.gameObject.activeInHierarchy)
        {
            candy.transform.localScale = baseScale;
        }
    }

    public void ReleaseCandy(Candy candy)
    {
        if (candy == null)
        {
            return;
        }

        if (candy.gameObject.activeInHierarchy && Time.timeSinceLevelLoad > 0.35f)
        {
            Vector3 worldPos = candy.transform.position;
            int colorId = candy.PoolIndex;
            float cellSize = ownerBoard != null ? ownerBoard.CellSize : 1f;

            if (Match3VFXManager.Instance != null)
            {
                Match3VFXManager.Instance.PlayBubblePop(worldPos, colorId, cellSize);
            }
        }

        int originPoolIndex = candy.PoolIndex;

        candy.SetCell(null);
        candy.SetSelectedVisual(false);
        candy.SetSpecialType(SpecialCandyType.None);
        candy.gameObject.SetActive(false);

        if (poolContainer != null && candy.transform.parent != poolContainer)
        {
            candy.transform.SetParent(poolContainer, false);
        }

        if (!poolByPrefabIndex.ContainsKey(originPoolIndex))
        {
            poolByPrefabIndex[originPoolIndex] = new Queue<Candy>();
        }

        poolByPrefabIndex[originPoolIndex].Enqueue(candy);
    }
}