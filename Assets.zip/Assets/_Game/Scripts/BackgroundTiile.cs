using UnityEngine;

/// <summary>
/// Một ô nền trên bảng Match 3.
/// Giữ nguyên tên BackgroundTiile để tương thích với prefab trong project hiện tại.
/// Đã tách riêng hàm gán logic (AssignCandyLogical) và hàm gán hiển thị (SetCandy)
/// để tránh gọi Transform.SetParent liên tục khi mô phỏng nước đi hoặc xáo trộn.
/// </summary>
public class BackgroundTiile : MonoBehaviour
{
    [Header("Candy Prefabs (Fallback)")]
    [Tooltip("Danh sách prefab kẹo. Có thể cấu hình tại đây hoặc ghi đè trong LevelData.")]
    public GameObject[] dots;

    public int X { get; private set; }
    public int Y { get; private set; }
    public Board OwnerBoard { get; private set; }
    public Candy CurrentCandy { get; private set; }

    public void Initialize(Board board, int x, int y)
    {
        OwnerBoard = board;
        X = x;
        Y = y;
    }

    /// <summary>
    /// Tạo hoặc lấy một viên kẹo từ CandyPool và đặt vào ô này.
    /// </summary>
    public Candy CreateCandy(int typeIndex, Vector3 spawnPosition, bool snapToCell = true, SpecialCandyType specialType = SpecialCandyType.None)
    {
        Candy candy = null;

        // Ưu tiên lấy kẹo từ Object Pool của Board để tránh rác bộ nhớ (GC)
        if (OwnerBoard != null && OwnerBoard.Pool != null)
        {
            candy = OwnerBoard.Pool.SpawnCandy(typeIndex, spawnPosition, specialType);
        }
        else
        {
            // Fallback nếu gọi độc lập không qua Pool
            if (dots == null || typeIndex < 0 || typeIndex >= dots.Length || dots[typeIndex] == null)
            {
                Debug.LogError($"Candy prefab không hợp lệ ở index {typeIndex}.", this);
                return null;
            }

            GameObject candyObject = Instantiate(dots[typeIndex], spawnPosition, Quaternion.identity);
            candy = candyObject.GetComponent<Candy>();
            if (candy == null) candy = candyObject.AddComponent<Candy>();
            if (candyObject.GetComponent<Collider2D>() == null) candyObject.AddComponent<BoxCollider2D>();
            candy.Initialize(typeIndex, specialType);
        }

        if (candy != null)
        {
            candy.gameObject.name = $"Candy_{typeIndex} ({X}, {Y})";
            SetCandy(candy, snapToCell);
        }

        return candy;
    }

    /// <summary>
    /// Gán kẹo vào ô trong gameplay thực tế (có cập nhật vị trí hoặc Transform nếu cần).
    /// Kẹo được giữ trong CandiesContainer chung của Board thay vì đổi Parent liên tục.
    /// </summary>
    public void SetCandy(Candy candy, bool snapToCell = true)
    {
        CurrentCandy = candy;

        if (candy == null)
        {
            return;
        }

        candy.SetCell(this);

        // Giữ kẹo trong container chung của Board để không phải đổi Hierarchy mỗi lần di chuyển
        Transform targetParent = (OwnerBoard != null && OwnerBoard.CandiesContainer != null)
            ? OwnerBoard.CandiesContainer
            : transform;

        if (candy.transform.parent != targetParent)
        {
            candy.transform.SetParent(targetParent, true);
        }

        if (snapToCell)
        {
            candy.transform.position = transform.position;
        }
    }

    /// <summary>
    /// CHỈ gán tham chiếu dữ liệu logic để phục vụ thuật toán thử nước đi (HasPossibleMove)
    /// hoặc xáo trộn (Reshuffle). Tuyệt đối KHÔNG đụng tới Transform để tối ưu CPU.
    /// </summary>
    public void AssignCandyLogical(Candy candy)
    {
        CurrentCandy = candy;
        if (candy != null)
        {
            candy.SetCell(this);
        }
    }
}
